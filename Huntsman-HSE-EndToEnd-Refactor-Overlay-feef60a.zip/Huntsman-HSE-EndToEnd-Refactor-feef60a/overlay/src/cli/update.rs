//! Thin CLI adapter for the application update service.

use crate::{
    app::update::{self, AutoUpdateOutcome},
    core::error::Result,
};

use super::Command;

/// Commands that own installation state or only observe the current install.
///
/// This is the single executable authority used by runtime dispatch and tests;
/// there is deliberately no mirrored test predicate to keep in sync.
fn skips_auto_update(command: &Command) -> bool {
    matches!(
        command,
        Command::Serve { .. }
            | Command::Update { .. }
            | Command::BuildSha { .. }
            | Command::Doctor { .. }
            | Command::Selftest { .. }
            | Command::Provision { .. }
    )
}

pub(super) async fn cmd_update(check: bool, ref_: Option<String>) -> Result<()> {
    println!("hse {} — update", crate::VERSION);

    if check {
        match update::ensure_install_dir() {
            Some(dir) => {
                print!("Source: {}  ", dir.display());
                if update::is_detached(&dir) {
                    println!(
                        "HEAD is detached: pinned to one commit and following no branch, so \
                         nothing is behind and nothing updates it automatically. `hse update` \
                         installs main."
                    );
                    return Ok(());
                }
                match update::commits_behind(&dir) {
                    Some(0) => println!("Already up to date."),
                    Some(n) => {
                        println!("{n} commit(s) available — run `hse update` to install.");
                        for line in update::changelog_lines(&dir).iter().take(20) {
                            println!("  {line}");
                        }
                    }
                    None => println!("(could not reach remote — offline?)"),
                }
            }
            None => {
                println!("Source directory not found.");
                println!("Re-run the installer to get updates:");
                println!("  {}", update::INSTALL_CMD);
            }
        }
        return Ok(());
    }

    update::apply_update(ref_).await
}

pub(super) async fn maybe_auto_update(command: &Command) {
    // Read-only/hidden commands must never trigger a background reinstall:
    // install.sh itself invokes `hse build-sha` (prebuilt check + post-install
    // verification) and `hse provision` (env-file merge), so gating on either
    // would re-enter a SECOND detached install.sh into the same source dir —
    // racing the foreground installer's git checkout, cargo build, binary swap,
    // and rollback copy. Doctor / selftest are diagnostics: they must observe
    // the current install, never mutate it.
    if skips_auto_update(command) {
        return;
    }

    match update::maybe_auto_update().await {
        AutoUpdateOutcome::None => {}
        AutoUpdateOutcome::Applying { commits, log } => eprintln!(
            "hse: {commits} commit(s) behind GitHub main — applying the update in the \
             background (log: {}). This run uses the current build; the next run \
             picks up the rebuilt one. Disable with `hse config feature.auto_update off`.",
            log.display()
        ),
        AutoUpdateOutcome::Available { commits } => eprintln!(
            "hse: {commits} commit(s) available on GitHub main — run `hse update` to install \
             (auto-update is off; silence with `hse config feature.update_notify off`)."
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn update_owners_skip_opportunistic_check() {
        assert!(skips_auto_update(&Command::Serve {
            bind: "127.0.0.1:8080".into(),
            no_key_write: false,
            auth_token: None,
            allow_unauthenticated: false,
        }));
        assert!(skips_auto_update(&Command::Update {
            check: false,
            r#ref: None,
        }));
    }

    #[test]
    fn installer_invoked_readonly_commands_skip_opportunistic_check() {
        // install.sh runs `hse build-sha` mid-install and `hse provision` at
        // the end; gating on either would spawn a second, detached install.sh
        // racing the foreground one. Observed on-device 2026-09-15: a prebuilt
        // install of dcfbd9e (which WAS main) printed
        // "4 commit(s) behind GitHub main — applying the update in the
        // background" *during* `hse provision`, because an older source
        // checkout was still on disk and Provision was not in the skip set.
        assert!(skips_auto_update(&Command::BuildSha { json: false }));
        assert!(skips_auto_update(&Command::Doctor { live: false }));
        assert!(skips_auto_update(&Command::Selftest { json: false }));
        assert!(skips_auto_update(&Command::Provision {
            env_only: true,
            verify_only: false,
            dry_run: false,
            discover: true,
        }));
        assert!(!skips_auto_update(&Command::Engines { json: false }));
    }
}
