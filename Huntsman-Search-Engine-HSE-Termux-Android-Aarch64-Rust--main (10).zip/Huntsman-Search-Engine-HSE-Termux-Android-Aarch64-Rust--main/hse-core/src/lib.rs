//! `core::entity` — HSE entity model.
//!
//! Extracted from `huntsman_search_engine::core::entity` into its own crate,
//! re-exported at that same path (`crate::core::entity` in the parent crate)
//! so this file's content and every one of its ~250 call sites are otherwise
//! unchanged. The point of the extraction is sharing this logic — unmodified,
//! not reimplemented — with a wasm32-unknown-unknown browser build of the web
//! UI, so confidence-tier math the UI displays can call the real
//! `Entity::c_effective`/`source_count` instead of a hand-maintained JS
//! approximation that had already drifted out of sync once
//! (`ENRICHMENT_ONLY_SOURCES` vs. `src/web/js/helpers.js`'s old
//! `ENRICHMENT_SOURCES` mirror).
//!
//! # Architecture invariants
//! - SHA-256 deterministic UIDs
//! - GREATEST-semantics merge (confidence, corroboration only ever increase)
//! - `C_eff = clamp(max(C × (1 + 0.15·ln n), 1 − (1−C)·0.65^(n−1)), 0.0, 1.0)`,
//!   where `n = source_count()` (distinct corroborating sources) — NOT the raw
//!   `corroboration` field, a separate per-module observation magnitude. See
//!   [`Entity::c_effective`] and [`Entity::source_count`].
//! - `Classify()` is derived-only from `C_eff`
//! - No unsafe, no std::sync::Mutex (use tokio::sync, in the native build)
//! - Zero CGO / native deps

// hse-core's docs are built with `--document-private-items` and read internally,
// not consumed as a published API, so a public doc item linking to a private one
// (e.g. `coords`'s reference to `LatLon::checked`) is intentional. This mirrors
// the crate-root allow the parent crate already carries (see `src/lib.rs`); the
// high-value `broken_intra_doc_links` lint stays denied in CI, and only this
// stylistic, internal-reference lint is relaxed.
#![allow(rustdoc::private_intra_doc_links)]

pub mod coords;
pub mod tags;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::hash_map::RandomState;
use std::collections::{BTreeMap, HashMap};
use std::fmt;
use std::hash::BuildHasher;
#[cfg(not(target_arch = "wasm32"))]
use std::time::{SystemTime, UNIX_EPOCH};

/// Moved here from `huntsman_search_engine::util::url_util` (which now
/// re-exports this) so this crate has no dependency back onto the binary it
/// was extracted out of. This is the single definition — `util::url_util`
/// and `modules::search_engines::helpers::urls` both consume it through the
/// re-export, so there is exactly one tracking-param list, not a mirror.
const URL_TRACKING_PARAMS: &[&str] = &[
    // Google / Ads
    "gclid",
    "gclsrc",
    "dclid",
    "gbraid",
    "wbraid",
    "_ga",
    "_gl",
    // Facebook / Instagram / Meta
    "fbclid",
    "fb_action_ids",
    "fb_action_types",
    "fb_ref",
    "fb_source",
    "igshid",
    "igsh",
    "mibextid",
    // Microsoft / Bing, Twitter/X, Yandex
    "msclkid",
    "twclid",
    "ref_src",
    "ref_url",
    "yclid",
    // Email / marketing automation
    "mc_cid",
    "mc_eid",
    "mkt_tok",
    "_hsenc",
    "_hsmi",
    "hsctatracking",
    "vero_id",
    "vero_conv",
    "oly_anon_id",
    "oly_enc_id",
    "wickedid",
    // Misc analytics
    "spm",
    "scm",
    "s_kwcid",
    "_openstat",
    "icid",
];

/// True when a query-parameter key is pure tracking and safe to drop during
/// URL canonicalisation: the `utm_*` family (case-insensitive prefix) or an
/// exact (case-insensitive) match in `URL_TRACKING_PARAMS`. Uses `get(..4)`
/// rather than slicing so a non-ASCII key can never panic on a char boundary.
#[must_use]
pub fn is_tracking_param_key(key: &str) -> bool {
    if key.get(..4).is_some_and(|p| p.eq_ignore_ascii_case("utm_")) {
        return true;
    }
    URL_TRACKING_PARAMS
        .iter()
        .any(|p| key.eq_ignore_ascii_case(p))
}

// ─── Constants ───────────────────────────────────────────────────────────────

/// Corroboration boost coefficient (architecture invariant).
pub const CORROBORATION_COEFF: f64 = 0.15;

/// Residual-doubt decay per *additional* independent source in the
/// agreement model of [`Entity::c_effective`]. Each distinct corroborating
/// source shrinks the remaining doubt `(1 − confidence)` by this factor, so
/// independent agreement drives confidence toward certainty: at `0.65`, a
/// moderate finding (C=0.6) reaches ~0.74 at 2 sources and ~0.83 (Verified) at
/// 3 — which the purely-multiplicative model badly under-credits (0.66 / 0.73).
pub const CORROBORATION_DOUBT_DECAY: f64 = 0.65;

/// Confidence decay constant per hour (γ = 0.85).
pub const GAMMA_PER_HOUR: f64 = 0.85;

/// Confidence ceiling a **quarantined** entity is capped to: a finding sourced
/// from a record that does NOT match the scan target's identity (a stranger
/// from a broad breach/stealer search) is preserved as a lead at this strength
/// rather than discarded, but must never reach the correlated, default-view
/// tier. Deliberately below [`Classification::PROBABLE_MIN`] (0.40) so a demoted
/// entity always classifies as `Candidate`. The demotion itself is
/// [`Entity::demote_to_candidate`] — one definition shared by every breach pool
/// (the matcher that DECIDES a non-match lives separately in
/// `util::target_match`, keeping "does this match?" orthogonal to "tier it").
pub const CANDIDATE_CONF: f64 = 0.25;

/// Evidence "sources" that are deterministic self-enrichment passes the engine
/// runs over every entity of a given kind — NOT independent intelligence.
///
/// `geo_normalize` is the geospatial enrichment pass (`core::engine`)
/// that attaches a geohash/timezone/parsed-address evidence record to *every*
/// `Coordinates`/`Address` entity. Because it fires unconditionally it is not a
/// cross-correlating observation: counting it as a distinct source silently
/// lifted single-source coarse geo guesses (a postcode centroid, a candidate
/// suburb) from their base confidence into the Probable tier via the
/// agreement model, and fired the corroboration correlator rules
/// (AU-003/AU-014/AU-030) once per such entity. These sources are still kept in
/// the evidence chain (their attributes are real and useful) and still appear
/// in [`Entity::evidence_sources`] for display; they are only excluded from the
/// *corroboration* count — see [`Entity::corroborating_sources`].
///
/// `name_intel` is the name-derivation pass: it deterministically permutes the
/// seed display name into speculative handles and `name × freemail` email
/// guesses (`cindy.haynes@gmail.com`, …). Like `geo_normalize` these are
/// *derivations of the input*, not independent sightings, so counting one as a
/// corroborating source let a pure guess reach the cross-source rules — a
/// permuted `…@gmail.com` presented as "corroborated by 2 independent sources"
/// and fired AU-003 / AU-034. Excluding it means a permutation needs two
/// *genuine* sources to corroborate, while the derived entity still appears as a
/// lead in the dossier (its evidence is kept and shown).
///
/// `seed` is the operator's own target, recorded as evidence so the subject
/// anchor is traceable. It is the INPUT to the scan, so counting it as a source
/// that corroborates the input is a tautology: a live URL scan
/// (`andersonbushikai.com`, debug bundle 6b2d34664852…) showed the seed URL with
/// evidence from exactly `search_engines` + `seed` reported as
/// `source_count=2`, `c_eff=0.99`, VERIFIED — one real observation presented as
/// two. Because AU-003's floor for most kinds is 2, the seed alone could carry
/// an entity half-way to a "corroborated by 2 independent source(s)" finding.
///
/// `url_extract` derives a `Domain` from a `Url` already in the graph. Its own
/// module doc states it is "pure offline, zero network … confidence is derived
/// from the URL's presence in the graph, not from a live check" — the same
/// derivation-of-a-known-fact as `name_intel`, adding no independent sighting.
/// In that same scan it was counted among the five "independent sources" AU-003
/// reported for the apex domain, and among the five "infrastructure sources"
/// AU-010 listed as confirming it.
///
/// The remaining entries are the registry's other **offline derivation
/// modules** — every one a pure, deterministic transform of the seed or of an
/// entity already in the graph, with no external observation of its own
/// (`email_parse` splits an address into local-part/domain, `phone_intl` /
/// `phone_au` / `phone_geo` classify a number from embedded prefix tables,
/// `username_variants` permutes a handle, `email_canonical` folds
/// dot/plus-aliases, `email_locale` / `email_header_geo` /
/// `geo_domain_classifier` infer a locale from the string, `discord_snowflake` /
/// `structured_id` decode what an identifier itself encodes, `breach_timezone`
/// aggregates evidence other modules already attached). Before they were
/// listed, three of them re-emitting a seed phone — `phone_intl` + `phone_au` +
/// `phone_geo`, zero network calls between them — gave the seed
/// `source_count() == 3` and a "corroborated by 3 independent source(s)"
/// finding from nothing but the digits the operator typed in. Each module
/// declares this same fact as `Module::is_derivation() == true`, and
/// `derivation_modules_are_exactly_the_enrichment_only_sources`
/// (tests/architecture_parts) pins the two declarations to each other in both
/// directions.
pub const ENRICHMENT_ONLY_SOURCES: &[&str] = &[
    "breach_timezone",
    "discord_snowflake",
    "email_canonical",
    "email_header_geo",
    "email_locale",
    "email_parse",
    "geo_domain_classifier",
    "geo_normalize",
    "name_intel",
    "payid",
    "phone_au",
    "phone_geo",
    "phone_intl",
    "seed",
    "structured_id",
    "url_extract",
    "username_variants",
];

/// True if `source` is a deterministic self-enrichment pass rather than an
/// independent intelligence source (see [`ENRICHMENT_ONLY_SOURCES`]).
#[inline]
pub fn is_enrichment_source(source: &str) -> bool {
    ENRICHMENT_ONLY_SOURCES.contains(&source)
}

/// Canonical comparison form of a handle: ASCII-lowercased with the handle
/// separators (`.`, `_`, `-`) removed, so equivalent spellings across services
/// collapse to one token.
// Was `pub(in crate::core)` before this module's extraction — restricted to
// sibling `core::*` callers in the parent crate (correlator rules,
// relation/resolve/cross_scan), deliberately excluding `modules::*`/`api::*`.
// A crate boundary can't express "visible to this dependent crate's `core`
// submodule only", so that narrower encapsulation is lost; this is `pub`.
pub fn canonical_handle(value: &str) -> String {
    value
        .chars()
        .filter(|c| !matches!(c, '.' | '_' | '-'))
        .map(|c| c.to_ascii_lowercase())
        .collect()
}

/// Evidence source name of the recall pass — the local-database replay that
/// re-injects a prior scan's entity into the working set.
///
/// Recall is a SECOND look at the SAME prior observation, not a new independent
/// one, so it must never count toward cross-source corroboration. Counting it
/// did exactly that: a single-source finding (a name-permuted handle, a breach
/// co-occurrence row) gained a phantom "2nd source" on every re-scan and was
/// promoted a whole confidence tier (CANDIDATE → PROBABLE) — so a recalled scan
/// graded a tier higher than the identical fresh scan. The recall evidence is
/// still attached (and shown in [`Entity::evidence_sources`]) for provenance; it
/// just can't inflate [`Entity::source_count`] / `c_effective`.
pub const RECALL_SOURCE: &str = "recall";

/// Evidence source name of the cross-scan history link — the finalize pass that
/// notes a finding ALSO appears in an earlier scan in the local intelligence
/// database (the investigation flywheel).
///
/// Like [`RECALL_SOURCE`] this is provenance, not an independent observation: a
/// recurrence can't tell a re-scan of the same subject from a genuinely separate
/// sighting, so counting it would re-introduce exactly the recall over-credit
/// (a single-source value graded a tier higher merely for having been seen
/// before). The `cross_scan_history` evidence is kept and shown for the analyst —
/// it is what SURFACES the link between two investigations — but it must never
/// inflate [`Entity::source_count`] / `c_effective`.
pub const CROSS_SCAN_SOURCE: &str = "cross_scan_history";

/// Evidence source name of the final breach-consensus grading pass
/// (`core::breach_consensus`).
///
/// The pass reads the evidence the breach modules already attached and records
/// how many DISTINCT corpora attest each finding. It is a *summary of* those
/// observations, not a new one — counting it would let an entity corroborate
/// itself, and would do so most strongly for the entities the grading singled
/// out as weakest. The summary is attached (and is what the audit trail reads)
/// but, like [`RECALL_SOURCE`] and [`CROSS_SCAN_SOURCE`], it can never inflate
/// [`Entity::source_count`] / `c_effective`.
pub const CONSENSUS_SOURCE: &str = "breach_consensus";

/// Evidence source name emitted by the multipath-corroboration promotion pass
/// (`promote_multipath_corroborated` in `crate::core::engine::passes`).
///
/// This is a DERIVED signal: it records that the engine found two identity
/// endpoints connected across ≥2 edge-disjoint paths — it is NOT a new
/// independent data source. It may amplify an already-grounded entity's
/// `source_count`, but it must never be the sole reason an entity is considered
/// corroborated (see [`source_count`][Entity::source_count]).
pub const MULTIPATH_CORROBORATION_SOURCE: &str = "multipath_corroboration";

/// Evidence source name emitted by the cross-scan-corroboration promotion pass
/// (`promote_cross_scan_corroborated` in `crate::core::engine::passes`).
///
/// Same semantics as [`MULTIPATH_CORROBORATION_SOURCE`]: engine-derived signal,
/// not an independent observation.
pub const CROSS_SCAN_CORROBORATION_SOURCE: &str = "cross_scan_corroboration";

/// Evidence source name emitted by the geo-corroboration promotion passes
/// (`promote_geo_corroborated_family` / `promote_breach_candidate_geo_corroborated`
/// in `crate::core::engine::passes`). Engine-derived agreement signal, not an
/// independent observation.
pub const GEO_CORROBORATION_SOURCE: &str = "geo_corroboration";

/// True if `source` is an engine **promotion pass** rather than an independent
/// observation. Promotion passes amplify entities that are already grounded by
/// real sources; they must never GROUND an entity by themselves.
///
/// This is distinct from [`is_non_corroborating_source`]: non-corroborating
/// sources are NEVER counted; promotion sources ARE counted, but only when the
/// entity already has at least one real corroborating source (the grounding gate
/// in [`Entity::source_count`]).
#[inline]
pub fn is_promotion_source(source: &str) -> bool {
    source == MULTIPATH_CORROBORATION_SOURCE || source == CROSS_SCAN_CORROBORATION_SOURCE
}

/// True if `source` is an engine-derived corroboration signal — multipath,
/// cross-scan, or geo agreement — rather than an independent observation. Such a
/// signal must classify as the unscored `"other"`
/// `core::correlator::source_family`: it records that
/// existing sources agree, so counting it as its own family would manufacture a
/// phantom orthogonal source family. (`geo_corroboration`'s name contains the
/// `"geo"` substring the family classifier keys `"infra"` on, so without an
/// exact-match guard it was hijacked to `"infra"` and inflated AU-062 multipath /
/// AU-063 gap / AU-082 alerts.) Broader than [`is_promotion_source`]:
/// `geo_corroboration` still counts as a real source for corroboration DEPTH, but
/// must never add family BREADTH.
#[inline]
pub fn is_engine_corroboration_source(source: &str) -> bool {
    source == MULTIPATH_CORROBORATION_SOURCE
        || source == CROSS_SCAN_CORROBORATION_SOURCE
        || source == GEO_CORROBORATION_SOURCE
}

/// True if `source` must NOT count toward cross-source corroboration — a
/// deterministic self-enrichment pass ([`ENRICHMENT_ONLY_SOURCES`]), the recall
/// replay ([`RECALL_SOURCE`]), the cross-scan history link ([`CROSS_SCAN_SOURCE`]),
/// or the breach-consensus summary ([`CONSENSUS_SOURCE`]). All attach genuine,
/// useful evidence, but none is an independent observation, so none may inflate
/// the corroboration count.
#[inline]
pub fn is_non_corroborating_source(source: &str) -> bool {
    is_enrichment_source(source)
        || source == RECALL_SOURCE
        || source == CROSS_SCAN_SOURCE
        || source == CONSENSUS_SOURCE
}

// ─── EntityKind ──────────────────────────────────────────────────────────────

/// All value types an entity can represent.
///
/// People-centric kinds (Person, Email, Phone, Username) are weighted highest
/// in module priority ordering. Infrastructure kinds are enrichment targets.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EntityKind {
    // People-centric (priority identity)
    Person,
    Email,
    Phone,
    Username,

    // Document / credential
    Credential,
    ApiKey,
    Password, // never stored in evidence output

    // Network / infrastructure
    IpAddress,
    Domain,
    Url,
    Asn,
    /// A CIDR network block (`192.0.2.0/24`, `2001:db8::/48`). A scannable
    /// target that expands into its constituent host IPs (bounded).
    Cidr,

    // Physical / GEOINT
    Address,
    Coordinates,

    // Organisation
    Organisation,
    AbnAcn,

    // Device
    MacAddress,
    DeviceId,
    /// A WiFi network name (SSID) lifted from a stealer log or breach record. A
    /// *unique* SSID is geolocatable — WiGLE's SSID search returns the GPS points
    /// the network was observed at, placing the victim; generic/default names
    /// (`NETGEAR`, `iPhone`, …) are not dispatched.
    Ssid,

    // Web-analytics / tracking identifier (Google Analytics `UA-`/`G-`, GTM
    // `GTM-`, AdSense `ca-pub-`, Facebook Pixel, Yandex Metrica, Hotjar). A shared
    // ID across otherwise-unrelated sites is strong evidence of common ownership —
    // the "affiliate" pivot. Not a scannable target; a correlation node only.
    TrackingId,

    // Financial — cryptocurrency wallet addresses (BTC/ETH/LTC/…). A first-class
    // OSINT artifact: case-sensitive (base58 / bech32 / 0x-hex), never an API
    // key, and the pivot point for free chain-explorer enrichment.
    CryptoAddress,

    // Catch-all
    Other(String),
}

impl fmt::Display for EntityKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Person => f.write_str("person"),
            Self::Email => f.write_str("email"),
            Self::Phone => f.write_str("phone"),
            Self::Username => f.write_str("username"),
            Self::Credential => f.write_str("credential"),
            Self::ApiKey => f.write_str("api_key"),
            Self::Password => f.write_str("password"),
            Self::IpAddress => f.write_str("ip_address"),
            Self::Domain => f.write_str("domain"),
            Self::Url => f.write_str("url"),
            Self::Asn => f.write_str("asn"),
            Self::Cidr => f.write_str("cidr"),
            Self::Address => f.write_str("address"),
            Self::Coordinates => f.write_str("coordinates"),
            Self::Organisation => f.write_str("organisation"),
            Self::AbnAcn => f.write_str("abn_acn"),
            Self::MacAddress => f.write_str("mac_address"),
            Self::DeviceId => f.write_str("device_id"),
            Self::Ssid => f.write_str("ssid"),
            Self::TrackingId => f.write_str("tracking_id"),
            Self::CryptoAddress => f.write_str("crypto_address"),
            Self::Other(s) => write!(f, "other:{s}"),
        }
    }
}

// ─── Classification ───────────────────────────────────────────────────────────

/// Derived-only classification tier from `C_eff`.
///
/// Never set directly — always call `Entity::classify()`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum Classification {
    /// `C_eff < 0.40`
    Candidate,
    /// `0.40 ≤ C_eff < 0.75`
    Probable,
    /// `C_eff ≥ 0.75`
    Verified,
}

impl Classification {
    /// Lower bound of the Verified tier: `C_eff ≥ VERIFIED_MIN`.
    ///
    /// The tier ladder's single source of truth (with [`Self::PROBABLE_MIN`]).
    /// Consumed by [`Self::from_c_eff`] / `Entity::classify`, the CLI's
    /// confidence colouring, the engine's subject-identity gate ("every
    /// VERIFIED identity"), and the wrong-identity pivot gate ("below the
    /// Verified tier") — previously each re-stated `0.75` as a bare literal,
    /// so a recalibration would have silently diverged them.
    pub const VERIFIED_MIN: f64 = 0.75;
    /// Lower bound of the Probable tier: `C_eff ≥ PROBABLE_MIN` (and below
    /// [`Self::VERIFIED_MIN`]). Below this is Candidate.
    pub const PROBABLE_MIN: f64 = 0.40;

    /// The tier for an effective confidence — the canonical ladder. A
    /// non-finite `c_eff` (never produced by `c_effective`, which clamps)
    /// fails both bounds and lands in `Candidate`, the conservative tier.
    #[inline]
    #[must_use]
    pub fn from_c_eff(c_eff: f64) -> Self {
        if c_eff >= Self::VERIFIED_MIN {
            Self::Verified
        } else if c_eff >= Self::PROBABLE_MIN {
            Self::Probable
        } else {
            Self::Candidate
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Candidate => "CANDIDATE",
            Self::Probable => "PROBABLE",
            Self::Verified => "VERIFIED",
        }
    }

    /// Stable, dense tier rank (0 = Candidate, 1 = Probable, 2 = Verified).
    ///
    /// This is the finite tier ladder intended to back a bounded best-first
    /// expansion: with a `(target, tier)` visited-set an entity is expanded at
    /// most once per rank, and because there are exactly
    /// [`Classification::COUNT`] ranks, total expansions are bounded by
    /// `entities × COUNT`.
    ///
    /// NOTE (current state): the engine's expansion visited-set is still keyed
    /// on `(TargetKind, normalised value)` and expands each target at most
    /// once overall — it does not yet key on tier or re-queue on tier
    /// graduation. `rank()`/[`Self::COUNT`] are the ladder that the planned
    /// tier-aware frontier will use; until that lands, this method is consumed
    /// by tests and ranking, not by the live visited-set.
    #[inline]
    pub fn rank(self) -> u8 {
        match self {
            Self::Candidate => 0,
            Self::Probable => 1,
            Self::Verified => 2,
        }
    }

    /// Number of distinct confidence tiers. Fixed and finite — the
    /// multiplier in the halting bound `expansions ≤ entities × COUNT`.
    pub const COUNT: u8 = 3;
}

impl fmt::Display for Classification {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

// ─── Evidence ────────────────────────────────────────────────────────────────

/// Verification method for account ownership or data derivation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VerificationMethod {
    /// Account email matches a known entity's email.
    EmailLinked,
    /// Platform-native verification (checkmark, badge, official status).
    PlatformVerified,
    /// Activity proof: recent posts, followers, creation signals.
    ActivityProof,
    /// Self-disclosure: bio, pinned post, or explicit linking to other identity.
    SelfDisclosed,
    /// Account linked to another entity's profile.
    LinkedProfile,
    /// Unverified handle enumeration (present on platform, ownership unknown).
    Unverified,
}

/// A single piece of evidence attached to an entity.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Evidence {
    /// Module that produced this evidence.
    pub source: String,
    /// Human-readable summary / label for the record (not the raw data itself).
    pub summary: String,
    /// Raw key/value pairs from the module — the FULL source record, preserved
    /// verbatim for traceability (operator full-fidelity policy: nothing
    /// redacted or omitted, credentials included). The canonical leaked
    /// secret is additionally surfaced as a first-class `Password`/`Credential`
    /// entity so it is searchable and expandable, not just an attribute.
    /// `BTreeMap` (not `HashMap`) so the serialised evidence has a stable,
    /// sorted key order — identical findings must produce byte-identical JSON
    /// (reproducibility / hashable evidence chains), and HashMap iteration order
    /// is randomised per instance.
    #[serde(default)]
    pub attributes: BTreeMap<String, String>,
    /// Unix timestamp (seconds) when evidence was recorded.
    pub recorded_at: u64,
    /// Verification status for account/handle ownership. None if not applicable.
    /// Marked at evidence creation and propagated through correlations to gate
    /// account-attribution rules — prevents unverified accounts from being linked
    /// to persons.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub verification: Option<VerificationMethod>,
    /// True if this evidence represents a derivation or inference rather than
    /// a direct observation. Inferred data (e.g., names permuted from usernames,
    /// coordinates calculated from addresses) must be confidence-capped below HIGH
    /// and should decay confidence in downstream correlations.
    #[serde(default, skip_serializing_if = "is_false")]
    pub is_inferred: bool,
    /// Id of the scan that produced this evidence. Backfilled from the owning
    /// entity in `Entity::add_evidence` when not set explicitly, so per-record
    /// provenance survives multi-scan merges. Empty for old persisted records
    /// (pre-dates this field).
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub scan_id: String,
}

impl Evidence {
    pub fn new(source: impl Into<String>, summary: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            summary: summary.into(),
            attributes: BTreeMap::new(),
            recorded_at: unix_now(),
            verification: None,
            is_inferred: false,
            scan_id: String::new(),
        }
    }

    /// Attach a key/value attribute, **accumulating** rather than clobbering
    /// when the key is already present.
    ///
    /// Operator full-fidelity policy: a repeated key must not silently lose its
    /// earlier value — e.g. several breach rows folded into one evidence record,
    /// each carrying a different `gender`, `date_of_birth`, or `country`. On
    /// collision the new value is appended after `"; "`, **de-duplicated** so
    /// re-asserting an identical value is idempotent and the merged cell never
    /// bloats with repeats. The first-seen value stays first and single-set
    /// callers — the overwhelming majority — are byte-for-byte unchanged.
    pub fn with_attr(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        let key = key.into();
        let value = value.into();
        match self.attributes.get_mut(&key) {
            Some(existing) => {
                if !existing.split("; ").any(|seen| seen == value) {
                    existing.push_str("; ");
                    existing.push_str(&value);
                }
            }
            None => {
                self.attributes.insert(key, value);
            }
        }
        self
    }

    /// Attach several **optional** attributes in one call: each pair whose value
    /// is `Some` and trims to a non-empty string is added via
    /// [`with_attr`](Self::with_attr) (so its accumulate-on-collision semantics
    /// are unchanged); `None` or blank values are skipped. The single authority
    /// for the "conditionally add each trimmed non-empty attribute" idiom the
    /// leak-site / BSSID collector modules build multi-attribute evidence with,
    /// replacing the hand-rolled `for (k, v) in [...] { if let Some(v) =
    /// v.map(str::trim).filter(...) { ev = ev.with_attr(k, v); } }` loop each had
    /// copied verbatim.
    pub fn with_optional_attrs<'a>(
        mut self,
        attrs: impl IntoIterator<Item = (&'a str, Option<&'a str>)>,
    ) -> Self {
        for (k, v) in attrs {
            if let Some(v) = v.map(str::trim).filter(|s| !s.is_empty()) {
                self = self.with_attr(k, v);
            }
        }
        self
    }

    /// The individual values behind `key` — the **inverse of
    /// [`with_attr`](Self::with_attr)'s accumulation**, and the only correct way
    /// to read an attribute that can hold more than one.
    ///
    /// Both [`with_attr`](Self::with_attr) and `merge_evidence_attrs` join
    /// colliding values with `"; "`, so a key that looks single-valued at the
    /// call site can hold `"alice; bob_work"` by the time a rule reads it — two
    /// breach rows from ONE corpus mint two same-UID entities, and `absorb`
    /// deduplicates their evidence by `(source, summary)` into a single record.
    /// A consumer that reads `attributes.get(key)` whole then sees ONE opaque
    /// string: identity rules counting distinct accounts silently count 1 where
    /// there are 2, and their firing gate can never be met.
    ///
    /// Yields trimmed, non-empty parts; absent keys yield nothing.
    ///
    /// ```
    /// use hse_core::Evidence;
    ///
    /// let ev = Evidence::new("oathnet", "Breach on ForumX")
    ///     .with_attr("username", "alice")
    ///     .with_attr("username", "bob_work");
    /// assert_eq!(ev.attr_values("username").collect::<Vec<_>>(), ["alice", "bob_work"]);
    /// assert_eq!(ev.attr_values("absent").count(), 0);
    /// ```
    pub fn attr_values<'a>(&'a self, key: &str) -> impl Iterator<Item = &'a str> + 'a {
        self.attributes
            .get(key)
            .into_iter()
            .flat_map(|v| v.split("; "))
            .map(str::trim)
            .filter(|s| !s.is_empty())
    }

    /// Set the verification status for this evidence (used to mark account ownership verification).
    pub fn with_verification(mut self, v: VerificationMethod) -> Self {
        self.verification = Some(v);
        self
    }

    /// Mark this evidence as inferred/derived rather than directly observed.
    pub fn with_inferred(mut self, inferred: bool) -> Self {
        self.is_inferred = inferred;
        self
    }
}

/// Helper for serde skip_serializing_if on bool false values.
fn is_false(b: &bool) -> bool {
    !b
}

// ─── Entity ───────────────────────────────────────────────────────────────────

/// Core HSE entity.
///
/// # UID derivation
/// `uid = hex(SHA-256(kind_str + ":" + value_normalised))`
///
/// # Confidence formula
/// `C_eff = clamp(max(confidence × (1 + 0.15·ln n), 1 − (1−confidence)·0.65^(n−1)), 0, 1)`,
/// where `n = source_count()` — the count of DISTINCT corroborating sources,
/// floored at 1. **Not** the raw `corroboration` field below, which is a
/// separate summed observation magnitude that never drives `C_eff` directly.
/// See [`Entity::c_effective`] and [`Entity::source_count`].
///
/// # GREATEST-semantics merge
/// `confidence` and `corroboration` only ever increase during merge.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entity {
    /// Deterministic SHA-256 UID.
    pub uid: String,
    /// Value kind.
    pub kind: EntityKind,
    /// Normalised canonical value.
    pub value: String,
    /// Raw / display value (may differ from normalised).
    pub raw_value: String,
    /// Base confidence ∈ [0, 1].
    pub confidence: f64,
    /// Raw observation-magnitude counter (≥ 1): seeded per-module (e.g. a
    /// breach-count, an engine-agreement count) and summed on every
    /// GREATEST-semantics merge via [`Self::absorb`] — never deduplicated by
    /// source. **This is not a count of independent sources** and does not
    /// drive [`Self::c_effective`]; that uses [`Self::source_count`] instead.
    /// Retained as a ranking/diagnostics signal (see its doc comment for why).
    pub corroboration: u32,
    /// Decay timestamp (Unix seconds). Used to compute time-decay.
    pub observed_at: u64,
    /// Evidence chain (append-only via `add_evidence`).
    pub evidence: Vec<Evidence>,
    /// Arbitrary tag bag (e.g. "au:breach", "geoint").
    #[serde(default)]
    pub tags: Vec<String>,
    /// Scan ID this entity was first seen in.
    pub scan_id: String,
    /// Expansion **generation**: how many recursive expansion rounds from the
    /// seed this entity was first discovered — its distance, in pivots, from the
    /// queried subject. `0` = the seed round (found directly by scanning the
    /// subject), `N` = surfaced by pivoting on a generation-`N-1` entity, i.e.
    /// `N` hops out along its derivation trail. Engine-assigned (modules always
    /// create at `0`); the engine stamps a genuinely-new entity with the round
    /// it was born in, and `merge` preserves the EARLIEST generation an entity
    /// entered the graph at. Rides in `data_json` — old rows deserialize to `0`
    /// via `#[serde(default)]`, so no storage migration is needed.
    #[serde(default)]
    pub generation: u32,
}

impl Entity {
    // ── Construction ────────────────────────────────────────────────────────

    /// Create a new entity. `confidence` is clamped to [0, 1].
    pub fn new(
        kind: EntityKind,
        value: impl Into<String>,
        confidence: f64,
        scan_id: impl Into<String>,
    ) -> Self {
        let value = value.into();
        let normalised = normalise(&kind, &value);
        let uid = derive_uid(&kind, &normalised);
        Self {
            uid,
            kind,
            value: normalised,
            raw_value: value,
            // `f64::clamp` returns NaN UNCHANGED, so a non-finite confidence would
            // slip through and violate the frontier's total-order determinism
            // (confidence → depth → id) and the saturating `c_effective()` model
            // (which multiplies through it). Sanitize a non-finite input to 0.0.
            confidence: if confidence.is_finite() {
                confidence.clamp(0.0, 1.0)
            } else {
                0.0
            },
            corroboration: 1,
            observed_at: unix_now(),
            evidence: Vec::new(),
            tags: Vec::new(),
            scan_id: scan_id.into(),
            // Modules never know their expansion round, so every freshly-built
            // entity starts at the seed generation; the engine re-stamps a
            // genuinely-new entity with the round it was actually born in.
            generation: 0,
        }
    }

    // ── Derived metrics ──────────────────────────────────────────────────────

    /// Number of DISTINCT corroborating sources backing this entity — the
    /// true cross-correlation signal that drives the C_eff boost.
    ///
    /// This is `corroborating_sources().len()` — the same grounded set (distinct
    /// `evidence.source` strings minus the non-corroborating passes, with the
    /// same promotion-source grounding gate), computed here without allocating a
    /// `HashSet` — floored at 1. When no corroborating evidence is attached
    /// (synthetic/test
    /// entities, an entity constructed before its evidence, or one carrying only
    /// enrichment evidence) it falls back to the stored `corroboration` field so
    /// an explicitly-set strength value is still honoured.
    ///
    /// Why not the `corroboration` field directly: that field is the summed
    /// *observation magnitude* (e.g. hibp seeds it with verified-breach count,
    /// search_engines with engine-agreement count, and `merge()` adds them).
    /// Summed within-module counts are NOT a count of independent sources, so
    /// using them to boost C_eff over-credited single-source findings (a 5-breach
    /// hibp hit looked like "5 independent sources"). The distinct-source count
    /// is the honest cross-correlation measure — and is already the signal used
    /// by the expansion gate, the diagnostics diversity floor, and 6 correlator
    /// rules. The `corroboration` field is retained as the observation-magnitude
    /// signal for ranking/diagnostics; it no longer drives C_eff.
    #[inline]
    pub fn source_count(&self) -> u32 {
        // Count DISTINCT corroborating sources WITHOUT allocating a `HashSet`.
        // This runs for every entity on the merge/dedup hot path (via
        // `c_effective`/`classify`), so the previous `corroborating_sources().len()`
        // — which built and dropped a `HashSet<&str>` on every call — was pure
        // overhead. A source is counted exactly once, at its first occurrence:
        // for each record we scan only the evidence *before* it for the same
        // source. Entity evidence chains are short (a handful of sources), so
        // this O(k²) scan over tiny `k` beats hashing + heap allocation.
        //
        // GROUNDING GATE: promotion-pass sources (`multipath_corroboration`,
        // `cross_scan_corroboration`) are tracked separately and only COUNT
        // when the entity is already independently grounded. They re-fire every
        // scan, so a value the engine merely DERIVED (a name→email permutation,
        // an inferred handle — the `derived` tag) whose lone real source is its
        // own generator must NOT be lifted into apparent cross-source agreement.
        // Gate: for observed entities (no `derived` tag) 1 real source suffices;
        // for derived entities we require ≥2 real (corroborating, non-promotion)
        // sources before promotion counts. If the generator is itself
        // non-corroborating (e.g. `name_intel`), it does not contribute to
        // `real`, so external confirmation is needed regardless.
        let derived = self.has_tag(tags::DERIVED);
        let mut real: u32 = 0;
        let mut promo: u32 = 0;
        for (i, ev) in self.evidence.iter().enumerate() {
            let s = ev.source.as_str();
            if is_non_corroborating_source(s) {
                continue;
            }
            if self.evidence[..i]
                .iter()
                .any(|prev| prev.source == ev.source)
            {
                continue; // duplicate source — only count first occurrence
            }
            if is_promotion_source(s) {
                promo += 1;
            } else {
                real += 1;
            }
        }
        // For observed entities: 1 real source satisfies the gate.
        // For derived entities: need ≥2 real corroborating sources before
        // promotion passes count. Non-corroborating generators (e.g. `name_intel`)
        // do not contribute to `real`, so they do not satisfy the gate alone.
        let grounded = real >= if derived { 2 } else { 1 };
        let distinct = real + if grounded { promo } else { 0 };
        if distinct > 0 {
            // Evidence is attached: distinct *corroborating* sources is the
            // authoritative cross-correlation count. The summed `corroboration`
            // magnitude is deliberately NOT allowed to inflate it (that was the
            // original bug), and deterministic self-enrichment passes
            // (`geo_normalize`) are excluded so they can't fabricate agreement.
            distinct
        } else if self.evidence.is_empty() {
            // No evidence at all (synthetic/test entity, or constructed
            // pre-evidence): fall back to the explicitly-set field so a
            // deliberate strength value is still honoured.
            self.corroboration.max(1)
        } else {
            // Evidence EXISTS but every record is non-corroborating — a
            // deterministic enrichment pass (`geo_normalize`/`name_intel`) and/or
            // a `recall` replay. Such an entity is NOT cross-corroborated, so it
            // counts as ONE source. The stored `corroboration` magnitude must NOT
            // resurrect it: recall ratchets that field up by one every re-scan,
            // and a live scan was using it to lift a speculative name-permuted
            // email (`cindy.haynes@gmail.com`, only `name_intel` + `recall`) to
            // VERIFIED (C_eff 0.81) with zero real-world confirmation. A genuine
            // hit attaches a corroborating source and takes the `distinct` branch.
            1
        }
    }

    /// Cross-source effective confidence — the stronger of two models over the
    /// number of DISTINCT corroborating sources `n` (see [`Self::source_count`],
    /// floored at 1):
    ///
    /// * **Multiplicative** (legacy): `confidence × (1 + 0.15·ln n)` — a gentle,
    ///   sharply-diminishing boost.
    /// * **Independent-agreement** (noisy-OR): `1 − (1 − confidence)·γ^(n−1)`
    ///   with `γ = `[`CORROBORATION_DOUBT_DECAY`] — each *additional* independent
    ///   source shrinks the residual doubt, so N sources agreeing on a finding
    ///   drive confidence toward certainty.
    ///
    /// `C_eff = clamp(max(multiplicative, agreement), 0, 1)`.
    ///
    /// At `n = 1` both models equal `confidence`, so a single-source entity is
    /// unchanged. The agreement term is what gives genuine cross-correlation its
    /// due: the multiplicative model alone caps four independent confirmations of
    /// a moderate (C=0.6) finding at 0.73 ("Probable"); the agreement term lifts
    /// it to ~0.89 ("Verified"), which is what four independent sources warrant.
    /// `max` keeps the result monotonic and never below the legacy value, so the
    /// change only ever *adds* confidence for genuinely multi-sourced entities.
    ///
    /// ```
    /// use hse_core::{Entity, EntityKind};
    ///
    /// // Single source (no evidence attached → n = 1): C_eff equals confidence.
    /// let e = Entity::new(EntityKind::Email, "x@example.com", 0.6, "scan");
    /// assert_eq!(e.source_count(), 1);
    /// assert!((e.c_effective() - 0.6).abs() < 1e-9);
    /// ```
    #[inline]
    pub fn c_effective(&self) -> f64 {
        self.c_effective_with_source_count(self.source_count())
    }

    /// [`Self::c_effective`] computed from an already-known distinct-corroborating
    /// source count `n`. Callers that have already paid for [`Self::source_count`]
    /// — itself an O(k²) scan of the evidence chain — pass it here instead of
    /// forcing a recompute. `c_effective()` is exactly
    /// `c_effective_with_source_count(self.source_count())`, so the C_eff formula
    /// is single-sourced and the two can never drift apart.
    #[inline]
    pub fn c_effective_with_source_count(&self, n: u32) -> f64 {
        // Floor the source count at 1: a lone observation IS one source, and
        // [`Self::source_count`] already never yields 0. Guarding here makes this
        // public method TOTAL — without it, `n = 0` drives `ln(0) = -inf` (and
        // `γ^(n-1) = γ^-1`) and returns a value BELOW the base `confidence` (or a
        // NaN when `confidence == 0`), violating the model's `C_eff ≥ confidence`,
        // bounded-`[0,1]` invariant. At the floored `n = 1` both terms equal
        // `confidence`, so corroboration can only ever ADD confidence, never
        // subtract it.
        let n = f64::from(n.max(1));
        let multiplicative = self.confidence * CORROBORATION_COEFF.mul_add(n.ln(), 1.0);
        let residual_doubt = (1.0 - self.confidence) * CORROBORATION_DOUBT_DECAY.powf(n - 1.0);
        let agreement = 1.0 - residual_doubt;
        multiplicative.max(agreement).clamp(0.0, 1.0)
    }

    /// [`Self::c_effective`] discounted by expansion **depth-decay**: each
    /// generation (pivot) away from the seed multiplies confidence by `base`
    /// (`0 < base ≤ 1`), so a finding `N` hops out is scaled by `base^N`. A
    /// gen-0 (seed-round) entity is unchanged (`base^0 = 1`), and `base = 1.0`
    /// is a total no-op at any depth. Models the intuition that every pivot adds
    /// drift, so seed-adjacent leads are inherently more trustworthy than ones
    /// reached far down a chain of pivots.
    ///
    /// Pure; `base` is supplied by the caller. Only consulted when the opt-in
    /// `feature.depth_decay` expansion policy is enabled (default off), so the
    /// raw [`Self::c_effective`] every correlation/display/gate reads is
    /// untouched unless an operator deliberately turns the policy on.
    #[inline]
    pub fn c_effective_depth_decayed(&self, base: f64) -> f64 {
        (self.c_effective() * base.powf(f64::from(self.generation))).clamp(0.0, 1.0)
    }

    /// Derived classification tier from [`Self::c_effective`]: `Verified` at
    /// ≥ [`Classification::VERIFIED_MIN`] (0.75), `Probable` at ≥
    /// [`Classification::PROBABLE_MIN`] (0.40), else `Candidate`.
    ///
    /// Never stored — always recomputed, so a tier can only ever rise as merges
    /// add corroboration.
    ///
    /// ```
    /// use hse_core::{Classification, Entity, EntityKind};
    ///
    /// let mk = |c| Entity::new(EntityKind::Email, "x@example.com", c, "scan").classify();
    /// assert_eq!(mk(0.90), Classification::Verified);
    /// assert_eq!(mk(0.50), Classification::Probable);
    /// assert_eq!(mk(0.20), Classification::Candidate);
    /// ```
    #[inline]
    pub fn classify(&self) -> Classification {
        Classification::from_c_eff(self.c_effective())
    }

    /// The entity's current confidence tier — alias for [`Self::classify`] that
    /// names the role the value is intended to play in a tier-aware bounded
    /// best-first expansion (key the visited-set on `(target, tier_rank)` and
    /// re-queue at most once per tier when a merge lifts the entity).
    ///
    /// NOTE (current state): the live engine does not yet key its visited-set
    /// on tier or re-queue on graduation — see [`Classification::rank`]. This
    /// alias documents intent and is used by ranking/tests today.
    #[inline]
    pub fn tier(&self) -> Classification {
        self.classify()
    }

    /// Apply gamma-decay over elapsed time since `observed_at`.
    ///
    /// Returns the decayed confidence without mutating. Use `apply_decay()`
    /// to mutate in place.
    pub fn decayed_confidence(&self) -> f64 {
        let now = unix_now();
        let hours_elapsed = (now.saturating_sub(self.observed_at)) as f64 / 3600.0;
        (self.confidence * GAMMA_PER_HOUR.powf(hours_elapsed)).clamp(0.0, 1.0)
    }

    /// Mutate confidence in place using gamma decay.
    pub fn apply_decay(&mut self) {
        self.confidence = self.decayed_confidence();
    }

    // ── Evidence ────────────────────────────────────────────────────────────

    /// Append evidence. Passwords must be stripped before calling.
    ///
    /// Backfills `scan_id` from the owning entity when the evidence wasn't
    /// stamped with one, so per-record provenance survives multi-scan merges.
    pub fn add_evidence(&mut self, mut ev: Evidence) {
        if ev.scan_id.is_empty() {
            ev.scan_id = self.scan_id.clone();
        }
        self.evidence.push(ev);
    }

    // ── Tags ────────────────────────────────────────────────────────────────

    pub fn tag(&mut self, t: impl Into<String>) {
        let t = t.into();
        if !self.tags.contains(&t) {
            self.tags.push(t);
        }
    }

    /// Quarantine this entity into the `Candidate` tier: cap its confidence at
    /// [`CANDIDATE_CONF`] and stamp the `candidate` tag. Idempotent (the tag
    /// de-dupes; the cap is a `min`). The single, orthogonal definition of "this
    /// finding doesn't identify the subject, keep it but out of the
    /// full-confidence view" — applied by every breach/stealer pool
    /// (`oathnet_pro`, `see_know`) to rows a `util::target_match::TargetMatch`
    /// classified as a non-match, so the demotion semantics can never drift
    /// between them.
    pub fn demote_to_candidate(&mut self) {
        self.confidence = self.confidence.min(CANDIDATE_CONF);
        self.tag(tags::CANDIDATE);
    }

    pub fn has_tag(&self, t: &str) -> bool {
        self.tags.iter().any(|x| x == t)
    }

    /// True when this entity was extracted *only* from search-snippet recycling
    /// and nothing else has confirmed it — the lowest-reliability discovery path
    /// (a value scraped from the text of whatever page a search engine returned
    /// for a recycled query). The expansion planner uses this to record such a
    /// value as a lead without burning a recursion round pivoting on it: one
    /// independent corroborating source lifts [`Self::source_count`] past 1 and
    /// the entity expands normally. See the `uncorroborated_recycled` gate in
    /// the engine's expansion loop.
    #[inline]
    pub fn is_uncorroborated_recycled(&self) -> bool {
        self.has_tag(tags::RECYCLED) && self.source_count() < 2
    }

    /// True for a speculative identifier *permuted from the subject's name*
    /// (`name_intel`'s `name-derived` email/username guesses, e.g.
    /// `firstname.lastname@provider`) that no *reliable* independent source has
    /// yet corroborated.
    ///
    /// This is the predicate behind the **opt-in** `--gate-speculative` sweep —
    /// it is NOT applied by default. By default these permutations expand and get
    /// validated, because they are frequently the subject's REAL accounts and
    /// pivoting is exactly what confirms which are real. The operator opts in only
    /// when a name collides with many namesakes and the speculative fan-out (one
    /// name → dozens of unconfirmed permutations, each searched) costs more than
    /// it's worth; then the lead is recorded but not pivoted until confirmed.
    ///
    /// A breach / registry / profile source counts as corroboration — but two
    /// source classes deliberately do NOT, so the gate can't be defeated trivially
    /// when it is enabled:
    ///   * `name_intel`'s own derivation and `recall` (the enrichment /
    ///     non-corroborating passes), and
    ///   * a bare `search_engines` snippet hit — search is asked to look up the
    ///     very permutation it then "confirms" (circular), and a guessed name
    ///     string in a result page is as likely a namesake / people-search
    ///     aggregator as the subject (the same low-reliability path the recycled
    ///     gate already distrusts).
    ///
    /// (Even with the opt-in gate on, `--expand-all-identities` / `--full` force
    /// the exhaustive sweep.) Cheap: short-circuits on the first reliable source,
    /// no allocation.
    pub fn is_uncorroborated_name_permutation(&self) -> bool {
        self.has_tag(tags::NAME_DERIVED)
            && !self.evidence.iter().any(|ev| {
                let s = ev.source.as_str();
                !is_non_corroborating_source(s) && s != "search_engines"
            })
    }

    // ── Evidence helpers ────────────────────────────────────────────────────

    pub fn evidence_sources(&self) -> std::collections::HashSet<&str> {
        self.evidence.iter().map(|ev| ev.source.as_str()).collect()
    }

    /// Distinct evidence sources that represent *independent* intelligence —
    /// [`Self::evidence_sources`] minus the non-corroborating passes (the
    /// deterministic self-enrichment ones in [`ENRICHMENT_ONLY_SOURCES`] and the
    /// [`RECALL_SOURCE`] memory replay; see [`is_non_corroborating_source`]). This
    /// is the honest cross-correlation set that drives
    /// [`Self::source_count`]/[`Self::c_effective`] and the corroboration
    /// correlator rules; the full [`Self::evidence_sources`] set is retained for
    /// display and attribute access.
    pub fn corroborating_sources(&self) -> std::collections::HashSet<&str> {
        // GROUNDING GATE — identical to the one [`Self::source_count`] applies,
        // so the SET and the COUNT can never disagree about whether an entity is
        // independently corroborated. Promotion passes
        // (`multipath_corroboration`, `cross_scan_corroboration`) re-fire every
        // scan and must never GROUND an entity by themselves (see
        // [`is_promotion_source`]): they join the set only once the entity
        // already holds enough REAL sources — 1 normally, 2 when it is `derived`
        // (its lone real source is its own generator). Before this gate lived
        // here, ~20 correlator/engine gates keyed on this set counted a
        // promotion pass as an independent observation while `source_count`
        // (correctly) did not.
        let derived = self.has_tag(tags::DERIVED);
        let mut real: std::collections::HashSet<&str> = std::collections::HashSet::new();
        let mut promo: std::collections::HashSet<&str> = std::collections::HashSet::new();
        for ev in &self.evidence {
            let s = ev.source.as_str();
            if is_non_corroborating_source(s) {
                continue;
            }
            if is_promotion_source(s) {
                promo.insert(s);
            } else {
                real.insert(s);
            }
        }
        if real.len() >= if derived { 2 } else { 1 } {
            real.extend(promo);
        }
        real
    }

    /// The set of DISTINCT corroborating evidence *records* — `(source, summary)`
    /// pairs whose source counts toward corroboration (see
    /// [`is_non_corroborating_source`]). Unlike [`Self::corroborating_sources`],
    /// which collapses every record to the bare source NAME, this keeps
    /// per-record granularity: two entities share a record only when the same
    /// source produced the *same finding* for both.
    ///
    /// This is the correct key for **co-occurrence** (does an independent source
    /// name entities A and B *together*?). Keying co-occurrence on the source
    /// name alone conflates genuine joint sightings with one-to-many *fan-out
    /// enumeration*: a module like `username_search` probes a single handle
    /// across dozens of platforms and attaches a distinct per-platform summary
    /// (`"@h has a profile on Threads"`, `"… on OnlyFans"`, …) to a separate
    /// entity each — independent existence-proofs of one selector, not a shared
    /// sighting. Under the name-level key those N entities collapse to one shared
    /// `username_search` source and wire into a false N-clique; under the
    /// record-level key their summaries differ, so no spurious edge is drawn. A
    /// genuine joint record (both selectors in the *same* breach — identical
    /// `("hibp", "Breach 'Apollo'")` — or on the same crawled page) is shared
    /// verbatim, so the real co-occurrence edge survives.
    pub fn corroborating_records(&self) -> std::collections::HashSet<(&str, &str)> {
        self.evidence
            .iter()
            .filter(|ev| !is_non_corroborating_source(&ev.source))
            .map(|ev| (ev.source.as_str(), ev.summary.as_str()))
            .collect()
    }

    pub fn has_evidence_from(&self, source: &str) -> bool {
        self.evidence.iter().any(|ev| ev.source == source)
    }

    // ── GREATEST-semantics merge ─────────────────────────────────────────────

    /// Put this entity's evidence and tags into a deterministic order so the
    /// PERSISTED/EXPORTED result does not depend on the order modules happened to
    /// run in. Concurrent dispatch (the default, `max_concurrent > 0`) merges
    /// module results in completion order, which would otherwise leak into the
    /// evidence/tags ordering of the stored entity and make two runs' dossiers
    /// differ for no real reason (Determinism Requirement). Evidence is sorted by
    /// its dedup key — `(source, summary)`, already unique per entity — and tags
    /// lexicographically. Membership (`has_tag`) and the GREATEST
    /// confidence/corroboration are unaffected; only display/serialisation order
    /// is normalised. Called once per entity at scan finalisation, so it is not on
    /// the per-merge hot path.
    ///
    /// `raw_value` is likewise made order-independent by [`Entity::merge`],
    /// which keeps the lexicographically smaller spelling when two same-UID
    /// entities differ only in original casing/spacing (`Foo@Bar.com` vs
    /// `foo@bar.com`). Because `min` is commutative, the stored display value no
    /// longer depends on which module's result merged first.
    pub fn canonicalize_order(&mut self) {
        self.evidence.sort_by(|a, b| {
            a.source
                .cmp(&b.source)
                .then_with(|| a.summary.cmp(&b.summary))
        });
        self.tags.sort();
    }

    /// Merge `other` into `self` using GREATEST-semantics.
    ///
    /// This is the deduplication primitive: two entities with the same `uid`
    /// (same kind + normalised value) are folded so corroboration only ever
    /// grows — replaying the same finding never regresses confidence or drops
    /// evidence.
    ///
    /// Rules:
    /// - `uid` must match (debug-asserts; a mismatch is a no-op in release)
    /// - `confidence`  = max(self, other)        — never decreases
    /// - `corroboration` += other.corroboration  — only increases
    /// - `observed_at`  = max(self, other)        — most recent wins
    /// - `raw_value`    = min(self, other)        — deterministic display value
    /// - `generation`   = preserved (self's)      — earliest generation wins
    /// - `evidence` merged, de-duplicated by `(source, summary)`
    /// - `tags` unioned (de-duplicated)
    ///
    /// ```
    /// use hse_core::{Entity, EntityKind, Evidence};
    ///
    /// let mut a = Entity::new(EntityKind::Email, "x@example.com", 0.5, "scan");
    /// a.tag("breach");
    /// a.add_evidence(Evidence::new("hibp", "seen"));
    ///
    /// let mut b = Entity::new(EntityKind::Email, "X@Example.com", 0.9, "scan");
    /// b.tag("paste-exposed");
    /// b.add_evidence(Evidence::new("dehashed", "seen"));
    ///
    /// assert_eq!(a.uid, b.uid); // same kind + normalised value → same UID
    /// a.merge(b);
    /// assert_eq!(a.confidence, 0.9);    // GREATEST: confidence never decreases
    /// assert!(a.has_tag("breach") && a.has_tag("paste-exposed")); // tags unioned
    /// assert_eq!(a.evidence.len(), 2);  // distinct evidence both kept
    /// ```
    pub fn merge(&mut self, mut other: Self) {
        debug_assert_eq!(self.uid, other.uid, "merge: UID mismatch");
        if self.uid != other.uid {
            return;
        }
        // Canonical PROVENANCE spelling: the lexicographically smaller raw_value,
        // so the as-supplied string a source sent is independent of merge order.
        // Two modules can emit the same value with different original
        // casing/spacing ("Foo@Bar.com" vs "foo@bar.com" — both normalise to one
        // UID); under the default concurrent dispatch, results merge in
        // completion order, so keeping `self`'s would leak that order into the
        // persisted dossier (Determinism Requirement). `min` is commutative, so
        // any merge order — and any pairing — yields the same raw_value. `other`
        // is consumed by `absorb`, so swap the smaller spelling out rather than
        // cloning it.
        if other.raw_value < self.raw_value {
            std::mem::swap(&mut self.raw_value, &mut other.raw_value);
        }
        // Canonical DISPLAY value, under the same Determinism Requirement.
        // `identity_fold` makes `uid` insensitive to case and whitespace runs for
        // Person/Organisation while `normalise` leaves `value` alone, so those two
        // kinds are the only ones where same-UID observations can disagree on
        // `value` — and until this swap existed, which spelling survived was
        // decided by module completion order. That leaked into the exported
        // dossier AND into the `value` column every `q=` filter matches on, so one
        // scan run could find the subject by name and the next could not. Every
        // other kind folds inside `normalise`, so same UID implies an identical
        // `value` and this is a no-op for them.
        if prefers_display(&other.value, &self.value) {
            std::mem::swap(&mut self.value, &mut other.value);
        }
        self.absorb(other);
    }

    /// Fold another entity's corroborating **signal** into this one — confidence
    /// (max), corroboration (sum), recency (max), deduplicated evidence and tags
    /// — without touching identity (`uid`/`value`/`raw_value`).
    ///
    /// Note the division of labour: [`merge`](Self::merge) canonicalises the two
    /// spelling fields (`raw_value`, `value`) BEFORE delegating here, so this
    /// function can treat all three identity fields as settled and fold only
    /// signal.
    ///
    /// This is the identity-preserving core of [`merge`](Self::merge), exposed
    /// for the rare case of intentionally combining two entities with DIFFERENT
    /// UIDs that nonetheless denote the same real-world thing — e.g. collapsing
    /// `Address` entities for one locality (`"X, NSW"` and `"X, NSW 2582"`),
    /// which `merge` would refuse because their UIDs differ. The caller is
    /// responsible for having decided the two are the same; `absorb` only fuses
    /// their evidence. Commutative in confidence/corroboration/evidence/tags, so
    /// folding a group in any order yields the same result.
    // Was `pub(crate)` before extraction (called by core::engine::passes);
    // see uid_for's comment above on why a crate boundary widens this to `pub`.
    pub fn absorb(&mut self, other: Self) {
        self.confidence = f64::max(self.confidence, other.confidence).clamp(0.0, 1.0);
        self.corroboration = self
            .corroboration
            .saturating_add(other.corroboration)
            .max(1);
        self.observed_at = u64::max(self.observed_at, other.observed_at);
        // `generation` is deliberately NOT merged here: it is engine-assigned in
        // monotonic round order (a genuinely-new entity is stamped with the round
        // it was born in AFTER insertion), while every module-built `other` still
        // carries the meaningless default `0`. Taking a min would let a later
        // round's re-emission (`other.generation == 0`) reset an existing entity's
        // real generation back to the seed. Keeping `self`'s value preserves the
        // earliest generation the entity actually entered the graph — the invariant the
        // engine relies on (merges only ever fold `other` INTO the pre-existing,
        // earlier-or-equal entity).
        // Deduplicate evidence by (source, summary) to prevent accumulation
        // across live mode iterations or re-scans — a repeated observation by the
        // SAME source with the SAME summary is the same record, not new
        // corroboration. BUT it may carry attributes the existing record lacks
        // (an updated breach dump, a richer re-scan), so on a match MERGE the new
        // attributes in rather than dropping the record: dropping it silently
        // loses newly-discovered fields (a live re-import that gained a
        // `date_of_birth`/`tfn` between scans, exactly the case the breach-PII
        // rules depend on). [`merge_evidence_attrs`] keeps the fold deterministic
        // (smaller value wins a key conflict) and idempotent. Small inputs (the
        // overwhelming common case — a handful of rows) use a linear find; large
        // ones use a `(source, summary)→index` map so the fold stays linear under
        // re-scan / live-mode accumulation. Both branches yield identical results.
        if self.evidence.len() * other.evidence.len() <= 256 {
            for ev in other.evidence {
                match self
                    .evidence
                    .iter_mut()
                    .find(|e| e.source == ev.source && e.summary == ev.summary)
                {
                    Some(existing) => merge_evidence_attrs(existing, ev),
                    None => self.evidence.push(ev),
                }
            }
        } else {
            // Index compact identity fingerprints instead of cloning every source
            // and summary. Each bucket retains all matching indices and the lookup
            // verifies the original strings, so hash collisions cannot merge
            // unrelated evidence.
            let identity_hash_builder = RandomState::new();
            // Existing rows establish the minimum useful capacity. Incoming rows
            // grow the map only when they introduce unique identities, avoiding
            // an upper-bound allocation when a batch is mostly duplicates.
            let mut index: HashMap<u64, EvidenceIdentityBucket> =
                HashMap::with_capacity(self.evidence.len());
            for (i, evidence) in self.evidence.iter().enumerate() {
                index
                    .entry(evidence_identity_hash(
                        &identity_hash_builder,
                        &evidence.source,
                        &evidence.summary,
                    ))
                    .and_modify(|bucket| bucket.push(i))
                    .or_insert_with(|| EvidenceIdentityBucket::new(i));
            }
            self.evidence.reserve(other.evidence.len());
            for ev in other.evidence {
                let identity_hash =
                    evidence_identity_hash(&identity_hash_builder, &ev.source, &ev.summary);
                // A randomized 64-bit fingerprint makes multi-entry buckets
                // exceptional; the exact comparison is the collision-safe path.
                let existing_index = index.get(&identity_hash).and_then(|bucket| {
                    bucket.indices().find(|&i| {
                        self.evidence[i].source == ev.source
                            && self.evidence[i].summary == ev.summary
                    })
                });
                match existing_index {
                    Some(i) => merge_evidence_attrs(&mut self.evidence[i], ev),
                    None => {
                        index
                            .entry(identity_hash)
                            .and_modify(|bucket| bucket.push(self.evidence.len()))
                            .or_insert_with(|| EvidenceIdentityBucket::new(self.evidence.len()));
                        self.evidence.push(ev);
                    }
                }
            }
        }
        // `candidate` is a confidence-TIER quarantine stamped by
        // `demote_to_candidate`, not an accumulating multi-source label like an
        // ordinary tag — every default view filters entities purely on this tag
        // (`api::scan_export`, `api::scan_handlers::analysis`), so blindly
        // unioning it would let a stranger's non-matching, low-confidence
        // observation of the SAME uid silently quarantine an otherwise-verified
        // entity. Confidence already resolves to the max of the two sides
        // above; tag status must track that: skip carrying the tag itself over
        // in the general union below, then promote `self` out of quarantine
        // the moment `other` was NOT itself a candidate — a single non-candidate
        // corroboration is enough, symmetric with the confidence rule.
        let other_is_candidate = other.tags.iter().any(|t| t == tags::CANDIDATE);
        // `derived` marks an entity whose OWN evidence is a deterministic
        // derivation of the seed (see `ENRICHMENT_ONLY_SOURCES`'s doc),
        // consulted fresh on every call by `source_count`'s GROUNDING GATE to
        // require a stricter 2-real-source bar before a promotion pass counts.
        // Like `candidate` above, it must not be a plain accumulating tag:
        // wholesale-unioning it let merging in an unrelated, low-value derived
        // duplicate (contributing NOTHING to real evidence — e.g. a
        // `name_intel`/`url_extract` restatement) retroactively raise an
        // ALREADY-grounded entity's gate threshold, dropping its
        // classification tier purely from absorbing MORE evidence — violating
        // this file's own "a tier can only ever rise as merges add
        // corroboration" invariant. Fixed the same way as `candidate`, but as
        // a logical AND rather than OR: exclude it from the general union
        // below, then keep it only when BOTH sides carried it, so a single
        // genuinely-independent (non-derived) side graduates the merged
        // entity out of the stricter gate for good — symmetric with a single
        // non-candidate side clearing quarantine.
        let other_is_derived = other.tags.iter().any(|t| t == tags::DERIVED);
        for t in other.tags {
            if t != tags::CANDIDATE && t != tags::DERIVED {
                self.tag(t);
            }
        }
        if !other_is_candidate {
            self.tags.retain(|t| t != tags::CANDIDATE);
        }
        if !other_is_derived {
            self.tags.retain(|t| t != tags::DERIVED);
        }
    }

    /// Start a fluent [`EntityBuilder`] for the common emission shape.
    ///
    /// Collapses the `Entity::new(kind, value, conf, scan_id)` + `tag(..)` +
    /// `add_evidence(..)` + `result.push(..)` scaffold that is copy-pasted at
    /// ~1000 sites across the module fleet (three modules had already grown
    /// their own private `build_entity` helpers). Purely additive: it wraps the
    /// existing constructor with identical semantics — confidence is still
    /// clamped by `Entity::new`, tags still de-dupe via `Entity::tag`, evidence
    /// order is preserved — so a builder-produced entity is byte-identical to
    /// the hand-rolled sequence, and hand-rolled sites keep compiling.
    ///
    /// ```ignore
    /// Entity::builder(EntityKind::Domain, host, confidence::HIGH, &ctx.scan_id)
    ///     .tag("archived")
    ///     .evidence(Evidence::new(SRC, summary).with_attr("k", "v"))
    ///     .push_to(&mut result);
    /// ```
    pub fn builder(
        kind: EntityKind,
        value: impl Into<String>,
        confidence: f64,
        scan_id: impl Into<String>,
    ) -> EntityBuilder {
        EntityBuilder {
            entity: Entity::new(kind, value, confidence, scan_id),
        }
    }
}

/// Fluent builder for the common entity-emission shape. Construct via
/// [`Entity::builder`]. Every method mirrors the equivalent `Entity` mutation
/// exactly, so the result is indistinguishable from building the entity by
/// hand — this is ergonomics, not new behaviour.
#[must_use = "an EntityBuilder does nothing until `.build()` or `.push_to(..)`"]
pub struct EntityBuilder {
    entity: Entity,
}

impl EntityBuilder {
    /// Add one tag (de-duped, exactly like [`Entity::tag`]).
    pub fn tag(mut self, t: impl Into<String>) -> Self {
        self.entity.tag(t);
        self
    }

    /// Add several tags in order.
    pub fn tags<I, S>(mut self, tags: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        for t in tags {
            self.entity.tag(t);
        }
        self
    }

    /// Append one piece of evidence (order-preserving, like
    /// [`Entity::add_evidence`]). Passwords must be stripped before calling,
    /// same contract as the underlying method.
    pub fn evidence(mut self, ev: Evidence) -> Self {
        self.entity.add_evidence(ev);
        self
    }

    /// Finish and return the built [`Entity`].
    #[must_use]
    pub fn build(self) -> Entity {
        self.entity
    }
}

/// Index bucket that stores the common single fingerprint match inline and
/// allocates only when a real hash collision creates additional candidates.
struct EvidenceIdentityBucket {
    first: usize,
    collisions: Vec<usize>,
}

impl EvidenceIdentityBucket {
    fn new(first: usize) -> Self {
        Self {
            first,
            collisions: Vec::new(),
        }
    }

    fn push(&mut self, index: usize) {
        self.collisions.push(index);
    }

    fn indices(&self) -> impl Iterator<Item = usize> + '_ {
        std::iter::once(self.first).chain(self.collisions.iter().copied())
    }
}

/// Compact fingerprint for an evidence `(source, summary)` identity.
///
/// The per-merge randomized state resists adversarial collision batches. Callers
/// must still resolve every collision by comparing both original strings.
fn evidence_identity_hash(state: &RandomState, source: &str, summary: &str) -> u64 {
    state.hash_one((source, summary))
}

/// Merge `incoming`'s attributes into `existing` — they are the same evidence
/// record (matching `(source, summary)`), so add the keys `existing` lacks and,
/// on a key both set with DIFFERING values, accumulate the distinct observations
/// as `"a; b"` rather than dropping one. A conflicting re-observation (a corrected
/// value, or a namesake's differing `date_of_birth` on the same breach source) is
/// itself evidence and must survive for the disambiguation rules to see it. This
/// matches [`Evidence::with_attr`]'s in-record accumulation — eliminating the
/// inconsistency where the public builder kept both and this absorb path kept one
/// — but the values are SORTED (via the set) rather than appended in arrival
/// order, so the fold stays independent of merge order (the Determinism
/// Requirement) where `with_attr`'s append would not be.
fn merge_evidence_attrs(existing: &mut Evidence, incoming: Evidence) {
    for (k, v) in incoming.attributes {
        match existing.attributes.get_mut(&k) {
            Some(cur) => {
                if cur != &v {
                    let mut parts: std::collections::BTreeSet<String> =
                        cur.split("; ").map(String::from).collect();
                    parts.extend(v.split("; ").map(String::from));
                    *cur = parts.into_iter().collect::<Vec<_>>().join("; ");
                }
            }
            None => {
                existing.attributes.insert(k, v);
            }
        }
    }
}

impl fmt::Display for Entity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "[{}] {} ({}) C={:.3} C_eff={:.3} corr={} → {}",
            self.kind,
            self.value,
            self.uid.get(..8).unwrap_or(&self.uid),
            self.confidence,
            self.c_effective(),
            self.corroboration,
            self.classify(),
        )
    }
}

// ─── EntityRef ───────────────────────────────────────────────────────────────

/// Lightweight handle referencing an entity by UID and kind.
/// Used in module I/O to avoid cloning full entities.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EntityRef {
    pub uid: String,
    pub kind: EntityKind,
    pub value: String,
}

impl From<&Entity> for EntityRef {
    fn from(e: &Entity) -> Self {
        Self {
            uid: e.uid.clone(),
            kind: e.kind.clone(),
            value: e.value.clone(),
        }
    }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/// Fold a normalised value into the form that defines **identity**, as distinct
/// from the form that is **displayed**.
///
/// For most kinds these coincide and this borrows unchanged. For free-text NAME
/// kinds they must not: a person's identity does not depend on the capitalisation
/// or the run of spaces a particular source happened to emit, but the display
/// value very much does — nobody wants a dossier headed `jeremy stewart`.
///
/// [`normalise`] cannot do this job, because its output IS the display value
/// (`Entity::value`). Its catch-all arm is `value.trim()`, so `Person` receives
/// no folding whatsoever, and three sightings of one person fork into three
/// graph nodes:
///
/// ```text
/// "Jeremy Stewart"    -> bf2bbc2d…
/// "jeremy stewart"    -> c9973045…
/// "Jeremy  Stewart"   -> f0523905…
/// ```
///
/// Each fragment carries only the evidence of the source that spelled it that
/// way, so `corroborated_fraction` — the share of entities backed by ≥2 distinct
/// sources — is structurally suppressed toward zero no matter how many sources
/// agree. A real 1081-entity dossier drawing on 11 sources reported **0%**
/// corroborated, and listed `Jeremy Stewart` and `jeremy stewart` as separate
/// co-reference endpoints. `derive_canonical_identities` papers over the split
/// with `SameAs` edges, but an edge between two half-evidenced nodes is not the
/// same thing as one fully-evidenced node.
///
/// Excluded on purpose:
/// * `Ssid` — Wi-Fi network names are case-SENSITIVE by IEEE 802.11; folding
///   them would merge two genuinely different networks.
/// * `Address` — real address equivalence needs component parsing
///   (`Street`/`St`, unit notation), not case folding. Folding case alone would
///   imply a normalisation that has not happened.
/// * Every identifier kind — `Email`, `Username`, `Domain`, `Phone`,
///   `IpAddress`, `MacAddress`, `Url`, `Coordinates` — already normalises to a
///   canonical form in [`normalise`], where identity and display legitimately
///   coincide. Their UIDs are byte-identical before and after this change.
fn identity_fold<'a>(kind: &EntityKind, normalised: &'a str) -> std::borrow::Cow<'a, str> {
    match kind {
        EntityKind::Person | EntityKind::Organisation => {
            // `split_whitespace` collapses runs AND trims, so "Jeremy  Stewart"
            // and " Jeremy Stewart " reach the same key as "Jeremy Stewart".
            let folded = normalised
                .split_whitespace()
                .collect::<Vec<_>>()
                .join(" ")
                .to_lowercase();
            if folded == normalised {
                std::borrow::Cow::Borrowed(normalised)
            } else {
                std::borrow::Cow::Owned(folded)
            }
        }
        _ => std::borrow::Cow::Borrowed(normalised),
    }
}

/// Rank a display spelling for canonical selection — **lower is preferred**.
///
/// [`identity_fold`] deliberately lets `Person`/`Organisation` share a UID across
/// case and whitespace variants, while [`normalise`] keeps each source's own
/// spelling in `value`. Those are therefore the only kinds where two same-UID
/// observations can hold different `value` strings, and when they merge one
/// spelling has to win — chosen by a rule that depends only on the SET of
/// spellings, never on arrival order.
///
/// Ranking rather than a bare lexicographic `min`, because `min` would pick
/// `"ACME  CORP"` over `"Acme Corp"` (ASCII upper sorts before lower) and keep
/// the doubled space — precisely the dossier-quality loss `identity_fold` exists
/// to avoid ("nobody wants a dossier headed `jeremy stewart`").
///
/// Uncased scripts (CJK, Arabic) have neither upper nor lower, so they land in
/// the middle rank together and are separated by the lexicographic tiebreak —
/// still deterministic.
fn display_rank(value: &str) -> u8 {
    let collapsed = value.split_whitespace().collect::<Vec<_>>().join(" ");
    let mixed_case = value.chars().any(char::is_lowercase) && value.chars().any(char::is_uppercase);
    match (collapsed == value, mixed_case) {
        (true, true) => 0,  // clean spacing, mixed case — "Jeremy Stewart"
        (true, false) => 1, // clean spacing, but SHOUTED or all-lower
        (false, _) => 2,    // internal whitespace runs — "Jeremy  Stewart"
    }
}

/// True when `candidate` is the better canonical display spelling of two
/// same-UID observations. A strict total order over `(rank, bytes)`, so it is
/// commutative and associative: any merge order, and any pairing, selects the
/// same winner.
fn prefers_display(candidate: &str, current: &str) -> bool {
    (display_rank(candidate), candidate) < (display_rank(current), current)
}

/// Derive a deterministic SHA-256 UID from kind + normalised value.
///
/// Format: `hex(SHA-256("<kind_str>:<identity_fold(normalised_value)>"))`
///
/// The fold lives HERE rather than in [`Entity::new`] because `derive_uid` is
/// not the private helper of one constructor — it is called from six places,
/// and one of them is the engine deriving the **seed's** UID from the operator's
/// target string (`core::engine`), with others in dispatch and history. Folding
/// in the constructor alone would give a seed typed as `Jeremy Stewart` a
/// different UID from the `jeremy stewart` its own modules emit: the seed would
/// land in the graph as an isolated node while every derived edge attached to a
/// twin it could not reach. That is precisely the "subject has no derived
/// connections" state observed in a real dossier, so fixing identity anywhere
/// but at the single authoritative definition would have reproduced the defect
/// while appearing to cure it.
///
/// Migration: `Person` and `Organisation` UIDs computed before this change do
/// not match those computed after, so entities already persisted under a
/// mixed-case spelling are reachable only by re-scanning. Every other kind is
/// bit-for-bit unchanged.
// Was `pub(crate)` before extraction (called directly by core::engine::history
// and storage's tests); see uid_for's comment above on the crate-boundary widening.
pub fn derive_uid(kind: &EntityKind, normalised_value: &str) -> String {
    let normalised_value = &*identity_fold(kind, normalised_value);
    // digest 0.11 dropped the `io::Write` impl for hashers. Stream the `Display`
    // of `<kind>` straight into the hasher through [`HashWrite`] so the
    // per-entity hot path (every `Entity::new`) allocates NO intermediate
    // `String` — the previous `format!("{kind}:")` heap-allocated on every UID.
    // The bytes hashed are byte-identical to that `format!`, so existing UIDs are
    // unchanged.
    use fmt::Write as _;
    let mut h = Sha256::new();
    match kind {
        EntityKind::Other(s) => {
            // Unlike every fixed-string kind (drawn from a small closed set that
            // never contains `:`), `Other`'s inner name is attacker/scrape
            // controlled (`modules::breach_rich`'s catch-all loop mints these
            // straight from untrusted JSON field names) and can itself contain
            // `:`. Hashing `"other:{s}:{value}"` via the plain Display path
            // below is ambiguous at the name/value boundary: Other("a") with
            // value "b:c" and Other("a:b") with value "c" both produce the
            // identical preimage "other:a:b:c" and therefore the SAME uid.
            // Length-prefixing `s` fixes the split point unambiguously — this
            // changes ONLY `Other`'s hash preimage (hence only its UIDs);
            // every other kind's byte-identical Display-based path below is
            // untouched.
            let _ = write!(HashWrite(&mut h), "other:{}:", s.len());
            h.update(s.as_bytes());
            h.update(b":");
        }
        _ => {
            let _ = write!(HashWrite(&mut h), "{kind}:");
        }
    }
    h.update(normalised_value.as_bytes());
    hex::encode(h.finalize())
}

/// Mint an entity UID from a **raw, un-normalised** value — the single entry
/// point for the two-step `normalise` → [`derive_uid`] contract that identity
/// callers previously copy-pasted (engine seed derivation, dispatch source
/// counting, username history bridging). Folding the two steps here means a
/// caller with a raw operator/target string can never accidentally hash a
/// value that skipped [`normalise`] — which would land it in the graph under a
/// UID no module's emitted entity shares.
///
/// The result is byte-identical to `derive_uid(kind, &normalise(kind, value))`,
/// so this preserves the SHA-256-deterministic-UID invariant exactly.
///
/// NOT used by:
/// * [`Entity::new`], which needs the intermediate normalised form for its own
///   `value` field and so computes `normalise` once and calls [`derive_uid`]
///   directly — routing it through here would recompute `normalise` on every
///   entity constructed (the hottest path in the engine).
/// * Callers that already hold a **normalised** (`canon`) value; they call
///   [`derive_uid`] directly, because re-normalising a canonical value is at
///   best wasted work and at worst not provably idempotent for every kind.
// Was `pub(crate)` before this module's extraction — visible engine-wide in
// the parent crate (crate-level `pub(crate)` there meant "anywhere in
// huntsman_search_engine"), used by core::engine's dispatch/history. A crate
// boundary can't express that scope from here, so this is `pub`.
pub fn uid_for(kind: &EntityKind, value: &str) -> String {
    derive_uid(kind, &normalise(kind, value))
}

/// A [`fmt::Write`] shim that streams formatted text straight into a SHA-256
/// hasher, so a value's `Display` can be hashed with no intermediate `String`
/// allocation. `write_str` is infallible here (updating a hasher never fails).
struct HashWrite<'a>(&'a mut Sha256);

impl fmt::Write for HashWrite<'_> {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.0.update(s.as_bytes());
        Ok(())
    }
}

/// Canonicalise a URL query string for dedup: drop pure-tracking params
/// (see [`is_tracking_param_key`]) and sort the survivors so that
/// `?a=1&b=2` and `?b=2&a=1` — the same resource in a different order — key to
/// one UID. Empty segments are dropped. Returns `""` when every param was
/// tracking (the caller then omits the `?` entirely).
///
/// Parameter *values* are preserved byte-for-byte (only keys are matched
/// case-insensitively): a value like `?v=AbC123` on YouTube is case-significant
/// and must never be folded.
fn normalise_url_query(query: &str) -> String {
    let mut kept: Vec<&str> = query
        .split('&')
        .filter(|seg| !seg.is_empty())
        .filter(|seg| {
            let key = seg.split('=').next().unwrap_or(seg);
            !is_tracking_param_key(key)
        })
        .collect();
    kept.sort_unstable();
    kept.join("&")
}

/// Invisible format / zero-width characters that are never part of a real
/// identifier: BOM `U+FEFF`, zero-width space `U+200B`, ZWNJ/ZWJ `U+200C`/`U+200D`,
/// word-joiner `U+2060`.
const FORMAT_NOISE: [char; 5] = ['\u{feff}', '\u{200b}', '\u{200c}', '\u{200d}', '\u{2060}'];

/// Strip [`FORMAT_NOISE`] from an identifier value. Being non-whitespace, these
/// chars survive `trim` and silently fork one value's SHA-256 UID — a BOM an
/// exporter prepended (`\u{feff}alice@x.com`), a zero-width space in a scraped
/// handle — fragmenting one identity across two nodes. They never occur in a real
/// email / username / domain, so removal is loss-free. Borrows when the input is
/// clean (the overwhelmingly common case), so the hot normalize path allocates
/// only for the rare dirty value.
fn strip_format_noise(s: &str) -> std::borrow::Cow<'_, str> {
    if s.contains(FORMAT_NOISE) {
        std::borrow::Cow::Owned(s.chars().filter(|c| !FORMAT_NOISE.contains(c)).collect())
    } else {
        std::borrow::Cow::Borrowed(s)
    }
}

/// Round `lat`/`lon` to 6 dp and format as the canonical `"lat,lon"` string that
/// decides a `Coordinates` entity's UID, collapsing IEEE negative zero (`+ 0.0`)
/// so a point on the equator/meridian can't fragment onto two UIDs by the sign of
/// zero. The SINGLE authority for the geo-UID precision + negative-zero-collapse
/// rule: both `Coordinates` normalisation paths below (the bare-decimal fast path
/// and the `coords::parse` richer-notation path) call it, so a change to the
/// rounding rule can never edit only one and silently fork one physical point
/// onto two UIDs. (Scope: this is the UID round+collapse, not the many `{:.6}`
/// display formatters elsewhere.)
fn fmt_coord_6dp(lat: f64, lon: f64) -> String {
    let lat = (lat * 1e6).round() / 1e6 + 0.0;
    let lon = (lon * 1e6).round() / 1e6 + 0.0;
    format!("{lat:.6},{lon:.6}")
}

/// Normalise a value for a given kind.
///
/// - Email → lowercase, trim, strip surrounding quotes
/// - Domain → lowercase, trim, strip trailing dot
/// - Username → lowercase, trim, strip surrounding quotes + leading `@`
///   (EXCEPT a 27-char all-ASCII-alphanumeric value — a base62 structured-ID
///   shape like a KSUID, where case is significant — which is trimmed/
///   sigil-stripped but NOT case-folded, so its encoded data survives intact)
/// - IpAddress → trim
/// - Phone → strip non-digits (keep leading +)
/// - Everything else → trim
// Was `pub(crate)` before extraction (widely called across core::relation,
// core::breach_sweep, core::scan); see uid_for's comment above on the
// crate-boundary widening.
pub fn normalise(kind: &EntityKind, value: &str) -> String {
    match kind {
        EntityKind::Email => {
            // Breach dumps sometimes append a literal escape tail
            // (`…@gmail.com\r\n` — the four characters `\ r \ n`, NOT real
            // whitespace that `trim` would catch) or embed stray whitespace. A
            // real address contains neither a backslash nor internal whitespace,
            // so cut at the first of either before folding — otherwise the junk
            // tail fragments one address across two UIDs and leaks a malformed
            // value into the bundle. Valid emails have no such char, so their
            // UID is unchanged.
            // Strip invisible format / zero-width noise first (a BOM an exporter
            // prepended, a zero-width space mid-value) — removal, not the cut
            // below, because the noise can sit *before* the `@`, where cutting
            // would truncate the local part. See [`strip_format_noise`].
            let cleaned = strip_format_noise(value.trim());
            // Re-trim AFTER stripping: a leading BOM/zero-width char is NOT
            // whitespace, so the `value.trim()` above stops at it and leaves any
            // whitespace/control byte sitting BEHIND it in place. Removing the
            // format noise then exposes that byte at the edge; without this second
            // trim it survives into the result, but a re-normalise (no BOM left to
            // block `trim`) would strip it — so one address would key to two UIDs
            // and `normalise` would not be idempotent.
            let cleaned = cleaned.trim();
            // Cut at the first backslash / whitespace / control char: the breach
            // escape tail, stray internal whitespace, or a NUL-separated junk
            // suffix (`…@x.com\0junk`) all mark the end of the real address.
            let cut = cleaned
                .find(|c: char| c == '\\' || c.is_whitespace() || c.is_control())
                .unwrap_or(cleaned.len());
            // Strip surrounding quote characters an exporter or shell left on the
            // value (`"matt@x.com"`, `'matt@x.com`, a CSV `""`-escaped quote that
            // leaked into the seed): a quote is never part of a real address as HSE
            // handles them, so a leading/trailing one only forks the UID and
            // poisons every entity derived from the value (a `"matt@x.com` seed
            // spawned a `"matt` username that could never correlate with the clean
            // `matt`). Done AFTER the cut so a quote the cut exposes at the new end
            // (`a"<ctrl>b` → `a"` → `a`) is still removed — keeping normalise a
            // fixed point. Clean addresses carry none, so their UID is unchanged.
            let head = cleaned[..cut].trim_matches(['"', '\'', '`']);
            // Total Unicode case-fold for dedup. `str::to_lowercase` maps every
            // char through `char::to_lowercase`, so a value whose only capital is
            // non-ASCII (`Ölaf`, a Cyrillic/Greek handle, Turkish `İ`) folds the
            // same as its all-caps spelling — they must share a UID.
            head.to_lowercase()
        }
        EntityKind::Username => {
            // Same total Unicode case-fold as Email, plus stripping a leading `@`
            // handle sigil: a profile scraped as `@jordanavery` and one parsed
            // as `jordanavery` are the SAME account and must dedup to one UID.
            // Without this they fragmented into two identities, and the `@`-prefixed
            // copy also looked like a truncated value to the fragment auditor.
            // Invisible format noise is removed first (see [`strip_format_noise`])
            // so a BOM/zero-width char can neither fork the UID nor hide the
            // leading `@` from the sigil strip.
            let noise_free = strip_format_noise(value.trim());
            let cleaned = noise_free
                // Strip the leading run of the `@` handle sigil, surrounding quote
                // contamination (`"`, `'`, `` ` ``) AND any interleaved whitespace
                // in a SINGLE predicate — plus the symmetric trailing run of quotes
                // and whitespace. Folding whitespace into the same pass is what
                // keeps normalise a fixed point: a whitespace char sitting *between*
                // two sigils (`` `\t` ``) would otherwise be removed only by a later
                // standalone `.trim()`, exposing the inner sigil one normalise too
                // late and forking one account across two UIDs on a re-normalise.
                // (Proptest minimal case: the Username value `` `\t`\0 `` folded to
                // `` `\0 `` on the first pass but `` \0 `` on the second.) The `@`
                // is leading-only — a real handle never trails one — while quotes
                // and the backtick strip from both ends. This is the same
                // shield-the-sigil fixed-point discipline the Email (quote-after-cut)
                // and Domain (dots-and-whitespace-together) arms already apply.
                .trim_start_matches(|c: char| {
                    matches!(c, '@' | '"' | '\'' | '`') || c.is_whitespace()
                })
                .trim_end_matches(|c: char| matches!(c, '"' | '\'' | '`') || c.is_whitespace());
            // A 27-char, all-ASCII-alphanumeric value is the shape of a base62
            // structured ID (a KSUID — see `structured_id::decode_ksuid`), not a
            // human-chosen handle: nobody types a 27-char no-separator alnum
            // string as their own account name across platforms, so preserving
            // its case costs none of the cross-platform-handle correlation this
            // fold exists to provide. And it MUST be preserved here — unlike
            // Crockford base32 (ULID), which is case-insensitive BY DESIGN, base62
            // is case-SIGNIFICANT: `'A'` and `'a'` are different digit values, so
            // folding case does not normalise a KSUID, it silently decodes it into
            // a DIFFERENT value. Its leading bytes are a creation timestamp, so a
            // downstream decode over the folded value doesn't just fail closed —
            // it can confidently report a real-looking date that is months or
            // years wrong. (This still keeps `normalise` a fixed point: the
            // shape check and its outcome are unaffected by a second pass, since
            // nothing upstream of it — trim/format-noise-strip/sigil-strip — has
            // anything left to remove from an all-alphanumeric value.)
            if cleaned.len() == 27 && cleaned.bytes().all(|b| b.is_ascii_alphanumeric()) {
                cleaned.to_string()
            } else {
                cleaned.to_lowercase()
            }
        }
        EntityKind::Domain => {
            // Invisible format noise removed first (see [`strip_format_noise`]) so a
            // BOM/zero-width char can't fork the host's UID.
            let cleaned = strip_format_noise(value.trim());
            // Re-trim AFTER stripping: a leading BOM/zero-width char is NOT
            // whitespace, so the `value.trim()` above stops at it and leaves any
            // whitespace/control byte sitting BEHIND it (`\u{feff}\u{b}host`) in
            // place. Removing the format noise then exposes that byte at the edge;
            // without this second trim it survives into the result, but a
            // re-normalise (no BOM left to block `trim`) would strip it — so one
            // host would key to two UIDs and `normalise` would not be idempotent.
            // Mirrors the Username arm's post-strip `.trim()`.
            let cleaned = cleaned.trim();
            let mut s = String::with_capacity(cleaned.len());
            for c in cleaned.chars() {
                s.extend(c.to_lowercase());
            }
            // Trim trailing dots and any whitespace exposed by dot-stripping
            // together so the operation is idempotent: a value like "\x00\t."
            // would lose its trailing `.` here, leaving `\t` at the end, and a
            // second pass would then trim that `\t` — breaking the fixed-point.
            let len = s
                .trim_end_matches(|c: char| c == '.' || c.is_whitespace())
                .len();
            s.truncate(len);
            // Strip leading `www.` label(s) so `www.foo.com` and `foo.com` dedup
            // to one host. Consume *all* consecutive leading `www.` labels in a
            // single pass (not just the first) so the result is a fixed point:
            // a single strip left `www.www.foo.com` → `www.foo.com`, which then
            // re-normalised to `foo.com`, so the same host could key to two UIDs.
            // The non-empty guard keeps a bare `www.` from collapsing to "".
            let mut host = s.as_str();
            while let Some(rest) = host.strip_prefix("www.") {
                if rest.is_empty() {
                    break;
                }
                host = rest;
            }
            // Re-trim AFTER stripping: any leading whitespace the `www.` label
            // exposed must be removed so the result is idempotent.
            let host = host.trim_start();
            if host.len() != s.len() {
                s = host.to_string();
            }
            s
        }
        EntityKind::Phone => {
            // Trim BEFORE the leading-`+` check: every other arm trims, and a
            // scraped value with leading whitespace (" +61 412 …") would
            // otherwise fail the first-char test and silently drop the
            // country-code `+`, fragmenting one number across two UIDs
            // ("61412…" vs "+61412…").
            let trimmed = value.trim();
            let mut out = String::with_capacity(trimmed.len());
            let mut chars = trimmed.chars().peekable();
            if chars.peek() == Some(&'+') {
                out.push('+');
                chars.next();
            }
            for c in chars {
                if c.is_ascii_digit() {
                    out.push(c);
                }
            }
            out
        }
        EntityKind::IpAddress => {
            let trimmed = value.trim();
            // Parse and re-format to canonical form (handles IPv6 compression, mapped addresses)
            if let Ok(ip) = trimmed.parse::<std::net::IpAddr>() {
                match ip {
                    std::net::IpAddr::V6(v6) => {
                        // Convert IPv4-mapped IPv6 (::ffff:1.2.3.4) to plain IPv4
                        if let Some(v4) = v6.to_ipv4_mapped() {
                            return v4.to_string();
                        }
                        ip.to_string()
                    }
                    _ => ip.to_string(),
                }
            } else {
                trimmed.to_string()
            }
        }
        EntityKind::MacAddress => {
            // Normalise to lowercase colon-separated: aa:bb:cc:dd:ee:ff
            let trimmed = value.trim();
            let hex: String = trimmed
                .chars()
                .filter(char::is_ascii_hexdigit)
                .flat_map(char::to_lowercase)
                .collect();
            if hex.len() == 12 {
                format!(
                    "{}:{}:{}:{}:{}:{}",
                    &hex[0..2],
                    &hex[2..4],
                    &hex[4..6],
                    &hex[6..8],
                    &hex[8..10],
                    &hex[10..12]
                )
            } else {
                trimmed.to_lowercase()
            }
        }
        EntityKind::Coordinates => {
            // Normalise to 6 decimal places: "lat,lon"
            let trimmed = value.trim();
            if let Some((lat_s, lon_s)) = trimmed.split_once(',')
                && let (Ok(lat), Ok(lon)) =
                    (lat_s.trim().parse::<f64>(), lon_s.trim().parse::<f64>())
                && lat.is_finite()
                && lon.is_finite()
            {
                // The 6-dp round + negative-zero collapse lives in the single
                // `fmt_coord_6dp` authority. Non-finite values (NaN/inf) fall
                // through to the raw string instead of a formatted
                // pseudo-coordinate (guarded by the `is_finite` checks above).
                return fmt_coord_6dp(lat, lon);
            }
            // Richer notations the bare decimal fast-path above doesn't catch —
            // DMS/DDM, `geo:` URIs, Plus Codes, Maidenhead locators, space-
            // separated decimals — canonicalise to the same 6-dp "lat,lon" so
            // every downstream consumer (geocoders, the geo correlator) sees one
            // decimal shape. Non-finite / unparseable input still falls through
            // untouched.
            if let Some(p) = coords::parse(trimmed) {
                return fmt_coord_6dp(p.lat, p.lon);
            }
            trimmed.to_string()
        }
        EntityKind::Url => {
            let trimmed = value.trim();
            let lower = trimmed.to_lowercase();
            let (scheme, rest) = if lower.starts_with("https://") {
                ("https", &trimmed[8..])
            } else if lower.starts_with("http://") {
                ("http", &trimmed[7..])
            } else {
                return trimmed.to_string();
            };
            let no_frag = rest.split('#').next().unwrap_or(rest);
            let (host_and_path, query) = match no_frag.split_once('?') {
                Some((hp, q)) => (hp, Some(q)),
                None => (no_frag, None),
            };
            let (host, path) = host_and_path.split_once('/').unwrap_or((host_and_path, ""));
            let host_lower: String = host.chars().flat_map(char::to_lowercase).collect();
            let path_trimmed = path.trim_end_matches('/');
            let mut out = if path_trimmed.is_empty() {
                format!("{scheme}://{host_lower}")
            } else {
                format!("{scheme}://{host_lower}/{path_trimmed}")
            };
            if let Some(q) = query {
                let cleaned = normalise_url_query(q);
                if !cleaned.is_empty() {
                    out.push('?');
                    out.push_str(&cleaned);
                }
            }
            out
        }
        _ => value.trim().to_string(),
    }
}

/// The distinct evidence-source names across a set of entities — the modules /
/// providers that contributed to this collection. `BTreeSet` gives a
/// deduplicated, sorted, reproducible view. **Pure.**
///
/// This is the single primitive every "which sources/modules produced this
/// scan" surface reduces through — per-scan MITRE ATT&CK coverage (Navigator
/// layer, coverage JSON, report) and provenance roll-ups alike — so the source
/// set is computed one way everywhere and the surfaces cannot diverge.
#[must_use]
pub fn evidence_sources(entities: &[Entity]) -> std::collections::BTreeSet<&str> {
    entities
        .iter()
        .flat_map(|e| e.evidence.iter().map(|ev| ev.source.as_str()))
        .collect()
}

/// The **expansion timeline**: how many entities were first discovered in each
/// expansion generation ([`Entity::generation`]), ordered from the seed outward.
/// Generation 0 is the seed round (found directly by scanning the subject); each
/// later generation is one pivot further out along its derivation trail. The
/// shape of this distribution is the scan's expansion curve — the working graph
/// growing round by round, then converging as leads are exhausted or pruned.
/// Pure; returns a `BTreeMap` so generations are already in order.
#[must_use]
pub fn expansion_timeline(entities: &[Entity]) -> std::collections::BTreeMap<u32, usize> {
    let mut hist = std::collections::BTreeMap::new();
    for e in entities {
        *hist.entry(e.generation).or_insert(0) += 1;
    }
    hist
}

/// Deduplicate `entities` by `(kind, value)`, folding duplicates into the first
/// occurrence via [`Entity::merge`] rather than discarding them.
///
/// Any module that accumulates entities across more than one record, loop
/// iteration, or independent pass — two directories confirming the same
/// address, two search results resolving the same geocoded point, two
/// register rows restating the same organisation — can produce two entities
/// sharing a UID before the engine's own global merge ever sees them.
/// `merge`'s GREATEST semantics (max confidence, summed corroboration,
/// unioned tags/evidence) mean two independent observations of the same fact
/// read as corroborated, rather than one arbitrarily surviving and the
/// other's evidence being silently dropped at the module boundary.
/// Commutative in the folded signal, so the result does not depend on input
/// order — only the surviving slot's position follows first-occurrence
/// order. Pure.
pub fn dedup_merge_entities(entities: &mut Vec<Entity>) {
    let mut index: HashMap<(EntityKind, String), usize> = HashMap::new();
    let mut deduped: Vec<Entity> = Vec::with_capacity(entities.len());
    for e in entities.drain(..) {
        let key = (e.kind.clone(), e.value.clone());
        match index.get(&key) {
            Some(&i) => deduped[i].merge(e),
            None => {
                index.insert(key, deduped.len());
                deduped.push(e);
            }
        }
    }
    *entities = deduped;
}

/// Current Unix timestamp in seconds.
///
/// `std::time::SystemTime::now()` panics at runtime on `wasm32-unknown-unknown`
/// (no OS clock syscall in that target) — this browser build uses
/// `js_sys::Date::now()` (milliseconds since epoch) instead.
#[inline]
#[cfg(not(target_arch = "wasm32"))]
pub fn unix_now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

/// Current Unix timestamp in seconds (`wasm32-unknown-unknown` browser build).
#[inline]
#[cfg(target_arch = "wasm32")]
pub fn unix_now() -> u64 {
    (js_sys::Date::now() / 1000.0) as u64
}

/// Generate a unique scan ID: `hex(SHA-256("<kind>:<value>:<unix_now>"))`.
///
/// NOT deterministic across calls for the same target — the timestamp
/// is mixed in so each invocation produces a fresh id.
pub fn scan_id(kind: &str, value: &str) -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    // Collision-free per scan. The previous derivation mixed only `unix_now()`
    // at ONE-SECOND resolution, so two scans created in the same second with the
    // same (kind, value) — rapid web imports, a `/scans/batch`, a tight loop —
    // hashed identically and the second silently overwrote the first's row +
    // entities. Mix in a process-wide monotonic counter (guarantees uniqueness
    // within a run, even same-nanosecond) plus the sub-second nanos (separates
    // ids across a restart that resets the counter), keeping `unix_now()` for
    // human-meaningful time ordering. Re-scans still get a fresh id by design.
    static SEQ: AtomicU64 = AtomicU64::new(0);
    #[cfg(not(target_arch = "wasm32"))]
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.subsec_nanos());
    // `js_sys::Date::now()` only has millisecond resolution, not nanosecond —
    // honestly coarser sub-second entropy, not fabricated precision. SEQ still
    // guarantees same-run uniqueness regardless; this only affects separation
    // across a restart that resets the counter.
    #[cfg(target_arch = "wasm32")]
    let nanos = (js_sys::Date::now() as u64 % 1000) as u32 * 1_000_000;
    let mut h = Sha256::new();
    h.update(kind.as_bytes());
    h.update(b":");
    h.update(value.as_bytes());
    h.update(b":");
    h.update(unix_now().to_be_bytes());
    h.update(nanos.to_be_bytes());
    h.update(SEQ.fetch_add(1, Ordering::Relaxed).to_be_bytes());
    hex::encode(h.finalize())
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests;
