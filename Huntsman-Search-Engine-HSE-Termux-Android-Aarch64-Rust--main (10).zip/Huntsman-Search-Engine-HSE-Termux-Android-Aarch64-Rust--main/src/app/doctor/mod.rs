//! `hse doctor` — health-check subcommand.
//!
//! Reports Termux detection, DB path, key path, module/cost counts,
//! HUNTSMAN_* keys loaded, a per-source scraper health signal derived from
//! the persisted event log (`PROBLEM_TREE` T2.7 / `SOLUTION_TREE`
//! SOL-HEALTH-SIGNAL — see [`crate::util::scraper_health`]), a cross-scan
//! **weak findings** review list (every stored entity below the confidence
//! review threshold — see [`crate::storage::Store::low_confidence_evidence`]),
//! the local cell-tower database's freshness (no auto-resync exists yet, so a
//! months-stale import is a real "check for a refresh" signal — see
//! [`crate::util::cell_db::is_stale`]), a live WiGLE account introspection
//! that surfaces the email-unverified throttling warning before it starts
//! silently truncating result sets, a live SeekNow account probe that
//! catches a dead/plan-lacking key before it silently zeroes out HSE's
//! highest-priority paid source (and its proactive API-key-harvesting
//! reach — see [`crate::util::key_harvest`]) on every scan.

use crate::core::error::Result;
use crate::{
    default_db_path, is_termux,
    modules::registry,
    storage::{EvidenceAnomaly, Store},
    util::{cell_db, keys, scraper_health, timefmt},
};

use crate::app::export::{WAL_RUNAWAY_BYTES, cost_label};

pub async fn cmd_doctor(live: bool) -> Result<()> {
    let mods = registry();
    println!("HSE v{} — doctor\n", crate::VERSION);
    println!(
        "Termux:    {}",
        if is_termux() {
            "detected"
        } else {
            "not detected"
        }
    );
    println!("DB path:   {}", default_db_path());
    println!("Keys path: {}", keys::env_path());

    // Tracks a CRITICAL storage fault only — the database will not open, or its
    // integrity check reported corruption. Soft states (missing keys, a module
    // failure streak, a stale cell DB, a large WAL) are informational and never
    // set this. When set, `cmd_doctor` returns `Err` at the end so `hse
    // diagnostics` (which treats doctor as a fail-able section) and a scripted
    // standalone `hse doctor` both surface a broken DB via a non-zero exit
    // instead of a silent PASS — while still printing the full report first.
    let mut critical = false;

    println!("\nStorage:");
    let db_path = default_db_path();
    // Kept as a `Result` (not unwrapped into the match arm) so the same open
    // handle can back the scraper-health section further down without a
    // second `Store::open` — the DB is opened once per `doctor` run either way.
    let store_result = Store::open(&db_path);
    match &store_result {
        Ok(store) => {
            println!("  ok — database opens cleanly");
            // Explicit corruption check (T5): a healthy DB reports a single "ok".
            match store.integrity_check() {
                Ok(rows) if rows.iter().all(|r| r == "ok") => {
                    println!("  integrity:  ok");
                }
                Ok(rows) => {
                    critical = true;
                    println!("  integrity:  FAIL — {} issue(s) reported:", rows.len());
                    for r in rows.iter().take(10) {
                        println!("                {r}");
                    }
                }
                Err(e) => {
                    // The pragma itself failing to run is not a benign,
                    // informational signal — severe-enough corruption makes
                    // SQLite fail `PRAGMA integrity_check` outright rather
                    // than complete and report a row per problem (see
                    // `storage::tests::integrity_check_reports_problems_on_a_corrupted_db`),
                    // and this branch must not be less alarming than the
                    // "ran and found problems" arm above it.
                    critical = true;
                    println!("  integrity:  FAIL — could not run check — {e}");
                }
            }
            // WAL high-water mark: a never-checkpointed `-wal` can grow without
            // bound under a long-lived process. Report it so the operator can
            // see (and a TRUNCATE checkpoint at the next scan boundary resets it).
            if let Ok(meta) = tokio::fs::metadata(format!("{db_path}-wal")).await {
                let kib = meta.len() / 1024;
                println!("  WAL size:   {kib} KiB");
                if meta.len() > WAL_RUNAWAY_BYTES {
                    println!(
                        "                (large — runs a TRUNCATE checkpoint at the next scan)"
                    );
                }
            }
        }
        Err(e) => {
            critical = true;
            println!("  FAIL — {e}");
        }
    }

    println!("\nExternal tools:");
    let curl_ok = std::process::Command::new("curl")
        .arg("--version")
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .status()
        .is_ok_and(|s| s.success());
    if curl_ok {
        println!("  curl:      present");
    } else {
        println!("{}", curl_missing_message());
    }

    // ── Egress proxy pool (only when the operator configured one) ─────
    // `refresh_pool` fetches the configured feeds and probe-validates the due
    // entries IN THIS PROCESS, so what prints is a measurement made now — not
    // the per-process history a fresh `hse doctor` could never have observed
    // (the trap the module-health line above fell into). The pool's three
    // accessors existed with no caller; an operator relying on
    // HUNTSMAN_PROXY_FEEDS had no way to see a silently-dying pool until scans
    // started failing.
    {
        use crate::util::egress;
        let configured = std::env::var_os(egress::PROXY_ENV).is_some()
            || std::env::var_os(egress::PROXY_FEEDS_ENV).is_some();
        if configured {
            println!("\nEgress proxy pool:");
            let (fed, validated) = egress::refresh_pool().await;
            match egress::format_pool_health(&egress::proxy_pool_snapshot()) {
                Some(body) => {
                    if body.contains("FAIL") {
                        critical = true;
                    }
                    println!("{body}");
                }
                None => {
                    critical = true;
                    println!(
                        "  FAIL — {} / {} is set but no proxy entered the pool \
                         (feeds fetched: {fed}, validated: {validated}); every request \
                         will fail rather than leak a direct connection",
                        egress::PROXY_ENV,
                        egress::PROXY_FEEDS_ENV
                    );
                }
            }
        }
    }

    println!("\nModules ({} registered):", mods.len());
    let mut by_cost = std::collections::BTreeMap::<&str, usize>::new();
    for m in &mods {
        *by_cost.entry(cost_label(m.cost())).or_default() += 1;
    }
    for (cost, count) in &by_cost {
        println!("  {cost:<10} {count}");
    }

    // ── Module health (T2.7 / SOL-HEALTH-SIGNAL) ───────────────────────
    // Per-process failure streaks driven by real dispatch outcomes — quiet
    // by default (a freshly-started or fully healthy process reports
    // nothing extra), surfacing only sources actually worth investigating.
    let unhealthy = crate::core::engine::module_health_report();
    if unhealthy.is_empty() {
        // An empty tracker means one of two very different things, and saying
        // "no failure streak" for both is a false reassurance: this section is
        // per-process and reactive, and a standalone `hse doctor` dispatches
        // nothing, so the tracker is ALWAYS empty here. On a real device that
        // printed a clean bill of health immediately above the Scraper health
        // section reporting 22 sources in a failure streak.
        println!(
            "\n{}",
            empty_module_health_line(crate::core::engine::module_health_observed())
        );
    } else {
        println!(
            "\nModule health ({} with a failure streak this process):",
            unhealthy.len()
        );
        for h in &unhealthy {
            println!("  {}", format_module_health(h));
        }
    }

    // ── Persisted capability drift (offline, always shown) ─────────────
    // A confirmed-drift finding from a PAST live probe (`--live` here, or the
    // Web UI's "Run live capability probe" panel) is persisted to
    // `~/.huntsman/capability_drift.json` so it survives past that one
    // printout/response. Surfaced here, on every (even offline) `doctor` run,
    // so the operator doesn't have to remember to re-run `--live` to be
    // reminded a capability is known-dead. Ages out past 7 days (matches the
    // weekly CI drift-sweep cadence) — a stale finding may well be resolved by
    // now, so it is dropped rather than nagging forever.
    const DRIFT_TTL_SECS: u64 = 7 * 24 * 60 * 60;
    let persisted_drift = crate::selftest::capability_probe::recent_confirmed_drift(DRIFT_TTL_SECS);
    if !persisted_drift.is_empty() {
        println!(
            "\n⚠ Capability drift (from a previous live probe, last {} days):",
            DRIFT_TTL_SECS / 86_400
        );
        for (module, ts) in &persisted_drift {
            println!("  {module:<22} confirmed {}", timefmt::compact_utc(*ts));
        }
        println!("  run `hse doctor --live` to re-check whether these have recovered");
    }

    // ── Live capability preflight (opt-in, --live) ─────────────────────
    // The module-health section above is reactive — it only knows what real
    // scans in THIS process have already tried. `--live` is the proactive
    // complement: probe every keyless module against its real provider now, so
    // a drifted or dead capability shows up before an investigation relies on
    // it. Network-bound, so it is opt-in; the default `doctor` run stays offline.
    if live {
        print_live_capability_report().await;
    }

    let loaded = keys::load();
    let huntsman_keys = sorted_huntsman_keys(&loaded);
    println!("\nHUNTSMAN_* keys loaded: {}", huntsman_keys.len());
    for k in &huntsman_keys {
        println!("  - {k}");
    }
    if huntsman_keys.is_empty() {
        println!("  (none set; all free modules still work)");
    }

    // ── Unset keys + where to get them (mostly free), ranked by acquisition ──
    // The "failing modules" in a scan are usually just these — unconfigured
    // optional providers, which skip cleanly rather than erroring. Ranked by
    // ROI tier (see `rank_unset_keys`) so the operator registers the keys that
    // unlock the most collection first, each with its free-signup hint.
    // A slot holding the unedited placeholder is UNSET, not set. Testing only
    // `contains_key` meant a freshly provisioned device — where every one of
    // these names is present as a template slot — had this entire section
    // suppressed, so the operator was shown no keys to acquire at all.
    let missing = rank_unset_keys(|k| key_slot_is_filled(&loaded, k));
    if !missing.is_empty() {
        println!(
            "\nUnset keys ({}), ranked by acquisition value — modules needing \
             these skip cleanly (not errors). Register multiplier-tier keys first:",
            missing.len()
        );
        for (k, roi) in missing {
            let tier = roi.label();
            match keys::signup_hint(k) {
                Some(hint) => println!("  - [{tier:<10}] {k}\n      → {hint}"),
                None => println!("  - [{tier:<10}] {k}"),
            }
        }
    }

    // ── Per-source scraper health (T2.7 / SOL-HEALTH-SIGNAL) ──────────
    // Derived from the persisted event log across ALL scans (a rolling
    // window — see `recent_module_outcome_events`'s doc), not just this
    // process: a source that has errored on every one of its last N runs is
    // real drift an operator should know about even if the failing scans
    // happened days ago in unrelated invocations.
    println!("\nScraper health (recent window):");
    match &store_result {
        Ok(store) => match store.recent_module_outcome_events(scraper_health::RECENT_EVENTS_WINDOW)
        {
            Ok(events) => {
                let health = scraper_health::aggregate_source_health(&events);
                let drifted: Vec<_> = health.iter().filter(|h| h.is_drifted()).collect();
                println!(
                    "  {} source(s) tracked over {} recent outcome event(s)",
                    health.len(),
                    events.len()
                );
                if drifted.is_empty() {
                    println!("  no drifted sources");
                } else {
                    println!(
                        "  {} DRIFTED (>= {} consecutive failures with no success in between):",
                        drifted.len(),
                        scraper_health::DRIFTED_THRESHOLD
                    );
                    for h in &drifted {
                        let last_ok = h
                            .last_success_at
                            .and_then(|ts| timefmt::ymd_utc(ts as i64))
                            .unwrap_or_else(|| "no success in this window".to_string());
                        println!(
                            "    - {:<20} {} consecutive failures, last success: {}",
                            h.module, h.consecutive_failures, last_ok
                        );
                        if let Some(err) = &h.last_error {
                            println!("      last error: {err}");
                        }
                    }
                }

                // ── Key authentication (observed, not synthetically probed) ──
                // Fuse the loaded-key list with the auth-shaped drift errors
                // above: a source failing with a 401 / "invalid API key" while
                // its key IS configured means the CONFIGURED credential is being
                // rejected by the upstream — the single most actionable key
                // problem, and one otherwise reconstructed by hand across two
                // separate sections. Grounded in what real scans observed, so it
                // never mis-reports a working key the way a synthetic probe would.
                let rejected: Vec<_> = crate::util::key_health::auth_failing_sources(&health)
                    .into_iter()
                    .filter(|i| i.likely_env_var.is_some_and(|e| loaded.contains_key(e)))
                    .collect();
                if rejected.is_empty() {
                    println!("  no configured key is being rejected by its upstream");
                } else {
                    println!(
                        "  {} CONFIGURED KEY(S) REJECTED by the upstream — replace or renew:",
                        rejected.len()
                    );
                    for i in &rejected {
                        // The upstream's own words, char-safely capped so a long
                        // JSON body can't flood the terminal — and the cap is
                        // disclosed, so a clipped message is never mistaken for
                        // the upstream's complete reply.
                        let detail = i.detail_capped(160);
                        match i.likely_env_var {
                            Some(env) => println!("    - {:<20} {env}\n      {detail}", i.module),
                            None => println!("    - {:<20}\n      {detail}", i.module),
                        }
                    }
                }

                // ── Silent zero-yield ("parse-rate") drift ──────────────
                // Distinct from a hard failure: the module completes
                // without erroring but has quietly stopped finding
                // anything, on a source proven capable of yielding —
                // consistent with a layout change breaking extraction
                // rather than the target genuinely having nothing.
                let yield_drifted: Vec<_> =
                    health.iter().filter(|h| h.is_yield_drifted()).collect();
                if yield_drifted.is_empty() {
                    println!("  no silent zero-yield (parse-rate) drift");
                } else {
                    println!(
                        "  {} YIELD-DRIFTED (>= {} trailing zero-result runs on a source that has \
                         previously found something):",
                        yield_drifted.len(),
                        scraper_health::YIELD_DRIFT_THRESHOLD
                    );
                    for h in &yield_drifted {
                        println!(
                            "    - {:<20} {} trailing zero-result runs",
                            h.module, h.consecutive_zero_yield
                        );
                    }
                }
            }
            Err(e) => println!("  could not read event log — {e}"),
        },
        Err(_) => println!("  skipped — database did not open (see Storage above)"),
    }

    // ── Weak findings review (cross-scan) ───────────────────────────────
    // `Store::low_confidence_evidence` has no `scan_id` filter by design — it
    // queries the WHOLE local intelligence DB, not one investigation. That is
    // exactly why this lives here, in the cross-scan operator dashboard
    // (alongside the scraper-health signal just above), and NOT as an `hse
    // audit` report section: `hse audit` scores one scan/source's evidentiary
    // quality, and silently blending in weak entities from OTHER, unrelated
    // scans would itself be the wrong-scope evidentiary contamination this
    // project's correlator audits (AU-056/AU-085, AU-105, the GEXF
    // co-occurrence fix) have repeatedly closed elsewhere.
    println!(
        "\nWeak findings (last 7 days, confidence < {:.2}):",
        Store::DEFAULT_LOW_CONFIDENCE_THRESHOLD
    );
    match &store_result {
        Ok(store) => match store.low_confidence_evidence(
            Store::DEFAULT_LOW_CONFIDENCE_THRESHOLD,
            crate::core::port::EVENTS_RETENTION_SECS as i64,
        ) {
            Ok(anomalies) => print!("{}", format_weak_findings(&anomalies)),
            Err(e) => println!("  could not query weak findings — {e}"),
        },
        Err(_) => println!("  skipped — database did not open (see Storage above)"),
    }

    // ── Cell tower database freshness ──────────────────────────────────
    // `hse cells import` is a manual trigger with no auto-resync (a named,
    // unbuilt gap in SOLUTION_TREE §4a) — surfacing staleness here at least
    // makes an operator relying on GEOINT cell-tower correlation (AU-084,
    // `cell_intel`/`cell_local`) aware their local dataset may no longer
    // reflect current tower deployments, rather than trusting it silently.
    println!("\nCell tower database:");
    match cell_db::open_ro() {
        Ok(conn) => match cell_db::last_import(&conn) {
            Ok(Some(rec)) => {
                let total = cell_db::total_count(&conn).unwrap_or(0);
                let now = crate::core::entity::unix_now() as i64;
                let age_days = now.saturating_sub(rec.imported_at).max(0) / 86_400;
                println!("  {total} towers, last import {age_days}d ago");
                if cell_db::is_stale(rec.imported_at, now) {
                    println!(
                        "  STALE (>= {}d since last import) — GEOINT cell-tower correlation \
                         is working from data that old; consider `hse cells import --country \
                         <CODE>` to refresh.",
                        cell_db::STALE_THRESHOLD_DAYS
                    );
                }
            }
            Ok(None) => println!("  populated but no import history recorded"),
            Err(e) => println!("  could not read import history — {e}"),
        },
        Err(_) => println!(
            "  not populated — run `hse cells import --country AU` (or --file PATH) to enable \
             local cell-tower lookups"
        ),
    }

    // ── WiGLE account health (network call, best-effort) ──────────────
    // Poll /api/v2/profile/user. Surfaces the "email unverified →
    // throttled" warning that the WiGLE account page calls out but which
    // our queries don't otherwise expose until they start silently
    // returning fewer results.
    println!("\nWiGLE account:");
    // Both halves of the HTTP-Basic pair are required and nothing is embedded,
    // so report an unconfigured account as exactly that instead of probing with
    // blanks and printing "not reachable".
    let wigle = keys::resolve_key(loaded.get("HUNTSMAN_WIGLE_USER").map(String::as_str)).zip(
        keys::resolve_key(loaded.get("HUNTSMAN_WIGLE_TOKEN").map(String::as_str)),
    );
    match wigle {
        None => println!(
            "  NOT CONFIGURED — set HUNTSMAN_WIGLE_USER and HUNTSMAN_WIGLE_TOKEN.\n    {}",
            keys::signup_hint("HUNTSMAN_WIGLE_TOKEN")
                .unwrap_or("this build ships no credential for WiGLE")
        ),
        Some((wigle_user, wigle_token)) => {
            let http = crate::util::http::build_client();
            let status =
                crate::modules::wigle::refresh_account_status(&http, wigle_user, wigle_token).await;
            match status.verified {
                Some(true) => println!("  email-verified: yes"),
                Some(false) => println!(
                    "  email-verified: NO — WiGLE throttles DB queries until email is confirmed.\n                  Log into wigle.net/account and click the verify link."
                ),
                None => println!("  email-verified: unknown — /profile/user not reachable"),
            }
            if let Some(user) = status.user.as_deref() {
                println!("  user:           {user}");
            }
        }
    }

    // ── SeekNow account health (network call, best-effort) ──────────────
    // Probes /credits — a free meta-query, no scan budget spent — so a dead
    // or plan-lacking key is caught HERE, before an operator discovers it
    // only via SeekNow (HSE's highest-priority paid source, and its
    // proactive API-key-harvesting engine — see `util::key_harvest`)
    // silently returning nothing on every scan. `query_credits` now also
    // latches `is_key_invalid()` on an auth rejection — previously only the
    // data-bearing `search`/`get_path` calls did that classification, so a
    // fresh process (like this one) that only ever calls `query_credits`
    // could never detect a dead key at all.
    println!("\nSeekNow account:");
    // Print the host the probe will hit FIRST, so a resolution failure below is
    // immediately actionable ("could not resolve see-know.eu" → check the domain
    // + resolver), and an operator override is visible.
    println!("  api base: {}", crate::util::see_know::base_url());
    let seeknow_key = crate::util::keys::resolve_key(
        loaded
            .get(crate::util::see_know::KEY_ENV)
            .map(String::as_str),
    );
    use crate::util::see_know::CreditsProbe;
    // No embedded default exists any more, so an unconfigured slot means there is
    // nothing to probe with. Say so — probing with an empty key would report
    // "INVALID" and send the operator hunting for a key problem that is really a
    // configuration gap.
    let Some(seeknow_key) = seeknow_key else {
        println!(
            "  NOT CONFIGURED — set HUNTSMAN_SEEKNOW_KEY (or use the UI Settings panel).\n    {}",
            crate::util::keys::signup_hint(crate::util::see_know::KEY_ENV)
                .unwrap_or("this build ships no credential for SeekNow")
        );
        return finish(critical);
    };
    match crate::util::see_know::credits_probe(seeknow_key).await {
        CreditsProbe::Ok {
            remaining,
            daily_limit: Some(limit),
        } => println!("  credits remaining: {remaining}/{limit}"),
        CreditsProbe::Ok {
            remaining,
            daily_limit: None,
        } => println!("  credits remaining: {remaining} (daily limit not reported by this plan)"),
        // The cause and remedy come from the rejection itself — the ONE text
        // the scan-time warning and the per-seed module error also use — so a
        // `plan_required` key is told to fix its plan, not to swap the key.
        CreditsProbe::InvalidKey(rejection) => println!("  INVALID — {}.", rejection.guidance()),
        // The observed live failure: `curl exited 6` (could not resolve host).
        // Report it as a transport/DNS problem — NOT a key problem — with curl's
        // own detail and the concrete next steps, so an on-device operator can
        // fix it without guessing. `detail`'s wording is precise about what
        // was actually tried (see `seeknow_unreachable_guidance`) rather than
        // assuming every `Unreachable` was a DNS failure that already got a
        // DoH retry — `CreditsProbe::Unreachable` also covers timeouts,
        // connection-refused, and TLS failures, none of which trigger the
        // shared `CurlClient`'s exit-6-only DoH fallback (`util::curl_client`).
        CreditsProbe::Unreachable(detail) => println!(
            "  UNREACHABLE — could not connect to the SeekNow API host: {detail}\n    \
             {}",
            seeknow_unreachable_guidance(&detail)
        ),
        CreditsProbe::Unparseable => println!(
            "  reachable, but the response carried no recognised credits field — the key \
             may lack a paid plan, or the API schema changed."
        ),
    }

    finish(critical)
}

/// The doctor run's exit verdict: a critical storage fault is the one condition
/// that turns a diagnostic report into a non-zero exit. Shared by the normal end
/// of [`cmd_doctor`] and its early return for an unconfigured SeekNow key, so both exit
/// paths agree on what counts as failure.
fn finish(critical: bool) -> crate::core::error::Result<()> {
    if critical {
        return Err(crate::core::error::Error::Other(
            "critical storage fault — the database could not be opened or failed its \
             integrity check (see the FAIL line(s) above)"
                .into(),
        ));
    }
    Ok(())
}

/// The DoH-retry marker `util::curl_client::CurlClient::exec` appends to its
/// error `detail` exactly when it attempted the automatic DoH fallback for
/// this request (win or lose) — see that function's `via` string. Matched
/// verbatim here rather than re-derived, so the two stay coupled by a single
/// literal instead of silently drifting apart.
const DOH_RETRY_MARKER: &str = "(after DoH resolver fallback)";

/// curl's own exit-code text for "could not resolve host" (6), as embedded in
/// `detail` by the same function. Distinguishes a DNS failure that did NOT get
/// an automatic retry (fallback disabled via `HUNTSMAN_DOH_URL=off`) from a
/// non-DNS transport failure (timeout, connection-refused, TLS) that the DoH
/// fallback never applies to in the first place.
const CURL_EXIT_6_MARKER: &str = "exited 6";

/// Build the `hse doctor` guidance for a `CreditsProbe::Unreachable(detail)`.
///
/// `CreditsProbe::Unreachable` covers every curl transport failure — timeouts,
/// connection-refused, TLS errors, and DNS resolution failures alike — but
/// only a DNS failure (`curl exited 6`) ever triggers the shared `CurlClient`'s
/// automatic DoH retry, and even then only when `HUNTSMAN_DOH_URL` hasn't
/// disabled it. Claiming "an automatic DoH retry already ran" unconditionally
/// would be actively wrong for the other failure classes, so this branches on
/// what `detail` actually says was tried instead of assuming the DNS case.
///
/// Pure over the classified `detail` string so the three real cases are
/// unit-tested directly, without a live network round-trip.
fn seeknow_unreachable_guidance(detail: &str) -> String {
    if detail.contains(DOH_RETRY_MARKER) {
        // The automatic DoH retry ran (regardless of what error it hit) and
        // the request still failed — the resolver-level self-heal already
        // available is exhausted.
        "This is a network/DNS failure, not a key problem. An automatic DNS-over-HTTPS \
         retry already ran (see 'after DoH resolver fallback' above) and the connection \
         still failed. Next steps: point HUNTSMAN_DOH_URL at a different DoH endpoint, \
         set Android's system-wide Private DNS (Settings > Network > Private DNS) to a \
         resolver your carrier doesn't filter, or point HUNTSMAN_SEEKNOW_BASE at a \
         reachable https base for the same API."
            .to_string()
    } else if detail.contains(CURL_EXIT_6_MARKER) {
        // A genuine DNS failure, but the automatic retry did NOT run — the
        // only way that happens is HUNTSMAN_DOH_URL disabling the fallback.
        "This is a DNS resolution failure (could not resolve host), and the automatic \
         DoH retry did not run for this request — check whether HUNTSMAN_DOH_URL is set \
         to 'off'/'none' and clear it to re-enable the fallback. Next steps: clear \
         HUNTSMAN_DOH_URL (or point it at a specific DoH endpoint), set Android's \
         system-wide Private DNS (Settings > Network > Private DNS) to a resolver your \
         carrier doesn't filter, or point HUNTSMAN_SEEKNOW_BASE at a reachable https base \
         for the same API."
            .to_string()
    } else {
        // Not a DNS failure at all (timeout, connection-refused, TLS, …) — the
        // DoH fallback never applies here, so don't claim it was tried.
        "This is a network connectivity failure, not a DNS resolution problem — the \
         automatic DoH fallback only applies to unresolvable hosts, so it did not run for \
         this request. Verify general internet connectivity and any outbound proxy/firewall \
         settings, or point HUNTSMAN_SEEKNOW_BASE at a reachable https base for the same API."
            .to_string()
    }
}

/// The loaded `HUNTSMAN_*` key names, sorted for stable, run-to-run-identical
/// output — `loaded` is a `HashMap`, so an unsorted iteration would print a
/// different order on every invocation against the identical environment
/// (the standing "no HashMap-iteration-order leaks into output" rule),
/// exactly the class of bug `rank_unset_keys` just below already guards
/// against for the unset-keys listing.
///
/// Pure over the loaded map so it is unit-testable without touching the real
/// environment.
/// Whether `loaded` holds a USABLE credential for `k` — the predicate the
/// unset-keys listing ranks by.
///
/// Named rather than inline so the production call site and its regression test
/// exercise the same code. As a closure at the call site it read
/// `loaded.contains_key(k)`, i.e. name presence, and since every one of these
/// names ships in the env template that suppressed the entire remediation
/// section on any freshly provisioned device.
fn key_slot_is_filled(loaded: &std::collections::HashMap<String, String>, k: &str) -> bool {
    loaded.get(k).is_some_and(|v| keys::is_configured_value(v))
}

/// What to say when the reactive module-health tracker is empty.
///
/// Empty means one of two very different things and the code said the same
/// thing for both. The section is per-process and reactive — `record_success` /
/// `record_failure` fire only from `core::engine::dispatch` — and a standalone
/// `hse doctor` dispatches nothing, so the tracker is ALWAYS empty there and
/// "no modules currently show a failure streak" was a constant, not a
/// measurement. On a real device it printed that clean bill of health directly
/// above the Scraper health section listing 22 sources in a failure streak.
///
/// `observed` distinguishes them: both recorders `entry(name).or_default()`, so
/// `0` means nothing ran, and non-zero with no unhealthy entries means
/// everything that ran is genuinely healthy — which IS a verdict worth stating.
///
/// Named rather than inline so the production caller and its test exercise the
/// same code.
fn empty_module_health_line(observed: usize) -> &'static str {
    if observed == 0 {
        "Module health: not measured — no modules ran in this process. \
         See `Scraper health` below for outcomes recorded across recent scans."
    } else {
        "Module health: no modules currently show a failure streak"
    }
}

fn sorted_huntsman_keys(loaded: &std::collections::HashMap<String, String>) -> Vec<&str> {
    let mut keys: Vec<&str> = loaded
        .iter()
        // The VALUE decides, not the name. `hse provision` writes a full
        // template of `insert_..._here` slots, so a name-only filter reported
        // every unfilled slot as a loaded key: on a freshly provisioned device
        // this line said "62 keys loaded" while provision had just said
        // "real values: 0" and the WiGLE/SeekNow sections below — which go
        // through `keys::resolve_key` — correctly said NOT CONFIGURED.
        .filter(|(k, v)| k.starts_with("HUNTSMAN_") && keys::is_configured_value(v))
        .map(|(k, _)| k.as_str())
        .collect();
    keys.sort_unstable();
    keys
}

/// Render one module's health line for the `hse doctor` report.
///
/// Pure over a [`crate::core::engine::ModuleHealth`] snapshot so it is
/// unit-testable without touching real dispatch state.
fn format_module_health(h: &crate::core::engine::ModuleHealth) -> String {
    match h.last_success_at {
        Some(t) => format!(
            "{:<20} {} consecutive failure{} (last succeeded {})",
            h.name,
            h.consecutive_failures,
            if h.consecutive_failures == 1 { "" } else { "s" },
            crate::util::timefmt::compact_utc(t),
        ),
        None => format!(
            "{:<20} {} consecutive failure{} (never succeeded this process)",
            h.name,
            h.consecutive_failures,
            if h.consecutive_failures == 1 { "" } else { "s" },
        ),
    }
}

/// Run the live capability preflight and print a per-module alive/empty/
/// unreachable/panicked table plus a one-line summary. Shares the exact probe
/// implementation the weekly `live_drift` sweep uses
/// ([`crate::selftest::capability_probe`]), so what the operator sees on-device and
/// what CI asserts can never diverge. Confirmed drift (a curated canary that
/// reached its provider yet parsed nothing, or any module that panicked on the
/// live response) is called out explicitly.
async fn print_live_capability_report() {
    use crate::selftest::capability_probe::{self, ProbeOutcome};

    println!("\nLive capability probe (keyless modules):");
    // Bounded concurrency — a full-fleet sweep without a socket storm on a phone.
    let reports = capability_probe::probe_keyless_fleet(8).await;
    if reports.is_empty() {
        println!("  (no keyless modules with a probeable target)");
        return;
    }

    let (mut alive, mut empty, mut unreachable, mut timed_out, mut panicked) =
        (0usize, 0usize, 0usize, 0usize, 0usize);
    let mut drift: Vec<&str> = Vec::new();
    for r in &reports {
        let canary = if capability_probe::is_canary(r.module) {
            " [canary]"
        } else {
            ""
        };
        match &r.outcome {
            ProbeOutcome::Alive { found } => {
                alive += 1;
                println!("  alive        {:<22} {found} found{canary}", r.module);
            }
            ProbeOutcome::Empty => {
                empty += 1;
                let tag = if r.is_confirmed_drift() {
                    " — DRIFT (canary parsed nothing)"
                } else {
                    ""
                };
                println!(
                    "  empty        {:<22} ({} {}){canary}{tag}",
                    r.module,
                    r.kind.canonical_str(),
                    r.value
                );
                if r.is_confirmed_drift() {
                    drift.push(r.module);
                }
            }
            ProbeOutcome::Unreachable { reason } => {
                unreachable += 1;
                println!("  unreachable  {:<22} {reason}{canary}", r.module);
            }
            ProbeOutcome::TimedOut => {
                timed_out += 1;
                println!("  timed-out    {:<22}{canary}", r.module);
            }
            ProbeOutcome::Panicked { message } => {
                panicked += 1;
                println!("  panicked     {:<22} {message}{canary}", r.module);
                // Unconditional, canary or not — see the module doc comment.
                drift.push(r.module);
            }
        }
    }
    println!(
        "  summary: {} probed — {alive} alive, {empty} empty, {unreachable} unreachable, \
         {timed_out} timed-out, {panicked} panicked",
        reports.len()
    );
    if !drift.is_empty() {
        println!(
            "  ⚠ confirmed drift in {}: {} — the upstream wire shape likely changed",
            drift.len(),
            drift.join(", ")
        );
    }
    // Persist so this finding survives past this one printout — the next
    // (offline, free) `hse doctor` run can surface it without a live re-probe.
    capability_probe::record_confirmed_drift(&reports);
}

/// The `curl:      MISSING` diagnostic body — every module/command that shells
/// out to the `curl` binary with NO reqwest fallback, so it silently fails
/// rather than erroring when curl is absent. Verified against the current
/// codebase (not every module that mentions curl qualifies — e.g. `geocode`
/// tries reqwest first and only falls back to curl, so curl's absence there
/// just loses a fallback, not the whole feature):
/// - `search_engines`, `social_probe` (default modules), `see_know`,
///   `oathnet_pro`, `api_key_probe`, `abn_lookup` — each calls a curl
///   subprocess directly (or via `util::see_know`/`util::oathnet`'s
///   `CurlClient`) with no other transport, so the module returns nothing.
/// - `hse keys validate` / `hse keys import-tsv --validate`
///   (`util::key_pool::validation::validate_against_endpoint`) — a failed
///   `curl` spawn is swallowed into `false`, the SAME return value as a
///   genuinely dead key, so every key in the pool reports INVALID rather
///   than the command erroring — a materially worse failure mode than
///   "returns nothing", since it looks like the key pool died, not that a
///   tool is missing.
fn curl_missing_message() -> String {
    "  curl:      MISSING — search_engines + social_probe (default modules), plus\n             \
     see_know, oathnet_pro, api_key_probe and abn_lookup, shell out to curl and\n             \
     will silently return nothing. `hse keys validate` / `hse keys import-tsv\n             \
     --validate` also shell out to curl — without it they report every key as\n             \
     INVALID rather than erroring, which reads as a dead key pool, not a missing\n             \
     tool. Install it: pkg install curl"
        .to_string()
}

/// Rank every unset `KNOWN_KEYS` env var by acquisition ROI, highest first.
///
/// `key_roi` tiers a service by how far a key cascades into more collection:
/// a **Multiplier** (Shodan, Hunter, the breach pools, …) discovers
/// infrastructure / identities / credentials that feed back into MORE modules
/// and MORE keys; **Expansion** adds depth without chaining; **Terminal** is
/// one-and-done. So the operator who registers a multiplier-tier key first
/// unlocks the most downstream acquisition per signup. Ties within a tier sort
/// by name for stable, run-to-run-identical output.
///
/// Pure over an `is_present` predicate (true if the env var is already set) so
/// it is unit-testable without touching the filesystem or environment.
// The unset-key acquisition ranking is the single source of truth in
// `util::key_roi` (shared with the web Settings page's acquisition guidance).
use crate::util::key_roi::rank_unset_keys;

/// Render the "Weak findings" doctor section body. `anomalies` is expected
/// already weakest-first ([`crate::storage::Store::low_confidence_evidence`]'s
/// own `ORDER BY confidence ASC`); this only formats, so it is unit-testable
/// without a store — mirroring [`scraper_health::aggregate_source_health`]'s
/// separation of query (impure) from presentation (pure).
fn format_weak_findings(anomalies: &[EvidenceAnomaly]) -> String {
    if anomalies.is_empty() {
        return "  no weak findings in the tracked window\n".to_string();
    }
    let mut out = format!(
        "  {} weak finding(s) — review before trusting as evidence:\n",
        anomalies.len()
    );

    // Per-module totals first. One module emitting at a flat floor dominates the
    // raw list entirely, so the counts are the only place its share is legible:
    // a real report showed 1346 findings whose every printed row was the same
    // module at the same confidence, which reads as "1346 things to review"
    // rather than "one module emits 1340 speculative pivots at its floor".
    let mut tally: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
    for a in anomalies {
        *tally.entry(a.module_name.as_str()).or_default() += 1;
    }
    // Sorted into a total order (count desc, then name) — a HashMap's iteration
    // order is arbitrary, and a diagnostic report that reshuffles between runs on
    // identical data is not one an operator can diff.
    let mut counts: Vec<(&str, usize)> = tally.into_iter().collect();
    counts.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(b.0)));
    out.push_str("    by module: ");
    out.push_str(
        &counts
            .iter()
            .map(|(m, n)| format!("{m} {n}"))
            .collect::<Vec<_>>()
            .join(", "),
    );
    out.push('\n');

    // Then a sample, capped PER MODULE.
    //
    // The rows are weakest-first, and the weakest confidence any module routinely
    // emits is a flat speculative floor — so an unbounded `take(SHOWN)` printed
    // that one module's rows and nothing else, every time. The entities this
    // section exists to surface (a breach-pool near-miss demoted to 0.25, say)
    // were unreachable without lowering the threshold below the floor, which
    // prints nothing at all. Capping per module guarantees every module with
    // weak findings is represented.
    const SHOWN: usize = 20;
    const PER_MODULE: usize = 3;
    let mut printed_per_module: std::collections::HashMap<&str, usize> =
        std::collections::HashMap::new();
    let mut printed = 0usize;
    for a in anomalies {
        if printed >= SHOWN {
            break;
        }
        // Lookup only — the ROWS keep `anomalies`' own weakest-first order, so
        // the map's arbitrary iteration order never reaches the output.
        let seen = printed_per_module
            .entry(a.module_name.as_str())
            .or_insert(0);
        if *seen >= PER_MODULE {
            continue;
        }
        *seen += 1;
        printed += 1;
        let observed = timefmt::ymd_utc(a.created_at).unwrap_or_else(|| "unknown date".to_string());
        // uid is a SHA-256 hex digest; the first 12 chars are enough to
        // cross-reference against `hse export`/`--output json` without
        // flooding the terminal with the full 64-char hash per row.
        let short_uid = &a.entity_uid[..a.entity_uid.len().min(12)];
        out.push_str(&format!(
            "    - conf={:.2}  {:<24} {}…  observed {}\n",
            a.confidence, a.module_name, short_uid, observed
        ));
    }
    if anomalies.len() > printed {
        out.push_str(&format!(
            "    … and {} more (at most {PER_MODULE} shown per module)\n",
            anomalies.len() - printed
        ));
    }
    out
}

#[cfg(test)]
mod tests {
    include!("tests.rs");
}
