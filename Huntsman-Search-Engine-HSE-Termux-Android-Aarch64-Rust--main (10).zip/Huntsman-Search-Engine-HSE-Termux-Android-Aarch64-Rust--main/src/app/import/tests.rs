//! Unit tests for the import parsers and persistence.
//!
//! Split out of the module file; reaches private parsers/helpers via
//! `use super::*` (each parser is re-exported into the parent's scope).

use super::{
    ImportFormat, MAX_IMPORT_BYTES, cmd_import, deduplicate_by_uid, detect_import_format,
    entities_from_upload, looks_like_dossier, parse_dossier, parse_oathnet_html,
};

#[test]
fn max_import_bytes_is_the_documented_16_mib() {
    // The single source of truth (Pass 30) for the single-file import cap,
    // the local-storage scrape's per-file cap, and (via an `as usize` cast)
    // api::scan_handlers::MAX_UPLOAD_BYTES. Pin the literal value here so an
    // accidental edit is caught where the authority actually lives.
    assert_eq!(MAX_IMPORT_BYTES, 16 * 1024 * 1024);
}

#[test]
fn detect_import_format_is_content_based_not_extension_gated() {
    // The bug: the CLI only recognised a dossier/combined/stealer/OathNet-report
    // text export under a `.txt` extension, so the SAME content saved under any
    // other name (or none) was mis-routed to the JSON parser and rejected. The
    // detector now keys on CONTENT, so the format is identical regardless of the
    // filename — and the CLI and web upload share this one decision.
    let dossier = "Entry #1:\n   \u{2022} email: a@b.com\n";
    for path in ["dump.dat", "dump.txt", "breach", "x.json", ""] {
        assert_eq!(
            detect_import_format(path, dossier),
            ImportFormat::Dossier,
            "dossier content must be detected regardless of the filename ({path:?})"
        );
    }
    // A JSON object wins before the text heuristics (so a `{`-body is never
    // mis-keyed), by content alone — no `.json` extension required.
    assert_eq!(
        detect_import_format("export", "{\"exportInfo\":{}}"),
        ImportFormat::OathnetJson
    );
    // HTML by content even without the `.html` extension.
    assert_eq!(
        detect_import_format("page", "<!doctype html><html></html>"),
        ImportFormat::OathnetHtml
    );
    // CSV by the `.csv` hint even when the content is ambiguous.
    assert_eq!(
        detect_import_format("table.csv", "a,b,c\n1,2,3"),
        ImportFormat::DehashedCsv
    );
    // Unrecognised plain text falls to the OathNet-TXT catch-all (graceful — the
    // same final `else` the web upload uses), never a hard error.
    assert_eq!(
        detect_import_format("notes.dat", "just some unstructured prose"),
        ImportFormat::OathnetTxt
    );
}

#[test]
fn detect_import_format_ignores_a_leading_utf8_bom() {
    // Regression: a UTF-8 BOM (U+FEFF) is not whitespace, so `trim_start` left it in
    // place and a BOM-prefixed export (common from Excel / Windows exporters) was
    // misrouted to the wrong parser and silently dropped every entity. It must now
    // detect by its real first token.
    assert_eq!(
        detect_import_format("", "\u{feff}{\"exportInfo\":{}}"),
        ImportFormat::OathnetJson
    );
    assert_eq!(
        detect_import_format("", "\u{feff}<!doctype html><html></html>"),
        ImportFormat::OathnetHtml
    );
    assert_eq!(
        detect_import_format("table.csv", "\u{feff}a,b,c\n1,2,3"),
        ImportFormat::DehashedCsv
    );
}

/// The upload dispatcher parses UNTRUSTED text from the web endpoint, so it
/// must never panic — not on truncation, not on a multibyte codepoint landing
/// next to a structural marker (`@`, `->`, `•`, `:`, a section header), not on
/// malformed JSON/HTML. This pins that contract: every hostile input returns
/// Ok/Err, never unwinds. (Panic = abort is off, but a 500 from a paste is
/// still a defect.)
#[tokio::test]
async fn upload_dispatcher_never_panics_on_adversarial_input() {
    let bomb = "é".repeat(4000); // multibyte filler
    let cases: Vec<String> = vec![
            String::new(),
            " \t\n ".into(),
            "@".into(),
            "->".into(),
            "\u{2022}".into(),                                   // lone bullet
            "Entry #".into(),                                    // truncated header
            "Entry #\u{2022}:é".into(),                          // bullet+multibyte at header
            format!("Entry #1:\n   \u{2022} email: {bomb}@"),    // dangling local@
            format!("EMAILS:\n  -> {bomb}@{bomb}"),              // huge no-TLD email
            "USERNAMES:\n->".into(),                             // empty list item
            "\u{2022} : value".into(),                           // empty key
            "URL: \nUsername: \nPassword: ".into(),              // empty TXT fields
            "=== INFECTED MACHINES".into(),                      // section marker, no body
            "=== OSINT ENRICHMENT\nIP: \nlat: zzz\nlon: ".into(),// bad geo numbers
            "{".into(),                                          // truncated JSON
            "{}".into(),
            r#"{"searchResults":{"MULTI_SERVICE_RESULTS":{"breach":{"data":{"results":[null,1,"x"]}}}}}"#.into(),
            r#"{"stealerData":{"victims":[{"device_ips":[1,null,"1.2.3.4"]}]}}"#.into(),
            "<html>".into(),
            format!("<html>{bomb}@{bomb}.com http://{bomb}</html>"),
            // Section markers butted against multibyte text.
            format!("PASSWORDS:é\n-> é{bomb}"),
            "Entry #1:\n   \u{2022} name: é\n   \u{2022} hash: $2a$".into(),
            // Truncated Stealerlogs block: a victim with a dangling Password key,
            // and a `[N]` marker with a multibyte value where a domain belongs.
            format!("Module: Stealerlogs\nVictims:\n  [1]\n    Credentials:\n      [1]\n        Password:\n    Domains:\n      [1]\n        é{bomb}"),
            // Truncated OathNet report: a header, an entry with a dangling field
            // and a multibyte name butted against the OSINT marker.
            format!("=== DATABASE LOGS ===\nEntry 1:\nemail:\nfull name: é{bomb}\n=== OSINT ENRICHMENT\nIP: \nlat: x"),
        ];
    for (i, input) in cases.iter().enumerate() {
        // The await completing at all is the assertion — a panic would unwind
        // through here and fail the test.
        let r = entities_from_upload(input, "fuzz", None).await;
        // Whatever the outcome, entities (if any) must be well-formed.
        if let Ok((ents, _)) = r {
            for e in &ents {
                assert!(
                    !e.value.is_empty(),
                    "case {i}: produced an empty-value entity"
                );
            }
        }
    }
}

#[tokio::test]
async fn upload_dispatcher_routes_every_format_to_its_parser() {
    use crate::core::entity::EntityKind;
    let has = |ents: &[crate::core::entity::Entity], k: EntityKind, v: &str| {
        ents.iter().any(|e| e.kind == k && e.value == v)
    };

    // HTML export → regex extraction of domains/emails/IPs.
    let (html, label) = entities_from_upload(
        "<html><body>contact me at jo@acme-corp.com on acme-corp.com</body></html>",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-html");
    assert!(has(&html, EntityKind::Email, "jo@acme-corp.com"));

    // Dossier compilation → per-entry correlation.
    let (dos, label) = entities_from_upload(
        "Entry #1:\n   \u{2022} email: isaacfrost@gmail.com\n   \u{2022} name: Isaac Frost\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "dossier");
    assert!(has(&dos, EntityKind::Email, "isaacfrost@gmail.com"));
    assert!(has(&dos, EntityKind::Person, "Isaac Frost"));

    // OathNet stealer-log TXT → the catch-all text branch.
    let (txt, label) = entities_from_upload(
        "URL: https://admin.target.io/login\nUsername: victim\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(txt.iter().any(|e| e.kind == EntityKind::Url));

    // DeHashed CSV export → the breach-table branch.
    let (csvents, label) = entities_from_upload(
        "id,email,username,name,database_name,password,phone\n\
         1,jordanavery@gmail.com,javery,Jordan Avery,ExampleBreach,Hunter2pass,+61412345678\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "dehashed-csv");
    assert!(has(&csvents, EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(&csvents, EntityKind::Person, "Jordan Avery"));

    // Combined Search aggregator export → the breach-aggregator branch.
    let (comb, label) = entities_from_upload(COMBINED, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "combined-search");
    assert!(has(&comb, EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(&comb, EntityKind::Person, "Jordan Avery"));

    // HSE's own CSV export → round-trip branch (not the DeHashed table).
    let hse = "kind,value,raw_value,confidence,c_effective,corroboration,classification,observed_at,sources,evidence_urls,evidence,tags\n\
        person,Jordan Avery,Jordan Avery,0.850,1.000,3,VERIFIED,1,name_intel,,[name_intel] x,au\n";
    let (hents, label) = entities_from_upload(hse, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "hse-csv");
    assert!(has(&hents, EntityKind::Person, "Jordan Avery"));

    // JSON API export → parsed (and the label proves the branch).
    let (_json, label) = entities_from_upload(
        r#"{"exportInfo":{"query":"x"},"searchResults":{}}"#,
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-json");

    // Malformed JSON is a clean error, not a panic.
    assert!(
        entities_from_upload("{ not valid json", "s", None)
            .await
            .is_err()
    );
}

#[tokio::test]
async fn oathnet_json_stealer_victim_emits_every_distinct_field_uncapped() {
    use crate::core::entity::EntityKind;
    // A single stealer victim record carrying MORE than the old, arbitrary
    // per-field caps (device_ips: 10, device_emails: 20, hwids: 5,
    // discord_ids: 5, device_users: 5) — every one of these array fields is
    // whatever the upstream OathNet API returned, with no dedup/validation
    // reason to cap any of them (unlike e.g. push_crypto's checksum gate).
    let device_ips: Vec<String> = (0..15).map(|i| format!("10.0.0.{i}")).collect();
    let device_emails: Vec<String> = (0..25).map(|i| format!("user{i}@victim-host.io")).collect();
    let hwids: Vec<String> = (0..8).map(|i| format!("HWID-{i}")).collect();
    let discord_ids: Vec<String> = (0..8).map(|i| format!("discord#{i}")).collect();
    let device_users: Vec<String> = (0..8).map(|i| format!("winuser{i}")).collect();
    let body = serde_json::json!({
        "stealerData": {
            "victims": [{
                "device_ips": device_ips,
                "device_emails": device_emails,
                "hwids": hwids,
                "discord_ids": discord_ids,
                "device_users": device_users,
            }]
        }
    })
    .to_string();
    let (ents, label) = entities_from_upload(&body, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "oathnet-json");
    let count = |k: EntityKind, tag: &str| {
        ents.iter()
            .filter(|e| e.kind == k && e.has_tag(tag))
            .count()
    };
    assert_eq!(
        count(EntityKind::IpAddress, "stealer-victim"),
        15,
        "every distinct device IP must be emitted, not capped at the old 10"
    );
    assert_eq!(
        count(EntityKind::Email, "stealer-victim"),
        25,
        "every distinct device email must be emitted, not capped at the old 20"
    );
    assert_eq!(
        count(EntityKind::DeviceId, "hwid"),
        8,
        "every distinct HWID must be emitted, not capped at the old 5"
    );
    assert_eq!(
        count(EntityKind::Username, "discord-id"),
        8,
        "every distinct Discord ID must be emitted, not capped at the old 5"
    );
    assert_eq!(
        count(EntityKind::Username, "device-user"),
        8,
        "every distinct device user must be emitted, not capped at the old 5"
    );
}

#[tokio::test]
async fn oathnet_json_ip_admission_recovers_ipv6_and_rejects_bogus() {
    use crate::core::entity::EntityKind;
    // The IP fields (breach `ip`, victim `device_ips`) are admitted iff they
    // parse as a real `IpAddr`. The old `contains('.')` guard silently dropped
    // every IPv6 address (no dots) and admitted out-of-range dotted-quads like
    // `999.999.999.999`. Both regressions are pinned here.
    // Public addresses are used deliberately: the shared `deduplicate_by_uid`
    // finalizer drops documentation/reserved ranges (2001:db8::/32, 203.0.113.x)
    // via `is_bogus_ip`, so a doc IP would be filtered downstream and mask the
    // parse-gate behaviour under test here.
    let body = serde_json::json!({
        "searchResults": {
            "MULTI_SERVICE_RESULTS": {
                "breach": { "data": { "results": [
                    { "ip": "2606:4700:4700::1111", "dbname": "ExampleBreach" },
                    { "ip": "999.999.999.999", "dbname": "ExampleBreach" },
                ] } }
            }
        },
        "stealerData": {
            "victims": [{
                "device_ips": ["2001:4860:4860::8888", "256.300.1.1", "8.8.8.8"],
            }]
        }
    })
    .to_string();
    let (ents, _label) = entities_from_upload(&body, "s", None)
        .await
        .expect("should succeed");
    let ips: std::collections::HashSet<&str> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        ips.contains("2606:4700:4700::1111"),
        "a breach IPv6 address must now be recovered, not dropped by contains('.')"
    );
    assert!(
        ips.contains("2001:4860:4860::8888"),
        "a victim device IPv6 address must now be recovered"
    );
    assert!(
        ips.contains("8.8.8.8"),
        "a valid public IPv4 must still be admitted"
    );
    assert!(
        !ips.contains("999.999.999.999") && !ips.contains("256.300.1.1"),
        "out-of-range dotted-quads must be rejected by the IpAddr parse gate"
    );
}

#[tokio::test]
async fn import_extracts_wifi_bssid_as_geolocation_seed() {
    use crate::core::entity::EntityKind;
    // A stealer-log-shaped body carrying the victim's router BSSID.
    let (ents, label) = entities_from_upload(
        "URL: https://x.com/login\nUsername: victim\nRouter BSSID: A4:B1:C2:00:11:22\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::MacAddress
            && e.value == "a4:b1:c2:00:11:22"
            && e.has_tag("bssid")),
        "the BSSID must become a MacAddress geolocation seed"
    );
}

#[tokio::test]
async fn import_extracts_every_distinct_mac_address_uncapped() {
    use crate::core::entity::EntityKind;
    // 60 distinct BSSIDs — more than the old, arbitrary 50-per-import cap this
    // guards against reintroducing. `push_macs` must emit every one:
    // `crate::util::extract::macs` already dedupes, so the cap protected
    // nothing real.
    let mut body = String::from("URL: https://x.com/login\nUsername: victim\n");
    for i in 0..60u32 {
        body.push_str(&format!("Router BSSID: A4:B1:C2:00:11:{i:02X}\n"));
    }
    let (ents, _label) = entities_from_upload(&body, "s", None)
        .await
        .expect("should succeed");
    let mac_count = ents
        .iter()
        .filter(|e| e.kind == EntityKind::MacAddress)
        .count();
    assert_eq!(
        mac_count, 60,
        "every distinct BSSID must be emitted, not capped at the old arbitrary 50"
    );
}

#[tokio::test]
async fn import_extracts_crypto_wallet_as_chain_seed() {
    use crate::core::entity::EntityKind;
    // The genesis Bitcoin address — checksum-valid, so it survives validation.
    let (ents, label) = entities_from_upload(
        "URL: https://x.com\nWallet: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::CryptoAddress
            && e.value
                .eq_ignore_ascii_case("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa")
            && e.has_tag("crypto-address")),
        "the wallet must become a CryptoAddress chain seed"
    );
}

#[tokio::test]
async fn import_extracts_leaked_api_key_from_body() {
    use crate::core::entity::EntityKind;
    // An AWS access-key ID sitting loose in the log (not a `service: key` line).
    let (ents, label) = entities_from_upload(
        "URL: https://x.com\nleftover config had AKIAZ3XK7P2QWERT5YBN in it\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::ApiKey && e.has_tag("api-key") && e.has_tag("stealer")),
        "the loose AWS key must be recovered as an ApiKey finding"
    );
}

#[tokio::test]
async fn dehashed_csv_also_mines_wallets_from_any_field() {
    use crate::core::entity::EntityKind;
    // The breach "password" field is itself a wallet — the table scan recovers it.
    let (ents, label) = entities_from_upload(
        "id,email,username,database_name,password\n\
         1,a@b.com,x,Breach,1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "dehashed-csv");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::CryptoAddress && e.has_tag("dehashed")),
        "the DeHashed table scan must recover a wallet from any field"
    );
}

#[tokio::test]
async fn import_extracts_iban_as_financial_finding() {
    use crate::core::entity::EntityKind;
    let (ents, label) = entities_from_upload(
        "URL: https://x.com\nBank account: GB82WEST12345698765432\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Other("iban".into())
                && e.value == "GB82WEST12345698765432"
                && e.has_tag("financial")),
        "a checksum-valid IBAN must become a financial finding"
    );
}

#[tokio::test]
async fn import_extracts_labeled_ssid_for_wigle_geolocation() {
    use crate::core::entity::EntityKind;
    let (ents, label) = entities_from_upload(
        "URL: https://x.com\nUsername: victim\nSSID: Smith Home 5G\n",
        "s",
        None,
    )
    .await
    .expect("should succeed");
    assert_eq!(label, "oathnet-txt");
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::Ssid
            && e.value == "Smith Home 5G"
            && e.has_tag("wifi-network")),
        "a labelled SSID must become an Ssid entity (a WiGLE geolocation seed)"
    );
}
use crate::core::entity::{Entity, EntityKind};

// The exact shape of the user-provided "Isaac Frost.txt" dossier upload.
const DOSSIER: &str = "http://www.linkedin.com/in/isaac-frost-42474a122
    Entry #82:
       \u{2022} username: zacfrost512
       \u{2022} email: zacfrost512@gmail.com
       \u{2022} name: Isaac Frost
       \u{2022} _domain: gmail.com
       \u{2022} ip: 8.8.8.8
       \u{2022} phone: +61412345678
       \u{2022} id: 9540629
       \u{2022} created: 2016-02-19 15:57:12
       \u{2022} language: en
    Entry #85:
       \u{2022} username: IsaacFrost6
       \u{2022} email: frostisms@gmail.com
       \u{2022} name: Isaac Frost
       \u{2022} domain: derbyrock.com
       \u{2022} ip: 203.0.113.45
       \u{2022} birthdate: 2002-11-17
       \u{2022} country: GB
       \u{2022} gender: M
       \u{2022} hash: $2a$10$id3HAw6TcOjKvPH/RK7MS.
USERNAMES:
  -> isaac frost
  -> a_frost_life
  -> isaac@derbyrock.com
EMAILS:
  -> betocastillo097@gmail.com
  -> @gmail
PASSWORDS:
  -> 00346D91DD87C74089F3BFA88E13DE8101000000DCB6
";

#[test]
fn dossier_is_detected_and_oathnet_txt_is_not() {
    assert!(looks_like_dossier(DOSSIER));
    assert!(!looks_like_dossier(
        "URL: https://x.com/login\nUsername: bob\nPassword: hunter2\n"
    ));
}

use super::combined::{
    looks_like_combined_search, parse_combined_search, parse_combined_search_json,
};
use super::csv::{looks_like_dehashed_csv, looks_like_hse_csv, parse_dehashed_csv, parse_hse_csv};
use super::local::{collect_importable_files, import_local_dir_entities};
use super::oathnet_report::{looks_like_oathnet_report, parse_oathnet_report};
use super::stealer::{looks_like_stealerlogs, parse_stealerlogs};

// A synthetic HSE entity CSV export (the exact column order HSE writes).
const HSE_CSV: &str = "kind,value,raw_value,confidence,c_effective,corroboration,classification,observed_at,sources,evidence_urls,evidence,tags\n\
person,Jordan Avery,Jordan Avery,0.850,1.000,3,VERIFIED,1782117614,au_people|name_intel,,\"[name_intel] Name found || [au_people] Residential match, Carlton\",au|verified\n\
email,jordanavery@gmail.com,jordanavery@gmail.com,0.720,0.800,2,PROBABLE,1782117614,dehashed,,[dehashed] Breach record,breach\n\
other:au-postcode,2000,2000,0.900,0.900,1,VERIFIED,1782117614,au_geo,,[au_geo] ASGS postcode,au\n";

#[test]
fn hse_csv_is_detected_and_distinct_from_dehashed() {
    assert!(looks_like_hse_csv(HSE_CSV));
    assert!(!looks_like_dehashed_csv(HSE_CSV)); // no email/db columns in HSE's header
    assert!(!looks_like_hse_csv(
        "id,email,username,database_name\n1,a@b.com,x,Y\n"
    ));
}

#[test]
fn hse_csv_round_trips_kind_value_confidence_tags_and_evidence() {
    let (ents, _stats) = parse_hse_csv(HSE_CSV, "s");
    // Person row: kind, value, confidence, tags (original + provenance), and the
    // two-source evidence trail are all restored.
    let p = ents
        .iter()
        .find(|e| e.kind == EntityKind::Person && e.value == "Jordan Avery")
        .expect("person row");
    assert!((p.confidence - 0.85).abs() < 0.01);
    assert!(p.has_tag("au") && p.has_tag("verified") && p.has_tag("hse-csv"));
    let srcs: Vec<&str> = p.evidence.iter().map(|ev| ev.source.as_str()).collect();
    assert!(srcs.contains(&"name_intel") && srcs.contains(&"au_people"));
    // The quoted summary with an internal comma survived the RFC-4180 reader.
    assert!(p.evidence.iter().any(|ev| ev.summary.contains("Carlton")));
    // The Other("au-postcode") kind round-trips.
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Other("au-postcode".into()) && e.value == "2000")
    );
    assert!(ents.iter().any(|e| e.kind == EntityKind::Email));
}

// Synthetic Combined Search export (no real PII): a module-metadata block plus
// two result records, exercising inline header values AND next-line values.
const COMBINED: &str = "Module: Combined Search
Query: javery
Search Type: Username
Results: 2

  [1]
    Key:
      snusbase
    Source Type:
      snusbase
    Status:
      results
    Count:
      2
    Results:
      [1]
        Username:
          javery
        Email:
          jordanavery@gmail.com
        Name:
          Jordan Avery
        Password:
          Hunter2pass
        Source:
          2089_EXAMPLE_BREACH_122025
      [2]
        Email:
          jordan2@example.com
        Hash:
          e1436d06a8b5f6decbf31371d9da13fc
        Lastip:
          24.32.96.70
        Source:
          2042_EXAMPLE_TECH_012024
";

#[test]
fn combined_search_is_detected() {
    assert!(looks_like_combined_search(COMBINED));
    assert!(!looks_like_combined_search(
        "URL: https://x.com/login\nUsername: bob\n"
    ));
}

#[test]
fn combined_search_parses_records_and_skips_metadata() {
    let (ents, stats) = parse_combined_search(COMBINED, "s");
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);
    // Record 1.
    assert!(has(EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(EntityKind::Username, "javery"));
    assert!(has(EntityKind::Person, "Jordan Avery"));
    assert!(has(EntityKind::Credential, "Hunter2pass"));
    // Record 2: a hash credential and a last-login IP.
    assert!(has(EntityKind::Email, "jordan2@example.com"));
    assert!(has(
        EntityKind::Credential,
        "e1436d06a8b5f6decbf31371d9da13fc"
    ));
    assert!(has(EntityKind::IpAddress, "24.32.96.70"));
    // Two result records; the module-metadata block emitted nothing.
    assert_eq!(stats.breach_records, 2);
    // The source database rides on the evidence.
    let em = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email && e.value == "jordanavery@gmail.com")
        .expect("should succeed");
    assert!(em.evidence.iter().any(|ev| {
        ev.attributes
            .get("source")
            .is_some_and(|v| v.contains("EXAMPLE_BREACH"))
    }));
}

// Two result records under one module, spelling the SAME real public IPv6
// address (Google Public DNS) two different ways — expanded vs compressed.
// Not an RFC 3849 documentation address on purpose: `is_bogus_ip` rejects the
// documentation range, which would mask the dedup gap behind a fixture the
// gate rejects in both old and new code either way.
const COMBINED_REPEATED_IP: &str = "Module: Combined Search
Query: javery
Search Type: Username
Results: 2

  [1]
    Key:
      snusbase
    Results:
      [1]
        Username:
          javery
        Ip:
          2001:4860:4860:0000:0000:0000:0000:8888
      [2]
        Username:
          javery
        Lastip:
          2001:4860:4860::8888
";

#[test]
fn combined_search_dedups_an_expanded_and_a_compressed_ipv6_spelling() {
    // Regression: a bare clone of the raw string doesn't canonicalise the
    // way `core::entity::normalise` does, so an expanded and a compressed
    // spelling of the same IPv6 address each earned their own dedup slot
    // despite colliding on the same uid once `Entity::new` constructs them.
    let (ents, _stats) = parse_combined_search(COMBINED_REPEATED_IP, "s");
    let ips: Vec<&Entity> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .collect();
    assert_eq!(
        ips.len(),
        1,
        "an expanded and a compressed spelling of the same IPv6 address must dedup to one entity: {ips:?}"
    );
}

// A real-world Combined Search aggregator export echoes each module's results
// TWICE: once nested under a "Modules:" section, and again verbatim under a
// separate top-level "Results:" section (both keyed off the same underlying
// per-module data) — unlike COMBINED above, which only has the single nested
// occurrence. Synthetic placeholders only (no real PII).
const COMBINED_DUPLICATE_TOP_LEVEL_RESULTS: &str = "Module: Combined Search
Query: javery
Search Type: Username
Results: 2

Modules:
  [1]
    Key:
      snusbase
    Source Type:
      snusbase
    Status:
      results
    Count:
      2
    Results:
      [1]
        Username:
          javery
        Email:
          jordanavery@gmail.com
        Name:
          Jordan Avery
        Password:
          Hunter2pass
        Source:
          2089_EXAMPLE_BREACH_122025
      [2]
        Email:
          jordan2@example.com
        Hash:
          e1436d06a8b5f6decbf31371d9da13fc
        Lastip:
          24.32.96.70
        Source:
          2042_EXAMPLE_TECH_012024
    Meta:
      Combined Runner:
        Attempt:
          1
Results:
  [1]
    Key:
      snusbase
    Source Type:
      snusbase
    Status:
      results
    Count:
      2
    Results:
      [1]
        Username:
          javery
        Email:
          jordanavery@gmail.com
        Name:
          Jordan Avery
        Password:
          Hunter2pass
        Source:
          2089_EXAMPLE_BREACH_122025
      [2]
        Email:
          jordan2@example.com
        Hash:
          e1436d06a8b5f6decbf31371d9da13fc
        Lastip:
          24.32.96.70
        Source:
          2042_EXAMPLE_TECH_012024
    Meta:
      Combined Runner:
        Attempt:
          1
Meta:
  Combined:
    true
  Completed Count:
    1
";

#[test]
fn combined_search_does_not_double_count_when_results_echo_the_modules_section() {
    // H (2026-07-06, real-world export review): a paid Combined Search
    // aggregator's actual export repeats every module's results twice — once
    // under "Modules:", again verbatim under a top-level "Results:" — the
    // shape COMBINED_DUPLICATE_TOP_LEVEL_RESULTS reproduces. Entities are
    // already de-duplicated by the per-field `seen` set, but `breach_records`
    // was incremented once per RECORD regardless of whether it was a repeat,
    // so the operator-facing "N breach" count silently doubled for this real
    // export shape — the same fabricated-count bug class already fixed for
    // netlas/psbdmp/pypi_user/rubygems_user/urlscan this cycle.
    let (ents, stats) = parse_combined_search(COMBINED_DUPLICATE_TOP_LEVEL_RESULTS, "s");
    let count =
        |k: EntityKind, v: &str| ents.iter().filter(|e| e.kind == k && e.value == v).count();
    // Exactly one of each entity, not two, despite the record appearing twice.
    assert_eq!(count(EntityKind::Email, "jordanavery@gmail.com"), 1);
    assert_eq!(count(EntityKind::Username, "javery"), 1);
    assert_eq!(count(EntityKind::Person, "Jordan Avery"), 1);
    // The true record count is 2 (one snusbase module, two results), not 4.
    assert_eq!(
        stats.breach_records, 2,
        "the duplicated top-level Results: section must not double the reported breach count"
    );
}

// Synthetic Combined Search JSON export (no real PII) — the breach-aggregator API
// response shape `{ "modules": [ { "results": [ … ] } ] }`. It exercises the
// heterogeneous field types a real multi-source export carries: a `breach` that
// arrives as an INTEGER, a `dbname` that arrives as an ARRAY, a nested `details`
// OBJECT that is not a leaf field, and an error-stub result with no identity
// fields. Emails/persons use non-placeholder values so they survive the import's
// placeholder filter in the end-to-end path.
const COMBINED_JSON: &str = r#"{
  "success": true,
  "query": "javery",
  "mode": "username",
  "count": 3,
  "modules": [
    {
      "key": "snusbase",
      "label": "Snusbase",
      "status": "results",
      "results": [
        {
          "username": "javery",
          "email": "jordanavery@gmail.com",
          "name": "Jordan Avery",
          "password": "Hunter2pass",
          "breach": 2844,
          "source": "2089_EXAMPLE_BREACH_122025"
        },
        {
          "email": "jordan.reeves@gmail.com",
          "password_hash": "e1436d06a8b5f6decbf31371d9da13fc",
          "lastip": "24.32.96.70",
          "dbname": ["FantasyForum.net", "FuniStream.net"]
        }
      ]
    },
    {
      "key": "seon",
      "label": "SEON",
      "status": "results",
      "results": [
        {
          "email": "jordanavery@gmail.com",
          "details": { "risk_scores": { "global_network_score": 1.3 } },
          "source": "SEON"
        }
      ]
    },
    {
      "key": "xosint",
      "label": "xOsint",
      "status": "results",
      "results": [ { "0": "Server-side errors" } ]
    }
  ]
}"#;

#[test]
fn combined_search_json_extracts_entities_and_coerces_heterogeneous_fields() {
    use crate::core::entity::EntityKind;
    let doc: serde_json::Value = serde_json::from_str(COMBINED_JSON).expect("valid JSON fixture");
    let (ents, stats) = parse_combined_search_json(&doc, "s");
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);
    // snusbase record 1: identity fields + a plaintext credential.
    assert!(has(EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(EntityKind::Username, "javery"));
    assert!(has(EntityKind::Person, "Jordan Avery"));
    assert!(has(EntityKind::Credential, "Hunter2pass"));
    // record 2: a hash credential (from `password_hash`) and a last-login IP.
    assert!(has(EntityKind::Email, "jordan.reeves@gmail.com"));
    assert!(has(
        EntityKind::Credential,
        "e1436d06a8b5f6decbf31371d9da13fc"
    ));
    assert!(has(EntityKind::IpAddress, "24.32.96.70"));
    // The INTEGER `breach` (2844) is coerced to a string and rides on evidence,
    // not silently dropped for being a non-string.
    let em1 = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email && e.value == "jordanavery@gmail.com")
        .expect("should succeed");
    assert!(
        em1.evidence
            .iter()
            .any(|ev| ev.attributes.get("breach").map(String::as_str) == Some("2844")),
        "integer `breach` field must be coerced and preserved on evidence"
    );
    // The ARRAY `dbname` is coerced (joined), not dropped, and rides on evidence.
    let em2 = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email && e.value == "jordan.reeves@gmail.com")
        .expect("should succeed");
    assert!(
        em2.evidence.iter().any(|ev| ev
            .attributes
            .get("dbname")
            .is_some_and(|v| v.contains("FantasyForum.net") && v.contains("FuniStream.net"))),
        "array `dbname` field must be coerced (joined) and preserved on evidence"
    );
    // SEON's nested `details` object is skipped (not a leaf) without crashing the
    // parse, while its email is still captured; the xOsint error stub {"0":"…"}
    // has no identity field and emits nothing. So exactly three real result
    // records were counted, not four.
    assert_eq!(stats.breach_records, 3);
}

#[tokio::test]
async fn upload_dispatcher_imports_combined_search_json_not_zero_entities() {
    use crate::core::entity::EntityKind;
    // Regression: a Combined Search JSON export is a `{`-leading body, so the import
    // detector routes it to the OathNet-native JSON parser — which shares none of
    // its shape and, before the combined-JSON path existed, imported it as ZERO
    // entities, silently discarding every result of a paid multi-source breach
    // search uploaded through the Termux web UI. The upload must now yield the
    // breach entities and label the branch it actually parsed.
    let (ents, label) = entities_from_upload(COMBINED_JSON, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "combined-search-json");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "jordanavery@gmail.com"),
        "combined-search JSON upload must yield its breach entities, not nothing"
    );
    assert!(ents.iter().any(|e| e.kind == EntityKind::Credential));
    assert!(
        ents.len() >= 5,
        "expected the full multi-record entity set, got {}",
        ents.len()
    );
}

#[test]
fn local_scrape_enumerates_deterministically_and_skips_noise() {
    // The local-storage scrape must walk the tree in a fully deterministic order
    // (sorted by path) and skip build/binary noise and hidden/heavy directories,
    // so scraping the same installation always ingests the same files.
    let dir = tempfile::tempdir().expect("should succeed");
    let root = dir.path();
    std::fs::write(root.join("a.json"), "{}").expect("should succeed");
    std::fs::write(root.join("b.txt"), "hi").expect("should succeed");
    std::fs::write(root.join("photo.png"), [0u8, 1, 2, 3]).expect("should succeed"); // ext-skipped
    std::fs::write(root.join("Cargo.toml"), "x").expect("should succeed"); // name-skipped
    std::fs::create_dir_all(root.join("sub")).expect("should succeed");
    std::fs::write(root.join("sub").join("c.csv"), "x").expect("should succeed");
    std::fs::create_dir_all(root.join("target")).expect("should succeed");
    std::fs::write(root.join("target").join("skip.json"), "{}").expect("should succeed"); // dir-skipped
    std::fs::create_dir_all(root.join("Target")).expect("should succeed");
    std::fs::write(root.join("Target").join("skip.json"), "{}").expect("should succeed"); // mixed-case dir-skipped
    std::fs::create_dir_all(root.join(".git")).expect("should succeed");
    std::fs::write(root.join(".git").join("skip.txt"), "x").expect("should succeed"); // hidden dir-skipped

    let files = collect_importable_files(root);
    let names: Vec<String> = files
        .iter()
        .map(|p| {
            p.file_name()
                .expect("should succeed")
                .to_string_lossy()
                .into_owned()
        })
        .collect();
    // Sorted by full path: a.json < b.txt < sub/c.csv; the rest are skipped.
    assert_eq!(names, vec!["a.json", "b.txt", "c.csv"]);
}

#[tokio::test]
async fn local_scrape_aggregates_recognized_files_across_the_tree() {
    use crate::core::entity::EntityKind;
    // Scraping a directory tree ingests every recognised artifact under it through
    // the shared dispatcher and aggregates them into one entity set — the
    // network-free "scrape local storage" capability. Files under skipped
    // directories are never read.
    let dir = tempfile::tempdir().expect("should succeed");
    let root = dir.path();
    std::fs::write(root.join("dossier.txt"), DOSSIER).expect("should succeed");
    std::fs::create_dir_all(root.join("scans")).expect("should succeed");
    std::fs::write(root.join("scans").join("s.json"), COMBINED_JSON).expect("should succeed");
    std::fs::write(root.join("t.csv"), HSE_CSV).expect("should succeed");
    // Noise that MUST NOT be ingested — a distinctive, non-placeholder marker in a
    // skipped dir and a binary file.
    std::fs::create_dir_all(root.join("target")).expect("should succeed");
    std::fs::write(
        root.join("target").join("x.json"),
        r#"{"modules":[{"results":[{"email":"skiptarget@gmail.com"}]}]}"#,
    )
    .expect("should succeed");
    std::fs::write(root.join("pic.png"), [0u8, 159, 146, 150]).expect("should succeed");
    // A WiGLE KML wardriving export — the native output of the capture device,
    // and the whole point of scraping on-device storage. It routes through the
    // shared dispatcher like every other format, so this needs no scrape-side
    // code; the test pins that it is not skipped or swallowed by the TXT
    // catch-all. Single-line and separator-free, as the device writes it.
    std::fs::write(
        root.join("survey.kml"),
        concat!(
            r#"<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2">"#,
            r#"<Placemark><name>ScrapeProbeNet</name>"#,
            r#"<description>Network ID: 00:1B:2C:3D:4E:5FEncryption: WPA2Time: 2026-08-21T16:38:38.000-07:00Signal: -70.0Accuracy: 4.0Type: WIFI</description>"#,
            r#"<Point><coordinates>153.0,-26.8</coordinates></Point></Placemark></kml>"#,
        ),
    )
    .expect("should succeed");

    let (ents, scanned, imported, sightings) = import_local_dir_entities(root, "s").await;
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::MacAddress && e.value == "00:1b:2c:3d:4e:5f"),
        "a KML wardriving export in the tree must be scraped like any other format"
    );
    let has = |v: &str| {
        ents.iter()
            .any(|e| e.kind == EntityKind::Email && e.value == v)
    };
    // The combined-search JSON nested under scans/ is ingested and aggregated.
    assert!(
        has("jordanavery@gmail.com"),
        "combined-search JSON under scans/ must be ingested"
    );
    // The dossier + CSV also contribute; at least one email is present from them.
    assert!(ents.iter().any(|e| e.kind == EntityKind::Email));
    // The marker in target/ is never read — that directory is skipped.
    assert!(
        !has("skiptarget@gmail.com"),
        "target/ must be skipped, not ingested"
    );
    // Exactly the four non-skipped candidates are scanned (dossier.txt,
    // scans/s.json, t.csv, survey.kml); pic.png and target/ are excluded.
    assert_eq!(scanned, 4, "only non-skipped candidates are scanned");
    assert!(imported >= 2, "recognised files contributed entities");
    // The KML in the tree also yields its per-sighting RF record, which the
    // deduplicated entity set structurally cannot carry.
    assert_eq!(sightings.len(), 1, "the capture's one observation is kept");
    assert_eq!(sightings[0].network_id, "00:1b:2c:3d:4e:5f");
}

#[test]
fn dehashed_csv_is_detected_strictly() {
    assert!(looks_like_dehashed_csv(
        "id,email,username,database_name,password\n1,a@b.com,x,Breach,pw\n"
    ));
    assert!(looks_like_dehashed_csv(
        "email,hashed_password.1\nx@y.com,abc\n"
    ));
    // An arbitrary CSV without the DeHashed hallmark is not swallowed.
    assert!(!looks_like_dehashed_csv("name,age\nBob,42\n"));
    // Nor are the other import formats.
    assert!(!looks_like_dehashed_csv(DOSSIER));
}

#[test]
fn dehashed_csv_parses_quoted_fields_and_every_kind() {
    // Synthetic placeholders only (no real PII). The address carries an internal
    // comma, so it must be quoted — exercising the RFC-4180 field reader.
    let csv = "id,email,username,hashed_password.1,name,database_name,url,password,address,phone\n\
        1,jordanavery@gmail.com,javery,$2a$10$abcdefghijklmnopqrs,Jordan Avery,ExampleBreach2019,\
https://site.example/u,Sup3rSecret!,\"12 Smith St, Carlton VIC 3053\",0412 345 678\n";
    let (ents, stats) = parse_dehashed_csv(csv, "s");
    let has = |k: EntityKind, pred: &dyn Fn(&str) -> bool| {
        ents.iter().any(|e| e.kind == k && pred(&e.value))
    };
    assert!(has(EntityKind::Email, &|v| v == "jordanavery@gmail.com"));
    assert!(has(EntityKind::Username, &|v| v == "javery"));
    assert!(has(EntityKind::Person, &|v| v == "Jordan Avery"));
    assert!(has(EntityKind::Credential, &|v| v == "Sup3rSecret!")); // plaintext
    assert!(has(EntityKind::Credential, &|v| v.starts_with("$2a$"))); // hash
    // The quoted address (internal comma) parsed as ONE field.
    assert!(has(EntityKind::Address, &|v| v
        .to_ascii_lowercase()
        .contains("carlton")));
    // The AU local phone is recovered and canonicalised to E.164.
    assert!(has(EntityKind::Phone, &|v| v == "+61412345678"));
    assert!(ents.iter().any(|e| e.kind == EntityKind::Url));
    // Every breach entity carries its source database in evidence.
    let em = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email)
        .expect("email");
    assert!(em.evidence.iter().any(|ev| {
        ev.attributes
            .get("database_name")
            .is_some_and(|v| v == "ExampleBreach2019")
    }));
    assert_eq!(stats.breach_records, 1);
}

#[test]
fn dossier_parse_strips_leading_utf8_bom() {
    // An exporter that writes "UTF-8 with BOM" (Excel / Notepad default) prefixes
    // the file with U+FEFF, which `str::trim` does NOT strip — so the first section
    // header `EMAILS:` became `\u{feff}EMAILS:`, matched no section, and the whole
    // first section was silently dropped.
    let bom_dossier = "\u{feff}EMAILS:\n  -> betocastillo097@gmail.com\n";
    let (ents, _) = parse_dossier(bom_dossier, "sid");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "betocastillo097@gmail.com"),
        "the first section must parse despite a leading BOM: {:?}",
        ents.iter().map(|e| (&e.kind, &e.value)).collect::<Vec<_>>()
    );
}

#[test]
fn dossier_parse_yields_correlated_individualised_entities() {
    let (mut ents, stats) = parse_dossier(DOSSIER, "sid");
    deduplicate_by_uid(&mut ents);
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);

    // Entry-derived identity, fully parsed (not fragments).
    assert!(has(EntityKind::Email, "zacfrost512@gmail.com"));
    assert!(has(EntityKind::Username, "zacfrost512"));
    assert!(has(EntityKind::Person, "Isaac Frost"));
    assert!(has(
        EntityKind::Url,
        "http://www.linkedin.com/in/isaac-frost-42474a122"
    ));
    // Password hash is a Credential, never a Password.
    assert!(has(EntityKind::Credential, "$2a$10$id3HAw6TcOjKvPH/RK7MS."));
    assert!(!ents.iter().any(|e| e.kind == EntityKind::Password));

    // Section lists folded in; an email appears in the USERNAMES list too.
    assert!(has(EntityKind::Email, "betocastillo097@gmail.com"));
    assert!(has(EntityKind::Email, "isaac@derbyrock.com"));
    assert!(has(EntityKind::Username, "a_frost_life"));

    // The `@gmail` fragment is rejected, never surfaced.
    assert!(!ents.iter().any(|e| e.value == "@gmail"));
    // The freemail `_domain` is NOT emitted as a bare Domain entity.
    assert!(!has(EntityKind::Domain, "gmail.com"));

    // `ip`/`phone`/`domain` entry fields are first-class pivotable seeds — the
    // text path now matches the JSON importer's coverage. Each is validated:
    // a routable IP, a corporate domain and an E.164 phone are kept…
    assert!(has(EntityKind::IpAddress, "8.8.8.8"));
    assert!(has(EntityKind::Phone, "+61412345678"));
    assert!(has(EntityKind::Domain, "derbyrock.com"));
    // …while a documentation-range IP (RFC 5737) is rejected as bogus, never
    // becoming a high-confidence false seed.
    assert!(!has(EntityKind::IpAddress, "203.0.113.45"));

    // Individualised: the per-entry evidence carries the FULL record, so
    // birthdate/country/gender are verifiable on the finding, not lost.
    let frost = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email && e.value == "frostisms@gmail.com")
        .expect("entry #85 email");
    let attrs = &frost.evidence[0].attributes;
    assert_eq!(
        attrs.get("birthdate").map(String::as_str),
        Some("2002-11-17")
    );
    assert_eq!(attrs.get("country").map(String::as_str), Some("GB"));
    assert_eq!(attrs.get("gender").map(String::as_str), Some("M"));
    assert_eq!(attrs.get("name").map(String::as_str), Some("Isaac Frost"));
    // The hash is NOT echoed into a benign attribute.
    assert!(!attrs.contains_key("hash"));

    // The PASSWORDS: section's `-> <hex hash>` becomes a Credential too — a
    // major part of the real file, distinct from the per-entry `hash:` field.
    assert!(
        has(
            EntityKind::Credential,
            "00346D91DD87C74089F3BFA88E13DE8101000000DCB6"
        ),
        "a PASSWORDS-section hex hash must be parsed as a Credential"
    );

    // Two distinct credentials: the entry's bcrypt hash + the PASSWORDS hex.
    assert!(stats.persons >= 1 && stats.credentials >= 2 && stats.emails >= 3);
}

// A SeekNow `CONTACT SUMMARY (KEY DATA)` block (synthetic; AU + US mix). The
// `NAMES:`/`PHONE NUMBERS:`/`ADDRESSES:`/`IP ADDRESSES:` aggregate lists were
// previously dropped — only EMAILS/USERNAMES/PASSWORDS were recognised.
const SEEKNOW: &str =
    "================================================================================
                           SEARCH RESULTS EXPORT
================================================================================
Query: Jordan Avery

********************    CONTACT SUMMARY (KEY DATA)    ********************

  [EMAILS: 1 | NAMES: 2 | PHONE NUMBERS: 2 | ADDRESSES: 3 | IP ADDRESSES: 1]

  EMAILS:
    -> jordanavery@gmail.com

  NAMES:
    -> Full Name: Jordan Avery
    -> Company Name: Acme Corp Pty Ltd

  PHONE NUMBERS:
    -> 0412 345 678
    -> (214) 473-9696

  ADDRESSES:
    -> address: 12 Smith Street, Carlton, VIC, 3053, Australia
    -> city: Carlton
    -> state: VIC

  IP ADDRESSES:
    -> 24.32.96.70

Entry #1:
   \u{2022} email: jordanavery@gmail.com
   \u{2022} name: Jordan Avery
";

#[test]
fn dossier_captures_seeknow_contact_summary_sections() {
    assert!(looks_like_dossier(SEEKNOW));
    let (mut ents, stats) = parse_dossier(SEEKNOW, "s");
    deduplicate_by_uid(&mut ents);
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);

    // NAMES: full name → Person, company name → Organisation (employer pivot).
    assert!(has(EntityKind::Person, "Jordan Avery"));
    assert!(has(EntityKind::Organisation, "Acme Corp Pty Ltd"));
    assert!(stats.organisations >= 1);

    // PHONE NUMBERS: the AU local number is canonicalised to E.164; the bare US
    // number (no recoverable country code) is correctly dropped.
    assert!(has(EntityKind::Phone, "+61412345678"));
    assert!(
        !ents
            .iter()
            .any(|e| e.kind == EntityKind::Phone && e.value.contains("214")),
        "a bare foreign-national number must not be emitted as a phone"
    );

    // ADDRESSES: the full `address:` line is a residence; the lone `city:`/
    // `state:` fragments are too coarse and must be skipped.
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Address && e.value.contains("Carlton")),
        "the full address line must become an Address"
    );
    assert!(
        !has(EntityKind::Address, "Carlton"),
        "a bare city fragment must not become an Address"
    );

    // IP ADDRESSES: a real public IP becomes a pivotable IpAddress.
    assert!(has(EntityKind::IpAddress, "24.32.96.70"));
}

/// A SeekNow export whose per-entry fields are NOT mirrored in the CONTACT
/// SUMMARY. Dogfooding a genuine export showed the entry contributing nothing:
/// every surviving entity carried the `dossier-list` tag, i.e. it came from the
/// summary, and a record naming a breach corpus still reported "0 breach".
/// Invented identifiers throughout. The IP is a routable-looking literal rather
/// than an RFC 5737 documentation address on purpose: `is_bogus_ip` rejects the
/// documentation ranges, so a doc-range fixture would pass this test for the
/// wrong reason and keep passing if `lastip` were dropped again.
const SEEKNOW_ENTRY_ONLY: &str = "\
================================================================================
                          RAW DATA BY DATABASE
================================================================================

  [1] Probe \u{2022} INF0SEC Leaks — Intelligence Data
      Entry #1:
        \u{2022} label: PROBECORP NET 1M TEST 012020
        \u{2022} title: ProbeCorp
        \u{2022} username: probeuser
        \u{2022} lastip: 24.32.96.71
";

const SEEKNOW_TWO_ENTRIES_SAME_IP: &str = "\
================================================================================
                          RAW DATA BY DATABASE
================================================================================

  [1] Probe \u{2022} INF0SEC Leaks — Intelligence Data
      Entry #1:
        \u{2022} username: probeuser
        \u{2022} ip: 2001:4860:4860:0000:0000:0000:0000:8888
      Entry #2:
        \u{2022} username: probeuser2
        \u{2022} lastip: 2001:4860:4860::8888
";

#[test]
fn dossier_dedups_an_expanded_and_a_compressed_ipv6_spelling() {
    // Regression: see combined_search's identical fix for the general shape.
    // A real public address (Google Public DNS) is used, not an RFC 3849
    // documentation one, so `is_bogus_ip` cannot mask the gap.
    let (ents, _stats) = parse_dossier(SEEKNOW_TWO_ENTRIES_SAME_IP, "s");
    let ips: Vec<&Entity> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .collect();
    assert_eq!(
        ips.len(),
        1,
        "an expanded and a compressed spelling of the same IPv6 address must dedup to one entity: {ips:?}"
    );
}

#[test]
fn dossier_entry_fields_survive_without_a_contact_summary() {
    let (mut ents, stats) = parse_dossier(SEEKNOW_ENTRY_ONLY, "s");
    deduplicate_by_uid(&mut ents);
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);

    // `lastip` is the spelling SeekNow uses; it must yield the same pivotable
    // IpAddress that a record spelling the field `ip` would. Previously the
    // field was not whitelisted at all, so it never reached the entry and the
    // only IPs that survived an export were the ones the summary happened to
    // repeat.
    assert!(
        has(EntityKind::IpAddress, "24.32.96.71"),
        "a `lastip` field must emit an IpAddress"
    );
    assert!(has(EntityKind::Username, "probeuser"));

    // The entry is a breach record and must be counted as one — this path is
    // the whole reason the dossier format exists, yet it reported zero.
    assert_eq!(
        stats.breach_records, 1,
        "a dossier entry must count as a breach record"
    );

    // The corpus name and its display title are provenance: they must reach the
    // evidence of the entities lifted from that record, so a finding can be
    // traced back to the breach that disclosed it.
    let ip = ents
        .iter()
        .find(|e| e.kind == EntityKind::IpAddress)
        .expect("IpAddress emitted above");
    let attrs: Vec<(&str, &str)> = ip
        .evidence
        .iter()
        .flat_map(|ev| ev.attributes.iter())
        .map(|(k, v)| (k.as_str(), v.as_str()))
        .collect();
    assert!(
        attrs.contains(&("label", "PROBECORP NET 1M TEST 012020")),
        "the breach corpus label must be preserved as evidence, got {attrs:?}"
    );
    assert!(
        attrs.contains(&("title", "ProbeCorp")),
        "the breach display title must be preserved as evidence, got {attrs:?}"
    );

    // The corpus label embeds a domain-shaped token (`PROBECORP NET`). Mining it
    // into a Domain seed would mint high-confidence pivots out of a naming
    // convention, so it is deliberately NOT done.
    assert!(
        !ents.iter().any(|e| e.kind == EntityKind::Domain),
        "a corpus label must not be mined into a Domain seed"
    );
}

#[tokio::test]
async fn upload_dispatcher_routes_seeknow_summary_to_dossier() {
    let (ents, label) = entities_from_upload(SEEKNOW, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "dossier");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Phone && e.value == "+61412345678")
    );
}

#[test]
fn dossier_list_address_carries_provenance_and_geocodes() {
    use crate::core::engine::enrich_offline_geo;
    // A CONTACT SUMMARY whose ADDRESSES section names a major AU city.
    let body = "Entry #1:\n   \u{2022} email: a@example.com\n\
                ADDRESSES:\n  -> address: 10 George Street, Sydney NSW 2000\n";
    let (mut ents, _stats) = parse_dossier(body, "s");
    deduplicate_by_uid(&mut ents);

    // The list-section address now carries an `import:dossier` corroborating
    // source (previously it had none, leaving it source-less and un-geocodable).
    let addr = ents
        .iter()
        .find(|e| e.kind == EntityKind::Address)
        .expect("address");
    assert!(
        !addr.corroborating_sources().is_empty(),
        "a list-section address must carry provenance"
    );

    // With provenance, the shared offline geocode derives a Sydney coordinate.
    enrich_offline_geo(&mut ents, "s");
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::Coordinates
            && e.has_tag("addr-derived")
            && e.value.starts_with("-33.8688")),
        "the Sydney address must geocode once it carries a source"
    );
}

#[test]
fn finalize_drops_bogus_ips_keeps_real_and_private_and_dedups() {
    let sid = "import-test";
    let mut v = vec![
        Entity::new(EntityKind::IpAddress, "192.0.2.1", 0.6, sid), // doc -> drop
        Entity::new(EntityKind::IpAddress, "203.0.113.9", 0.6, sid), // doc -> drop
        Entity::new(EntityKind::IpAddress, "240.0.0.1", 0.6, sid), // reserved -> drop
        Entity::new(EntityKind::IpAddress, "8.8.8.8", 0.6, sid),   // real -> keep
        Entity::new(EntityKind::IpAddress, "192.168.1.5", 0.6, sid), // private -> keep
        Entity::new(EntityKind::IpAddress, "8.8.8.8", 0.6, sid),   // dup -> deduped
        Entity::new(EntityKind::Email, "x@b.com", 0.6, sid),       // non-IP untouched
    ];
    deduplicate_by_uid(&mut v);
    let vals: Vec<&str> = v.iter().map(|e| e.value.as_str()).collect();

    for bogus in ["192.0.2.1", "203.0.113.9", "240.0.0.1"] {
        assert!(
            !vals.contains(&bogus),
            "bogus {bogus} must be dropped: {vals:?}"
        );
    }
    assert_eq!(
        vals.iter().filter(|x| **x == "8.8.8.8").count(),
        1,
        "real IP kept exactly once (deduped)"
    );
    assert!(vals.contains(&"192.168.1.5"), "private IP kept");
    assert!(vals.contains(&"x@b.com"), "non-IP entity untouched");
}

#[test]
fn finalize_drops_ip_literals_mis_classified_as_domains() {
    let sid = "import-test";
    let mut v = vec![
        Entity::new(EntityKind::Domain, "8.8.8.8", 0.45, sid), // IP-as-domain -> drop
        Entity::new(EntityKind::Domain, "192.0.2.1", 0.45, sid), // doc-IP-as-domain -> drop
        Entity::new(EntityKind::Domain, "evil.com", 0.50, sid), // real domain -> keep
        Entity::new(EntityKind::Domain, "sub.evil.com", 0.45, sid), // real subdomain -> keep
    ];
    deduplicate_by_uid(&mut v);
    let vals: Vec<&str> = v.iter().map(|e| e.value.as_str()).collect();
    assert!(
        !vals.contains(&"8.8.8.8"),
        "IP literal must not be a domain: {vals:?}"
    );
    assert!(
        !vals.contains(&"192.0.2.1"),
        "doc-IP literal must not be a domain"
    );
    assert!(vals.contains(&"evil.com"), "real domain kept");
    assert!(vals.contains(&"sub.evil.com"), "real subdomain kept");
}

#[test]
fn import_txt_survives_misordered_section_markers() {
    // Regression: a crafted TXT export with the OSINT ENRICHMENT marker
    // BEFORE the INFECTED MACHINES marker used to panic
    // (`&body[vs..victim_end]` with start > end), aborting `hse import` —
    // the CLI path has no catch_unwind. The end marker is now sought after
    // the start, so the slice is always well-formed.
    // Tested against the pure parser (the panic was in parsing, not
    // persistence) so the test stays hermetic — it never touches the default
    // store that `cmd_import_txt` now writes to.
    let body = "=== OSINT ENRICHMENT ===\nstuff\n=== INFECTED MACHINES ===\nIPs: 8.8.8.8\n";
    let (ents, _) = super::parse_oathnet_txt(body, "sid");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::IpAddress && e.value == "8.8.8.8"),
        "misordered section markers must parse, not panic"
    );
}

#[test]
fn import_txt_parses_victim_section_in_normal_order() {
    // Happy path unaffected: INFECTED before OSINT still parses cleanly.
    let body = "=== INFECTED MACHINES ===\nIPs: 8.8.8.8\n=== OSINT ENRICHMENT ===\nMore: x\n";
    let (ents, _) = super::parse_oathnet_txt(body, "sid");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::IpAddress && e.value == "8.8.8.8")
    );
}

#[test]
fn import_txt_keeps_ipv6_victim_addresses() {
    // The old `contains('.')` gate dropped every IPv6 victim IP. A mixed IPs line
    // must keep both families and skip only the unspecified/`0.x` "no address" junk.
    let body = "=== INFECTED MACHINES ===\nIPs: 10.0.0.5, 2001:db8::1, 0.0.0.0, ::, 203.0.113.9\n";
    let (ents, _) = super::parse_oathnet_txt(body, "sid");
    let ips: Vec<&str> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        ips.contains(&"2001:db8::1"),
        "IPv6 victim IP must be kept: {ips:?}"
    );
    assert!(
        ips.contains(&"10.0.0.5"),
        "IPv4 victim IP still kept: {ips:?}"
    );
    assert!(!ips.contains(&"0.0.0.0"), "0.x junk skipped: {ips:?}");
    assert!(!ips.contains(&"::"), "unspecified IPv6 skipped: {ips:?}");
}

#[test]
fn dossier_plaintext_password_and_session_token_become_linkable_credentials() {
    use crate::core::entity::EntityKind;
    // Stealer-log fields — a reused plaintext `password` and a `session` token —
    // must surface as Credential entities tagged for AU-047, carrying each
    // entry's email so the reused-secret link can fire. Like the hash path,
    // reuse across entries must survive the uid-merge (both emails on one
    // credential), not be value-deduped away.
    let dossier = "Entry #1:\n   \u{2022} email: a@corp.io\n   \
                   \u{2022} password: Tr0ub4dor&3xK9!q\n   \
                   \u{2022} session: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15\n\
                   Entry #2:\n   \u{2022} email: b@other.io\n   \
                   \u{2022} password: Tr0ub4dor&3xK9!q\n";
    let (mut ents, stats) = super::parse_dossier(dossier, "sid");
    super::deduplicate_by_uid(&mut ents);

    // The reused password is one merged Credential tagged plaintext-credential
    // carrying BOTH accounts' emails (so AU-047 links them).
    let pw = ents
        .iter()
        .find(|e| e.kind == EntityKind::Credential && e.value == "Tr0ub4dor&3xK9!q")
        .expect("plaintext password credential");
    assert!(pw.has_tag("plaintext-credential"));
    let emails: std::collections::BTreeSet<&str> = pw
        .evidence
        .iter()
        .filter_map(|ev| ev.attributes.get("email").map(String::as_str))
        .collect();
    assert!(
        emails.contains("a@corp.io") && emails.contains("b@other.io"),
        "reused password must retain both accounts' emails, got {emails:?}"
    );

    // The session token surfaces tagged session-token.
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Credential && e.has_tag("session-token")),
        "session token must surface as a session-token credential"
    );
    assert!(stats.credentials >= 2);

    // End-to-end: the correlator links the two accounts on the reused password.
    let hits = crate::core::correlator::correlate_entities(&ents, "sid");
    assert!(
        hits.iter().any(|c| c.rule_id == "AU-047"),
        "reused plaintext password across two entries must fire AU-047"
    );
}

#[test]
fn dossier_entry_address_field_becomes_a_first_class_entity() {
    use crate::core::entity::EntityKind;
    // Regression: `address` was missing from the entry field whitelist, so the
    // `address:` line was never accumulated and `emit_dossier_entry`'s Address
    // block (the household / co-location pivot, AU-049) was dead code — every
    // dossier address was silently dropped during parsing.
    let dossier = "Entry #1:\n   \u{2022} email: a@corp.io\n   \
                   \u{2022} address: 12 Mary Street, Brisbane QLD 4000\n";
    let (mut ents, stats) = super::parse_dossier(dossier, "sid");
    super::deduplicate_by_uid(&mut ents);

    let addr = ents
        .iter()
        .find(|e| e.kind == EntityKind::Address)
        .expect("a specific residence address must be emitted");
    assert_eq!(addr.value, "12 Mary Street, Brisbane QLD 4000");
    assert!(addr.has_tag("breach") && addr.has_tag("dossier"));
    assert_eq!(stats.addresses, 1);

    // The full record still travels as evidence on the email (correlation intact).
    let email = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email && e.value == "a@corp.io")
        .expect("entry email");
    assert_eq!(
        email.evidence[0]
            .attributes
            .get("address")
            .map(String::as_str),
        Some("12 Mary Street, Brisbane QLD 4000"),
    );

    // A bare, non-specific locality ("USA") names a region thousands share and
    // must NOT fabricate a residence entity.
    let vague = "Entry #2:\n   \u{2022} email: b@corp.io\n   \u{2022} address: USA\n";
    let (ents2, stats2) = super::parse_dossier(vague, "sid");
    assert!(!ents2.iter().any(|e| e.kind == EntityKind::Address));
    assert_eq!(stats2.addresses, 0);
}

#[test]
fn reused_hash_across_entries_is_preserved_for_cross_account_linking() {
    use crate::core::entity::EntityKind;
    // The account-linking signal: two DIFFERENT accounts sharing one salted hash. The
    // parser must not value-dedup the credential away; after dedup-merge the one
    // credential entity must carry BOTH entries' emails in its evidence, so the
    // correlator (AU-047) can link the separate accounts.
    let dossier = "Entry #1:\n   \u{2022} email: a@proton.me\n   \u{2022} hash: $2a$10$SAMEHASHvalueAAAAAAAAAAAAAA\nEntry #2:\n   \u{2022} email: b@gmail.com\n   \u{2022} hash: $2a$10$SAMEHASHvalueAAAAAAAAAAAAAA\n";
    let (mut ents, _) = super::parse_dossier(dossier, "sid");
    super::deduplicate_by_uid(&mut ents);

    let cred = ents
        .iter()
        .find(|e| e.kind == EntityKind::Credential)
        .expect("a credential entity");
    let emails: std::collections::BTreeSet<&str> = cred
        .evidence
        .iter()
        .filter_map(|ev| ev.attributes.get("email").map(String::as_str))
        .collect();
    assert!(
        emails.contains("a@proton.me") && emails.contains("b@gmail.com"),
        "the reused-hash credential must retain BOTH accounts' emails, got {emails:?}"
    );
}

// ── parse_oathnet_html ────────────────────────────────────────────────────────

#[test]
fn parse_oathnet_html_extracts_domains_ips_and_emails() {
    use crate::core::entity::EntityKind;
    let body = "<html><body>\
        Host: example.com and sub.dept.example.com<br>\
        IP: 24.32.96.71<br>\
        Contact: Alice@Example.com\
        </body></html>";
    let es = parse_oathnet_html(body, "sid");
    let has = |k: EntityKind, v: &str| es.iter().any(|e| e.kind == k && e.value == v);
    assert!(has(EntityKind::Domain, "example.com"));
    assert!(has(EntityKind::Domain, "sub.dept.example.com"));
    assert!(has(EntityKind::IpAddress, "24.32.96.71"));
    // Emails are lower-cased.
    assert!(has(EntityKind::Email, "alice@example.com"));
    // Every imported entity carries the `import` tag.
    assert!(es.iter().all(|e| e.has_tag("import")));
}

#[test]
fn parse_oathnet_html_flags_subdomains_with_lower_confidence() {
    use crate::core::entity::EntityKind;
    let es = parse_oathnet_html("a.b.example.com plain.com", "sid");
    let sub = es
        .iter()
        .find(|e| e.kind == EntityKind::Domain && e.value == "a.b.example.com")
        .expect("subdomain present");
    let apex = es
        .iter()
        .find(|e| e.kind == EntityKind::Domain && e.value == "plain.com")
        .expect("apex present");
    assert!(sub.has_tag("subdomain"));
    assert!(!apex.has_tag("subdomain"));
    // Subdomains are scored below apex domains (0.45 < 0.50).
    assert!(sub.confidence < apex.confidence);
}

#[test]
fn parse_oathnet_html_skips_bogus_ips_and_dedups() {
    use crate::core::entity::EntityKind;
    // 0./127./255.-prefixed IPs are dropped; a repeated domain appears once.
    let es = parse_oathnet_html(
        "127.0.0.1 0.0.0.0 255.255.255.255 example.com example.com",
        "sid",
    );
    assert!(
        !es.iter().any(|e| e.kind == EntityKind::IpAddress),
        "loopback/unspecified/broadcast IPs must be skipped"
    );
    assert_eq!(
        es.iter()
            .filter(|e| e.kind == EntityKind::Domain && e.value == "example.com")
            .count(),
        1,
        "a repeated domain must be de-duplicated"
    );
}

#[test]
fn parse_oathnet_html_rejects_out_of_range_octets_keeps_valid() {
    use crate::core::entity::EntityKind;
    // The dotted-quad regex matches any `d{1,3}.d{1,3}.d{1,3}.d{1,3}` shape, so
    // `999.999.999.999` and `256.1.2.3` are syntactically captured but are not
    // valid IPv4 addresses. The `parse::<IpAddr>()` gate must reject them while
    // still admitting a real public address.
    let es = parse_oathnet_html("999.999.999.999 256.1.2.3 24.32.96.71", "sid");
    let ips: Vec<&str> = es
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .map(|e| e.value.as_str())
        .collect();
    assert_eq!(
        ips,
        vec!["24.32.96.71"],
        "only the parseable public IP must survive; out-of-range octets are bogus"
    );
}

#[test]
fn parse_oathnet_html_empty_body_yields_nothing() {
    assert!(parse_oathnet_html("", "sid").is_empty());
}

// ── Stealerlogs victim-export parser ──────────────────────────────────────────

// Synthetic Stealerlogs export (no real PII): two victims sharing one reused
// password, a corporate domain, a freemail domain and an infrastructure IP.
const STEALER: &str = "Module: Stealerlogs
Query: javery
Search Type: Auto Detect
Results: 0

Success:
  true
Query:
  javery
Victims:
  [1]
    Log Id:
      ea0621568ccd7fee2bd78e16f637727612aca78d4b3d1f6bf8175cf2ca8de831
    Credentials:
      [1]
        Username:
          jordanavery@gmail.com
        Password:
          Hunter2pass
        Pwned At:
          2026-05-20T21:00:00Z
      [2]
        Username:
          javery
        Password:
          Hunter2pass
        Pwned At:
          2026-05-20T21:00:00Z
    Domains:
      [1]
        acme-corp.com
      [2]
        79.98.132.222
      [3]
        gmail.com
    Newest:
      2026-05-20T21:00:00Z
    Oldest:
      2026-05-19T10:00:00Z
    Credential Count:
      2
    Domain Count:
      3
  [2]
    Log Id:
      8c815a3dd9c0954797f060577d8fb72690ac7d8cb142eab4c87856062ab8f067
    Credentials:
      [1]
        Username:
          bob
        Password:
          Hunter2pass
        Pwned At:
          2026-05-20T21:00:00Z
    Domains:
      [1]
        derbyrock.com
    Credential Count:
      1
    Domain Count:
      1
";

#[test]
fn stealerlogs_is_detected_and_others_are_not() {
    assert!(looks_like_stealerlogs(STEALER));
    // A renamed banner still parses via the structural fingerprint.
    assert!(looks_like_stealerlogs(
        "Victims:\n  [1]\n    Log Id:\n      abc\n    Credentials:\n"
    ));
    // The other formats are not swallowed.
    assert!(!looks_like_stealerlogs(DOSSIER));
    assert!(!looks_like_stealerlogs(COMBINED));
    assert!(!looks_like_stealerlogs(
        "URL: https://x.com/login\nUsername: bob\n"
    ));
    // And the stealer export is NOT mistaken for the aggregator/dossier formats.
    assert!(!looks_like_combined_search(STEALER));
    assert!(!looks_like_dossier(STEALER));
}

#[test]
fn stealerlogs_parses_victims_creds_and_domains() {
    let (mut ents, stats, _rows) = parse_stealerlogs(STEALER, "s");
    deduplicate_by_uid(&mut ents);
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);

    // Two victims, each one stealer doc.
    assert_eq!(stats.victim_records, 2);
    assert_eq!(stats.stealer_docs, 2);

    // Credential username shapes: an email username and two plain usernames.
    assert!(has(EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(EntityKind::Username, "javery"));
    assert!(has(EntityKind::Username, "bob"));

    // The reused plaintext password is present and — crucially — NOT collapsed
    // away: it appears under three credential lines across two victims, so after
    // the uid-merge the single Credential entity must carry evidence from every
    // victim it implicates (the AU-047 reuse signal).
    let cred = ents
        .iter()
        .find(|e| e.kind == EntityKind::Credential && e.value == "Hunter2pass")
        .expect("the reused password must survive as a Credential");
    assert!(
        cred.evidence.len() >= 2,
        "a password reused across victims must retain every victim's evidence, got {}",
        cred.evidence.len()
    );

    // Domains: the corporate domain and the infrastructure IP are kept as pivots;
    // the freemail domain is gated out (expanding gmail.com maps a platform).
    assert!(has(EntityKind::Domain, "acme-corp.com"));
    assert!(has(EntityKind::Domain, "derbyrock.com"));
    assert!(has(EntityKind::IpAddress, "79.98.132.222"));
    assert!(
        !has(EntityKind::Domain, "gmail.com"),
        "a freemail domain must not become a pivot seed"
    );

    // The infected-machine log id becomes a DeviceId pivot.
    assert!(ents.iter().any(|e| e.kind == EntityKind::DeviceId
        && e.value == "ea0621568ccd7fee2bd78e16f637727612aca78d4b3d1f6bf8175cf2ca8de831"
        && e.has_tag("log-id")));

    // Every emitted entity is tagged as stealer-victim import data.
    assert!(
        ents.iter()
            .filter(|e| e.kind == EntityKind::Username)
            .all(|e| e.has_tag("stealer-victim"))
    );
}

const STEALER_IPV4_MAPPED_DOMAIN: &str = "Module: Stealerlogs
Query: javery
Search Type: Auto Detect
Results: 0

Victims:
  [1]
    Log Id:
      ea0621568ccd7fee2bd78e16f637727612aca78d4b3d1f6bf8175cf2ca8de831
    Domains:
      [1]
        ::ffff:8.8.8.8
      [2]
        8.8.8.8
";

#[test]
fn stealerlogs_collapses_an_ipv4_mapped_and_a_plain_ipv4_domain_entry() {
    // Regression: unlike the other IpAddress sites in this file, this one
    // DID reformat via a parsed `IpAddr` — `IpAddr::to_string()` already
    // canonicalises expanded/mixed-case IPv6 correctly — but Rust's
    // `Ipv6Addr::to_string()` renders an IPv4-mapped address as
    // "::ffff:a.b.c.d", NOT collapsed to plain IPv4 the way `core::entity::
    // normalise`'s explicit `.to_ipv4_mapped()` step does. A genuinely
    // public address (Google Public DNS) is used so `is_bogus_ip` cannot
    // mask the gap.
    let (entities, _stats, _rows) = parse_stealerlogs(STEALER_IPV4_MAPPED_DOMAIN, "s");
    let ips: Vec<&Entity> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .collect();
    assert_eq!(
        ips.len(),
        1,
        "an IPv4-mapped IPv6 spelling and its plain IPv4 equivalent must dedup to one entity: {ips:?}"
    );
}

#[test]
fn stealerlogs_credential_pwned_at_survives_onto_its_own_entities() {
    // Regression: `Cred::pwned_at` was parsed from the real `Pwned At:` field
    // (documented in `stealer.rs`'s own module header as part of the format)
    // but then silently dropped — never read again anywhere in the codebase,
    // never surfaced as evidence, violating the full-fidelity evidentiary
    // policy (`Evidence`'s own doc: "the FULL source record, preserved
    // verbatim... nothing redacted or omitted"). This pins that the second
    // victim's single, unambiguous credential ("bob") carries its own
    // `pwned_at` evidence attribute with the exact real capture instant.
    let (ents, _stats, _rows) = parse_stealerlogs(STEALER, "s");
    let bob = ents
        .iter()
        .find(|e| e.kind == EntityKind::Username && e.value == "bob")
        .expect("the bob credential must become a Username entity");
    let pwned_at = bob
        .evidence
        .iter()
        .find_map(|ev| ev.attributes.get("pwned_at"));
    assert_eq!(
        pwned_at.map(String::as_str),
        Some("2026-05-20T21:00:00Z"),
        "the credential's own Pwned At date must ride on its entity's evidence, not be dropped"
    );
}

#[tokio::test]
async fn upload_dispatcher_routes_stealerlogs() {
    let (ents, label) = entities_from_upload(STEALER, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "stealerlogs");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Credential && e.value == "Hunter2pass")
    );
}

// ── OathNet SEARCH REPORT parser ──────────────────────────────────────────────

// Synthetic OathNet SEARCH REPORT (no real PII): one fully-populated AU breach
// entry, one noise entry whose name is a doubled query token, and an OSINT IP
// enrichment block.
const OATHNET_REPORT: &str = "============================================================
OATHNET SEARCH REPORT
Generated via oathnet.org
Report Date: 2026-06-24T07:03:47.997Z
Search Query: \"javery\"
============================================================

=== SEARCH RESULTS ===
Query: javery
Count: 2

=== DATABASE LOGS ===

[Breach Logs] (2 entries)

Entry 1:
country: AU
dbname: examplebreach.com
email: jordanavery@gmail.com
email domain: gmail.com
first name: Jordan
full name: Jordan Avery
id: b8ed0df81e91044e7ba2
last name: Avery
password hash: 2e4cc0d58868c0ea4c89b799bc8fd41a087009e067a171d823368cb517d6b3be
phone number: 0412345678
service: breach
username: javery
address street: 12 Smith Street
city: Carlton
state: VIC
postal code: 3053

Entry 2:
full name: Rhino Rhino
dbname: noise.com
service: breach

=== OSINT ENRICHMENT DATA ===

--- IP INFORMATION ---

IP: 1.128.0.50
status: success
country: Australia
regionName: Victoria
city: Melbourne
lat: -37.8136
lon: 144.9631
isp: Telstra
query: 1.128.0.50
";

const OATHNET_REPORT_TWO_ENTRIES_SAME_IP: &str = "=== DATABASE LOGS ===

[Breach Logs] (2 entries)

Entry 1:
dbname: examplebreach.com
username: javery
ip: 2001:4860:4860:0000:0000:0000:0000:8888

Entry 2:
dbname: noise.com
username: javery2
ip: 2001:4860:4860::8888
";

#[test]
fn oathnet_report_dedups_an_expanded_and_a_compressed_ipv6_spelling() {
    // Regression: see combined_search's identical fix for the general shape.
    // A real public address (Google Public DNS) is used, not an RFC 3849
    // documentation one, so `is_bogus_ip` cannot mask the gap.
    let (ents, _stats) = parse_oathnet_report(OATHNET_REPORT_TWO_ENTRIES_SAME_IP, "s");
    let ips: Vec<&Entity> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .collect();
    assert_eq!(
        ips.len(),
        1,
        "an expanded and a compressed spelling of the same IPv6 address must dedup to one entity: {ips:?}"
    );
}

#[test]
fn oathnet_report_is_detected_and_others_are_not() {
    assert!(looks_like_oathnet_report(OATHNET_REPORT));
    assert!(looks_like_oathnet_report(
        "=== DATABASE LOGS ===\nEntry 1:\nemail: a@b.com\n"
    ));
    // Not confused with the dossier (`Entry #N`) or the stealer-log TXT.
    assert!(!looks_like_oathnet_report(DOSSIER));
    assert!(!looks_like_oathnet_report(
        "URL: https://x.com/login\nUsername: bob\n"
    ));
    // And the report is not mistaken for the dossier/combined shapes.
    assert!(!looks_like_dossier(OATHNET_REPORT));
    assert!(!looks_like_combined_search(OATHNET_REPORT));
}

#[test]
fn oathnet_report_parses_entries_and_osint_geolocation() {
    let (mut ents, stats) = parse_oathnet_report(OATHNET_REPORT, "s");
    deduplicate_by_uid(&mut ents);
    let has = |k: EntityKind, v: &str| ents.iter().any(|e| e.kind == k && e.value == v);

    // Entry 1's correlated identity cluster.
    assert!(has(EntityKind::Email, "jordanavery@gmail.com"));
    assert!(has(EntityKind::Username, "javery"));
    assert!(has(EntityKind::Person, "Jordan Avery"));
    // AU local phone canonicalised to E.164.
    assert!(has(EntityKind::Phone, "+61412345678"));
    // The hash credential.
    assert!(ents.iter().any(|e| e.kind == EntityKind::Credential
        && e.value.len() == 64
        && e.has_tag("password-hash")));
    // Residential address (real street number present).
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Address
                && e.value.to_ascii_lowercase().contains("carlton"))
    );

    // The doubled-token noise name ("Rhino Rhino") is NOT promoted to a Person.
    assert!(
        !has(EntityKind::Person, "Rhino Rhino"),
        "a query-echo name must not become a Person"
    );

    // The OSINT enrichment block geolocates the IP to coordinates + a place.
    // (The Coordinates kind canonicalises to 6 decimal places, so match by prefix
    // rather than the raw 4-place emit string.)
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::Coordinates
            && e.value.starts_with("-37.8136")
            && e.value.contains("144.9631")),
        "the OSINT IP must geolocate to coordinates"
    );
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Address && e.value.contains("Melbourne"))
    );

    // Only the real entry counts as a breach record (the noise block emits a
    // Person-free record but still carries an identity-less... actually it has a
    // name field, so it is a record); assert at least the populated one parsed.
    assert!(stats.breach_records >= 1);
    // The source database rides on the email's evidence.
    let em = ents
        .iter()
        .find(|e| e.kind == EntityKind::Email)
        .expect("email");
    assert!(em.evidence.iter().any(|ev| {
        ev.attributes
            .get("source")
            .is_some_and(|v| v == "examplebreach.com")
    }));
}

#[tokio::test]
async fn upload_dispatcher_routes_oathnet_report() {
    let (ents, label) = entities_from_upload(OATHNET_REPORT, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "oathnet-report");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Person && e.value == "Jordan Avery")
    );
    // The shared OSINT helper ran on the report path too.
    assert!(ents.iter().any(|e| e.kind == EntityKind::Coordinates));
}

// ── Raw combolist import ───────────────────────────────────────────────────
//
// SYNTHETIC fixtures only — fabricated names at real free-mail providers
// (the same convention `DOSSIER`/`COMBINED` above use), no real person or
// account. NOT `@example.*`: `is_placeholder_domain` deliberately drops every
// RFC 2606 `example.com`/`.org`/`.net` address as a documentation placeholder
// (see `core::validation::placeholder`), so a fixture built on one would be
// silently dropped by `deduplicate_by_uid` — not a suitable stand-in for a
// real leaked address. A raw `identity:secret` combolist (no header, no
// envelope — the single most common real-world breach-data shape) previously
// matched no `looks_like_*` check and fell through to the OathNet
// stealer-log TXT catch-all, which only recognises its own
// `"URL: "`/`"Username: "`-labelled lines and therefore extracted ZERO
// entities from a bare combolist: a real breach file silently imported as
// nothing. This was reproduced against the pre-fix code (label
// `"oathnet-txt"`, no Email/Password entities) before the fix landed.

use super::combolist::{looks_like_combolist, parse_combolist};

// A clean combolist — one entry per line, one delimiter variant each — used
// wherever the test also needs FORMAT DETECTION to fire (`looks_like_combolist`
// requires an overwhelming majority of sampled lines to parse cleanly, so a
// detection-path fixture must not itself carry the malformed lines under test
// below).
const COMBOLIST: &str = "alice.tester@gmail.com:Sup3rSecret!\n\
    bob.tester@outlook.com:hunter2000\n\
    carol.tester@yahoo.com;anotherPass9\n\
    dave.tester@protonmail.com\thunter2000\n";

// The same shape plus three structurally bad lines, for the parser's own
// quarantine behaviour. Deliberately NOT run through `looks_like_combolist` —
// that heuristic is a format-detection threshold, not a parse-tolerance limit,
// and a file this corrupted (3 of 7 lines) is exactly what quarantining exists
// to survive once the format is already known (e.g. the CLI's explicit
// `hse import` on a file already named/known to be a combolist).
const COMBOLIST_WITH_MALFORMED_LINES: &str = "alice.tester@gmail.com:Sup3rSecret!\n\
    bob.tester@outlook.com:hunter2000\n\
    carol.tester@yahoo.com;anotherPass9\n\
    dave.tester@protonmail.com\thunter2000\n\
    not-a-combolist-line-with-no-delimiter-at-all\n\
    :orphan-secret-no-identity\n\
    eve.tester@gmail.com:\n";

#[test]
fn combolist_is_detected_and_oathnet_txt_is_not() {
    assert!(looks_like_combolist(COMBOLIST));
    // A handful of incidental colons in prose must not misfire.
    assert!(!looks_like_combolist(
        "Report: see section 2.\nAuthor: Jane Doe.\nStatus: draft.\n"
    ));
    // Below the 3-line sample floor — too little signal to classify.
    assert!(!looks_like_combolist("alice.tester@gmail.com:hunter2\n"));
}

/// Guards against a specific, real, previously-considered "fix" for a known
/// detection gap (a bare-username-only combolist, with no email-shaped
/// identity anywhere in the file, is currently never detected — see PR #624's
/// description). The tempting broadened heuristic — drop the email-shape
/// requirement on the identity, and/or require only that the SECRET half has
/// no internal whitespace — was checked and found unsafe: "a single
/// whitespace-free token after a colon" is exactly as common in HTTP
/// headers, email headers, and key-value config files as it is in a real
/// credential dump, so that broadened heuristic misdetects all three as a
/// combolist. Each fixture below is 100%-matched by that broadened
/// heuristic (verified with a standalone check before this test was
/// written) while every line here is legitimate non-combolist text a real
/// operator could plausibly import. If `looks_like_combolist` is ever
/// changed to admit a non-email-shaped identity, these must still resolve
/// to `false` — a change that makes any of them `true` has reintroduced
/// exactly the false-positive class this test exists to catch.
#[test]
fn combolist_detection_never_misfires_on_header_or_config_shaped_text() {
    assert!(!looks_like_combolist(
        "Content-Type: application/json\nContent-Length: 348\nConnection: keep-alive\n"
    ));
    assert!(!looks_like_combolist(
        "From: alice@example.com\nTo: bob@example.com\nDate: 2026-09-09T10:00:00Z\n"
    ));
    assert!(!looks_like_combolist(
        "host: localhost\nport: 8080\ntimeout: 30s\n"
    ));
}

#[test]
fn parse_combolist_extracts_email_password_pairs_across_delimiters() {
    let (entities, stats) = parse_combolist(COMBOLIST_WITH_MALFORMED_LINES, "s");

    let emails: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(emails.contains(&"alice.tester@gmail.com"));
    assert!(emails.contains(&"bob.tester@outlook.com"));
    assert!(
        emails.contains(&"carol.tester@yahoo.com"),
        "semicolon delimiter"
    );
    assert!(
        emails.contains(&"dave.tester@protonmail.com"),
        "tab delimiter"
    );

    let passwords: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Password)
        .map(|e| e.value.as_str())
        .collect();
    assert!(passwords.contains(&"Sup3rSecret!"));
    assert!(passwords.contains(&"hunter2000"));
    assert!(passwords.contains(&"anotherPass9"));
    // eve's line has a delimiter but nothing after it — the whole line is
    // quarantined rather than minting a hallucinated empty-string secret (or
    // an unpaired identity the file never actually asserted a password for).
    assert!(!entities.iter().any(|e| e.value.is_empty()));
    assert!(!emails.contains(&"eve.tester@gmail.com"));

    // 3 structurally bad lines: no delimiter, empty identity, empty secret.
    assert_eq!(stats.malformed_lines, 3);
}

/// A `;`- or tab-delimited line whose PASSWORD contains a colon must split on
/// the real (earlier) delimiter. `split_combo_line` used to try the colon
/// authority unconditionally first, so `victim@x;Sept:2026!` became identity
/// `victim@x;Sept` — minted as a Username, not even the real Email — and
/// secret `2026!`, a truncated credential: a fabricated identity fed into the
/// graph silently, with no quarantine and no warning. Found by the workflow
/// correctness review, reproduced by running the parser on this exact line.
#[test]
fn parse_combolist_splits_on_the_earliest_delimiter_not_the_colon_first() {
    let body = "victim.tester@gmail.com;Sept:2026!\n\
                second.tester@outlook.com\tpa:ss:word\n\
                third.tester@yahoo.com:pa;ss\n";
    let (entities, stats) = parse_combolist(body, "s");
    let has =
        |kind: EntityKind, value: &str| entities.iter().any(|e| e.kind == kind && e.value == value);

    assert!(
        has(EntityKind::Email, "victim.tester@gmail.com"),
        "`;` line: the real email must survive: {entities:#?}"
    );
    assert!(
        has(EntityKind::Password, "Sept:2026!"),
        "`;` line: the whole password, embedded colon included"
    );
    assert!(
        has(EntityKind::Email, "second.tester@outlook.com"),
        "tab line"
    );
    assert!(
        has(EntityKind::Password, "pa:ss:word"),
        "tab line: the password keeps every later colon"
    );
    // The colon-dominant case is unchanged: a `;` INSIDE the password stays in it.
    assert!(has(EntityKind::Email, "third.tester@yahoo.com"));
    assert!(has(EntityKind::Password, "pa;ss"));
    assert!(
        !entities.iter().any(|e| e.kind == EntityKind::Username),
        "no fabricated identity (email fused with a password prefix): {entities:#?}"
    );
    assert_eq!(stats.malformed_lines, 0, "every line here is well-formed");
    assert_eq!(stats.emails, 3);
}

#[test]
fn parse_combolist_quarantines_sentinels_and_recovers_a_mis_stored_email() {
    let body = "frank.tester@gmail.com:[fail]\n\
                grace.tester@gmail.com:REDACTED\n\
                henry.tester@gmail.com:otherperson@outlook.com\n\
                ivan.tester@gmail.com:ivan.tester@gmail.com\n";
    let (entities, _stats) = parse_combolist(body, "s");
    // Every identity is still admitted...
    for id in [
        "frank.tester@gmail.com",
        "grace.tester@gmail.com",
        "henry.tester@gmail.com",
        "ivan.tester@gmail.com",
    ] {
        assert!(
            entities
                .iter()
                .any(|e| e.kind == EntityKind::Email && e.value == id),
            "{id} missing"
        );
    }
    // ...but no Password entity is minted from a sentinel or a self-echo,
    assert!(!entities.iter().any(|e| e.kind == EntityKind::Password));
    // and a password field that is itself an email is recovered as its own lead.
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "otherperson@outlook.com")
    );
}

// Regression: the self-echo guard used to compare the secret against the RAW
// identity text, not the normalised value `Entity::new` actually stores. A
// quoted or `@`-prefixed identity whose secret echoes the NORMALISED form
// (not the raw form) slipped past the guard and minted a spurious Password
// entity for a value that was really just the identity's own normalised
// self — exactly the class of fabricated finding RULE.md forbids. Found by
// automated review on the PR that introduced `parse_combolist`; reproduced
// against the pre-fix code (a Password entity for `alice` was minted
// alongside the Username entity for the exact same value) before the fix
// landed.
#[test]
fn parse_combolist_self_echo_guard_compares_the_normalised_identity() {
    let body = "'alice.tester':alice.tester\n\
                @bob.tester:BOB.TESTER\n";
    let (entities, _stats) = parse_combolist(body, "s");
    // Both identities are still admitted, normalised (quote/sigil stripped,
    // case-folded) exactly as `Entity::new` would produce on its own.
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Username && e.value == "alice.tester")
    );
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Username && e.value == "bob.tester")
    );
    // ...but neither line mints a Password entity: the secret in each case
    // is just the identity's own normalised form echoed back, not a real
    // credential — a raw-vs-raw comparison would have missed this and
    // fabricated one.
    assert!(
        !entities.iter().any(|e| e.kind == EntityKind::Password),
        "self-echo (quoted/sigil'd/case-differing identity) must never mint a \
         Password entity: {entities:?}"
    );
}

#[test]
fn parse_combolist_admits_a_bare_username_identity() {
    let body = "judy_tester_99:hunter2000\n";
    let (entities, stats) = parse_combolist(body, "s");
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Username && e.value == "judy_tester_99")
    );
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Password && e.value == "hunter2000")
    );
    assert_eq!(stats.malformed_lines, 0);
}

#[test]
fn parse_combolist_never_admits_an_identity_that_normalises_to_empty() {
    // A username normalises by stripping surrounding quotes; a bare `'` (and
    // nothing else) therefore normalises to the EMPTY string. This must never
    // reach the graph as an empty-value entity — the identity is quarantined
    // instead, exactly as a structurally malformed line would be.
    let (entities, stats) = parse_combolist("':secretvalue123\n", "s");
    assert!(!entities.iter().any(|e| e.value.is_empty()));
    assert!(!entities.iter().any(|e| e.kind == EntityKind::Username));
    assert_eq!(stats.malformed_lines, 1);
}

#[tokio::test]
async fn upload_dispatcher_routes_raw_combolist() {
    let (entities, label) = entities_from_upload(COMBOLIST, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "combolist");
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "alice.tester@gmail.com")
    );
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Password && e.value == "Sup3rSecret!")
    );
}

// ── SQL-dump import ─────────────────────────────────────────────────────────
//
// SYNTHETIC fixtures only — fabricated names at real free-mail providers (the
// same convention `COMBOLIST` above uses, for the same reason: `@example.*`
// is dropped by `is_placeholder_domain` before it could prove the full
// upload-dispatcher path). A leaked SQL dump (`INSERT INTO ... VALUES (...)`,
// the shape a `mysqldump` export of a compromised user table takes) matched
// no `looks_like_*` check and fell through to the OathNet TXT catch-all,
// which extracts nothing from it — a real breach dump silently imported as
// nothing, the same class of defect the combolist fix above addressed.

use super::sql_dump::{looks_like_sql_dump, parse_sql_dump};

const SQL_DUMP: &str = "INSERT INTO `users` (`id`, `email`, `username`, `password`, `full_name`) VALUES\n\
    (1, 'sql.tester.alpha@gmail.com', 'sqltesteralpha', 'SynthPassword1!', 'Sql TesterAlpha'),\n\
    (2, 'sql.tester.beta@outlook.com', 'sqltesterbeta', 'SynthPassword2!', 'Sql TesterBeta');\n";

#[test]
fn sql_dump_is_detected_and_oathnet_txt_is_not() {
    assert!(looks_like_sql_dump(SQL_DUMP));
    assert!(!looks_like_sql_dump(
        "just some prose that happens to mention insert and values in passing\n"
    ));
}

#[test]
fn parse_sql_dump_extracts_rows_with_escaped_and_multi_row_values() {
    let (entities, stats) = parse_sql_dump(SQL_DUMP, "s");

    let emails: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(emails.contains(&"sql.tester.alpha@gmail.com"));
    assert!(emails.contains(&"sql.tester.beta@outlook.com"));

    let passwords: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Credential)
        .map(|e| e.value.as_str())
        .collect();
    assert!(passwords.contains(&"SynthPassword1!"));
    assert!(passwords.contains(&"SynthPassword2!"));

    let names: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Person)
        .map(|e| e.value.as_str())
        .collect();
    assert!(names.contains(&"Sql TesterAlpha"));
    assert!(names.contains(&"Sql TesterBeta"));

    assert_eq!(stats.breach_records, 2);
    assert_eq!(stats.malformed_lines, 0);
}

/// A leaked table whose ONLY identity column is the login column, holding
/// email addresses — `(id, username, password)` with `username = 'alice@…'`,
/// one of the most common real schemas — must put those emails into the
/// graph. Both breach-table parsers gated the Username entity on
/// `!contains('@')` with no email fallback, so the identity was silently
/// dropped: reproduced live through the CLI and the HTTP upload as two bare
/// credentials and zero identities from this exact two-row table. Real
/// provider domains, as every fixture here (an `@example.*` placeholder is
/// filtered upstream).
#[test]
fn parse_sql_dump_dedups_an_expanded_and_a_compressed_ipv6_spelling() {
    // Regression: see combined_search's identical fix for the general shape.
    // A real public address (Google Public DNS) is used, not an RFC 3849
    // documentation one, so `is_bogus_ip` cannot mask the gap.
    let body = "INSERT INTO `users` (`id`, `username`, `ip`) VALUES\n\
        (1, 'user1', '2001:4860:4860:0000:0000:0000:0000:8888'),\n\
        (2, 'user2', '2001:4860:4860::8888');\n";
    let (entities, _stats) = parse_sql_dump(body, "s");
    let ips: Vec<&Entity> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::IpAddress)
        .collect();
    assert_eq!(
        ips.len(),
        1,
        "an expanded and a compressed spelling of the same IPv6 address must dedup to one entity: {ips:?}"
    );
}

#[test]
fn parse_sql_dump_recovers_an_email_held_in_the_username_column() {
    let body = "INSERT INTO `users` (`id`, `username`, `password`) VALUES\n\
        (1, 'alice.tester@gmail.com', 'Hunter2pass'),\n\
        (2, 'bob.tester@outlook.com', 'Sw0rdfish!');\n";
    let (entities, stats) = parse_sql_dump(body, "s");
    let emails: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        emails.contains(&"alice.tester@gmail.com") && emails.contains(&"bob.tester@outlook.com"),
        "the login column's emails must become Email entities: {entities:#?}"
    );
    assert!(
        !entities.iter().any(|e| e.kind == EntityKind::Username),
        "an email-shaped login is never minted as a Username"
    );
    assert_eq!(stats.emails, 2);
    assert_eq!(stats.breach_records, 2);

    // A separate email column carrying the SAME address must not double-emit.
    let both = "INSERT INTO `users` (`email`, `username`) VALUES \
        ('carol.tester@yahoo.com', 'carol.tester@yahoo.com');\n";
    let (ents, st) = parse_sql_dump(both, "s");
    assert_eq!(
        ents.iter().filter(|e| e.kind == EntityKind::Email).count(),
        1,
        "{ents:#?}"
    );
    assert_eq!(st.emails, 1);

    // A plain handle in the login column is still a Username (unchanged).
    let handle = "INSERT INTO `users` (`username`, `password`) VALUES ('dtester', 'pw12345');\n";
    let (ents, _) = parse_sql_dump(handle, "s");
    assert!(
        ents.iter()
            .any(|e| e.kind == EntityKind::Username && e.value == "dtester")
    );
}

/// A real `mysqldump` breach table routinely carries phone / address / IP /
/// password-hash columns alongside the identity columns — but every other
/// SQL-dump fixture in this suite declares only id/email/username/password/
/// full_name, so `phone_i`/`addr_i`/`ip_i`/`hashed_idxs` and their
/// entity-emission arms had never executed in CI. This exercises each of them
/// on one row, so a regression in exactly the fields most breach dumps carry
/// per row is caught. Synthetic placeholders only; the shapes mirror the
/// DeHashed CSV coverage above.
#[test]
fn parse_sql_dump_extracts_phone_address_ip_and_password_hash_columns() {
    let body = "INSERT INTO `users` \
        (`id`, `email`, `phone`, `address`, `ip`, `password_hash`) VALUES\n\
        (1, 'gamma.tester@gmail.com', '0412 345 678', \
         '12 Smith Street, Carlton VIC 3053', '24.32.96.71', \
         '$2a$10$abcdefghijklmnopqrstuv');\n";
    let (entities, stats) = parse_sql_dump(body, "s");
    let has = |kind: EntityKind, pred: &dyn Fn(&str) -> bool| {
        entities.iter().any(|e| e.kind == kind && pred(&e.value))
    };
    // The AU local phone is recovered and canonicalised to E.164.
    assert!(
        has(EntityKind::Phone, &|v| v == "+61412345678"),
        "phone column → E.164 Phone: {entities:#?}"
    );
    assert!(
        has(EntityKind::Address, &|v| v
            .to_ascii_lowercase()
            .contains("carlton")),
        "address column → Address"
    );
    assert!(
        has(EntityKind::IpAddress, &|v| v == "24.32.96.71"),
        "ip column → IpAddress"
    );
    assert!(
        has(EntityKind::Credential, &|v| v.starts_with("$2a$")),
        "password_hash column → Credential (hash)"
    );
    assert_eq!(stats.phones, 1);
    assert_eq!(stats.addresses, 1);
    assert_eq!(stats.ips, 1);
    assert_eq!(stats.breach_records, 1);
}

/// `cmd_import`'s directory + forced-format guard (the `if meta.is_dir()` block
/// in mod.rs) is a pure filesystem check that returns BEFORE any store access,
/// so it is drivable end-to-end with only a temp directory — yet no test
/// exercised it. It must REFUSE `--input-format` against a directory (a scrape
/// detects each file's format from its content), naming the forced format,
/// rather than silently ignoring the operator's override.
#[tokio::test]
async fn cmd_import_refuses_a_forced_format_against_a_directory() {
    let dir = tempfile::tempdir().expect("temp dir");
    let path = dir.path().to_str().expect("utf-8 temp path");
    let err = cmd_import(path, "table", Some(ImportFormat::SqlDump))
        .await
        .expect_err("a forced format on a directory must be refused, not ignored");
    let msg = err.to_string();
    assert!(
        msg.contains("--input-format") && msg.contains("sql-dump") && msg.contains("directory"),
        "the refusal must name the forced format and the reason: {msg}"
    );
    // Control: the SAME directory with no forced format is a scrape, not an
    // error (an empty dir scrapes to an empty result, but must not error on
    // the guard path).
    assert!(
        cmd_import(path, "table", None).await.is_ok(),
        "a directory scrape without a forced format must not hit the guard"
    );
}

#[test]
fn parse_sql_dump_unescapes_backslash_and_doubled_quote_dialects() {
    // mysqldump-style backslash escaping AND standard-SQL doubled-quote
    // escaping must both work, since a real dump could use either — the
    // parser never needs to guess which dialect produced it.
    let body = "INSERT INTO `users` (`email`, `full_name`) VALUES ('escape.tester@gmail.com', 'Conor O\\'Brien'), ('escape.tester2@gmail.com', 'Aoife O''Malley');\n";
    let (entities, _stats) = parse_sql_dump(body, "s");
    let names: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Person)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        names.contains(&"Conor O'Brien"),
        "backslash-escaped quote: {names:?}"
    );
    assert!(
        names.contains(&"Aoife O'Malley"),
        "doubled-quote escape: {names:?}"
    );
}

#[test]
fn parse_sql_dump_quarantines_a_row_whose_value_count_does_not_match_columns() {
    let body = "INSERT INTO `users` (`email`, `password`) VALUES \
                ('quarantine.tester@gmail.com', 'SynthPassword3!', 'unexpected-extra-value');\n";
    let (entities, stats) = parse_sql_dump(body, "s");
    assert!(
        !entities.iter().any(|e| e.kind == EntityKind::Email),
        "a row whose value count doesn't match its column list is not a record HSE can trust — quarantined whole, not partially guessed"
    );
    assert_eq!(stats.malformed_lines, 1);
    assert_eq!(stats.breach_records, 0);
}

#[test]
fn parse_sql_dump_never_guesses_columns_when_the_insert_has_no_explicit_list() {
    // No column list on the INSERT — HSE never recovers it from a separate
    // CREATE TABLE, since the two could disagree on order (RULE.md: no
    // fabricated findings). `looks_like_sql_dump` also correctly declines
    // this shape, since the detector's own regex requires the column list.
    let body = "CREATE TABLE users (email TEXT, password TEXT);\n\
                INSERT INTO users VALUES ('noguess.tester@gmail.com', 'SynthPassword4!');\n";
    assert!(!looks_like_sql_dump(body));
    let (entities, _stats) = parse_sql_dump(body, "s");
    assert!(entities.is_empty());
}

#[tokio::test]
async fn upload_dispatcher_routes_sql_dump() {
    let (entities, label) = entities_from_upload(SQL_DUMP, "s", None)
        .await
        .expect("should succeed");
    assert_eq!(label, "sql-dump");
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "sql.tester.alpha@gmail.com")
    );
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Credential && e.value == "SynthPassword1!")
    );
}

// ── Property tests (proptest) — no-panic contract for untrusted import ────────
//
// These parsers consume untrusted bytes supplied by the operator or uploaded via
// the web endpoint; the CLI import path has no `catch_unwind`, so a panic kills
// the process. The properties below pin the no-panic contract over thousands of
// arbitrary Unicode strings (incl. multibyte sequences landing next to structural
// bytes: `•`, `->`, `@`, `:`, section markers, truncated entry blocks) — the
// class the hand-coded adversarial table in
// `upload_dispatcher_never_panics_on_adversarial_input` can never exhaust.
mod prop {
    use proptest::prelude::*;

    use super::super::combolist::parse_combolist;
    use super::super::sql_dump::parse_sql_dump;
    use super::super::{
        parse_dossier, parse_oathnet_html, parse_oathnet_report, parse_oathnet_txt,
        parse_stealerlogs,
    };

    proptest! {
        /// `parse_dossier` must never panic on any input string and must only
        /// emit non-empty entity values.
        #[test]
        fn parse_dossier_never_panics(s in ".{0,512}") {
            let (ents, _) = parse_dossier(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_stealerlogs` must never panic on any input string — its nested
        /// `[N]` / indentation grammar consumes untrusted bytes — and must only
        /// emit non-empty entity values.
        #[test]
        fn parse_stealerlogs_never_panics(s in ".{0,512}") {
            let (ents, _, _) = parse_stealerlogs(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_oathnet_report` must never panic on any input string and must
        /// only emit non-empty entity values.
        #[test]
        fn parse_oathnet_report_never_panics(s in ".{0,512}") {
            let (ents, _) = parse_oathnet_report(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_oathnet_txt` must never panic on any input string and must only
        /// emit non-empty entity values.
        #[test]
        fn parse_oathnet_txt_never_panics(s in ".{0,512}") {
            let (ents, _) = parse_oathnet_txt(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_oathnet_html` must never panic on any input string and must
        /// only emit non-empty entity values.
        #[test]
        fn parse_oathnet_html_never_panics(s in ".{0,512}") {
            let ents = parse_oathnet_html(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_combolist` must never panic on any input string and must only
        /// emit non-empty entity values, however many malformed lines it quarantines.
        #[test]
        fn parse_combolist_never_panics(s in ".{0,512}") {
            let (ents, _stats) = parse_combolist(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }

        /// `parse_sql_dump` must never panic on any input string and must only
        /// emit non-empty entity values, however many malformed rows it quarantines.
        #[test]
        fn parse_sql_dump_never_panics(s in ".{0,512}") {
            let (ents, _stats) = parse_sql_dump(&s, "s");
            for e in &ents {
                prop_assert!(!e.value.is_empty(), "empty value in entity: {e:?}");
            }
        }
    }
}

// ── input-format override (`hse import --input-format`, upload `?format=`) ──

/// The format enum is the ONE spelling authority: `label()` must equal the
/// clap `ValueEnum` name for every variant, and `parse_name` must round-trip
/// each label (case- and whitespace-insensitively), so the CLI flag, the
/// upload parameter and the label both surfaces report can never drift.
#[test]
fn import_format_names_are_one_authority() {
    use clap::ValueEnum;
    for f in ImportFormat::value_variants() {
        let derived = f.to_possible_value().expect("no variant is skipped");
        assert_eq!(
            f.label(),
            derived.get_name(),
            "label() drifted from the clap spelling for {f:?}"
        );
        assert_eq!(ImportFormat::parse_name(f.label()), Ok(*f));
        assert_eq!(
            ImportFormat::parse_name(&format!("  {}  ", f.label().to_ascii_uppercase())),
            Ok(*f),
            "case- and whitespace-insensitive"
        );
    }
    let err = ImportFormat::parse_name("bogus").expect_err("unknown names are rejected");
    assert!(
        err.contains("`bogus`") && err.contains("combolist") && err.contains("oathnet-txt"),
        "the rejection must name the typo and every accepted spelling: {err}"
    );
}

/// The motivating case for the override: a combolist whose identities are ALL
/// bare usernames has no email-shaped line for the content detector to count,
/// so it cannot be sniffed as a combolist — yet `parse_combolist` handles it
/// fine once reached. Forcing the format reaches it, and the entities come
/// back under the forced label.
#[tokio::test]
async fn forced_input_format_reaches_the_combolist_parser_for_bare_usernames() {
    const USERNAMES_ONLY: &str =
        "alice.tester:Passw0rd!2026\nbob_tester:hunter2-synthetic\ncarol-tester:S3cret#fixture\n";
    let (ents, label) = entities_from_upload(USERNAMES_ONLY, "s", Some(ImportFormat::Combolist))
        .await
        .expect("a forced combolist parses");
    assert_eq!(label, "combolist");
    let mut usernames: Vec<&str> = ents
        .iter()
        .filter(|e| e.kind == crate::core::entity::EntityKind::Username)
        .map(|e| e.value.as_str())
        .collect();
    usernames.sort_unstable();
    assert_eq!(usernames, ["alice.tester", "bob_tester", "carol-tester"]);
    let passwords = ents
        .iter()
        .filter(|e| e.kind == crate::core::entity::EntityKind::Password)
        .count();
    assert_eq!(passwords, 3, "one Password per line: {ents:#?}");
}

/// The override is authoritative even where detection would have chosen
/// differently — and it fails loudly, never silently, when the forced parser
/// cannot read the body. Both halves use bodies whose detection result is
/// stable by design (a dossier's `Entry #` marker; non-JSON text).
#[tokio::test]
async fn forced_input_format_overrides_content_detection() {
    const DOSSIER: &str =
        "Entry #1:\n   \u{2022} username: isaacfrost\n   \u{2022} email: isaacfrost@gmail.com\n";
    let (_, detected) = entities_from_upload(DOSSIER, "s", None)
        .await
        .expect("detected");
    assert_eq!(
        detected, "dossier",
        "precondition: detection picks the dossier parser"
    );
    let (_, forced) = entities_from_upload(DOSSIER, "s", Some(ImportFormat::OathnetTxt))
        .await
        .expect("forced");
    assert_eq!(
        forced, "oathnet-txt",
        "the forced format must win over detection"
    );
    // A forced JSON parse of non-JSON text is an explicit error, not an
    // empty success.
    assert!(
        entities_from_upload("not json at all", "s", Some(ImportFormat::OathnetJson))
            .await
            .is_err()
    );
}

/// The web UI's format selector (`#dossier-format` in
/// `src/web/js/views/new_scan.js`) must offer exactly the import formats, in
/// declaration order — it is the one place the names are spelled outside this
/// enum, and a stale option would send the server a name it rejects.
#[test]
fn web_upload_format_selector_lists_exactly_the_import_formats() {
    use clap::ValueEnum;
    const NEW_SCAN_JS: &str = include_str!("../../web/js/views/new_scan.js");
    let start = NEW_SCAN_JS
        .find("id=\"dossier-format\"")
        .expect("the upload form has a #dossier-format selector");
    let rest = &NEW_SCAN_JS[start..];
    let block = &rest[..rest.find("</select>").expect("the selector closes")];
    let listed: Vec<&str> = block
        .split("<option value=\"")
        .skip(1)
        .filter_map(|s| s.split('"').next())
        .filter(|v| !v.is_empty())
        .collect();
    let expected: Vec<&str> = ImportFormat::value_variants()
        .iter()
        .copied()
        .map(ImportFormat::label)
        .collect();
    assert_eq!(
        listed, expected,
        "#dossier-format must offer every ImportFormat name, in declaration order, and nothing else"
    );
}

/// A stealer-log export with a `Credentials:` list but no `Log Id:` line fails
/// `looks_like_stealerlogs` (which requires all three markers) yet
/// `parse_stealerlogs` reads it fine — so on a forced `?format=stealerlogs`
/// upload, `stealer_rows_from_upload` must honour the forced format instead of
/// re-running the detection the operator deliberately bypassed, or the paired
/// rows are silently lost while the entities import.
#[test]
fn stealer_rows_from_upload_honours_the_forced_format() {
    // Detection-missing (no `Module: Stealerlogs` banner, no `Log Id:`) but
    // parseable: one victim, one credential.
    const NO_LOG_ID: &str = "Victims:\n  [1]\n    Credentials:\n      [1]\n        \
Username:\n          jordanavery@gmail.com\n        Password:\n          Hunter2pass\n";

    // Precondition — the data-loss trap: content detection rejects it, but the
    // parser still recovers the paired row, so anything gated on detection
    // alone drops that row.
    assert!(
        !looks_like_stealerlogs(NO_LOG_ID),
        "precondition: an export with no `Log Id:` is not detected as stealerlogs"
    );
    assert_eq!(
        parse_stealerlogs(NO_LOG_ID, "s").2.len(),
        1,
        "precondition: the parser still recovers the paired row"
    );

    // Auto-detect (no operator hint): consistent with detection — no rows, the
    // unchanged pre-override behaviour.
    assert!(super::stealer_rows_from_upload(NO_LOG_ID, None).is_empty());

    // Forced stealerlogs (the override used to reach the parser): the paired
    // rows are recovered, not silently dropped.
    let rows = super::stealer_rows_from_upload(NO_LOG_ID, Some(ImportFormat::Stealerlogs));
    assert_eq!(
        rows.len(),
        1,
        "forced stealerlogs must recover the paired row"
    );
    assert_eq!(rows[0].login.as_deref(), Some("jordanavery@gmail.com"));
    assert_eq!(rows[0].password.as_deref(), Some("Hunter2pass"));

    // Forced to a DIFFERENT format on a genuinely stealer-shaped body: the rows
    // the operator overrode are not emitted, so the two parses of one upload
    // agree on the format.
    assert!(
        super::stealer_rows_from_upload(STEALER, Some(ImportFormat::Combolist)).is_empty(),
        "a body forced away from stealerlogs must not emit stealer rows"
    );
}

/// An `INSERT ... VALUES` substring inside a text column VALUE must not be
/// mistaken for a statement boundary. It used to be: the header regex matched
/// inside the quoted `bio`, truncated the real statement mid-string, and the
/// tuple parser then quarantined every remaining row — so a `mysqldump
/// --extended-insert` table (one statement, all rows) silently imported as
/// **zero** entities, the exact silent breach-data loss this parser exists to
/// prevent. `string_literal_spans` now excludes in-string header matches.
#[test]
fn parse_sql_dump_ignores_insert_substrings_inside_string_values() {
    // Row 1's bio contains a full `INSERT INTO t (c) VALUES (1)`; both rows
    // (and their emails) must still be extracted, in one extended-insert
    // statement.
    let body = "INSERT INTO users (email, bio) VALUES \
        ('victim@example.org', 'I ran INSERT INTO t (c) VALUES (1) yesterday'), \
        ('second@example.org', 'ok');";
    let (entities, stats) = parse_sql_dump(body, "s");
    let emails: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        emails.contains(&"victim@example.org") && emails.contains(&"second@example.org"),
        "both rows must survive an inner INSERT substring: {emails:?} ({} malformed)",
        stats.malformed_lines
    );
    assert_eq!(stats.breach_records, 2, "two real rows, one statement");
    assert_eq!(stats.malformed_lines, 0, "nothing is malformed here");

    // The doubled-quote dialect (`''`) and the backslash dialect (`\'`) both
    // keep the inner INSERT inside the string.
    for one in [
        "INSERT INTO u (email, q) VALUES ('a@example.org', 'it''s an INSERT INTO z (x) VALUES (2)');",
        "INSERT INTO u (email, q) VALUES ('a@example.org', 'a \\' and INSERT INTO z (x) VALUES (3)');",
    ] {
        let (ents, st) = parse_sql_dump(one, "s");
        assert!(
            ents.iter()
                .any(|e| e.kind == EntityKind::Email && e.value == "a@example.org"),
            "dialect case must extract the email: {one}"
        );
        assert_eq!(st.malformed_lines, 0, "no quarantine for: {one}");
    }

    // Guard the fix does not OVER-filter: two genuinely separate statements
    // still split into two rows.
    let two = "INSERT INTO u (email) VALUES ('x@example.org');\n\
               INSERT INTO u (email) VALUES ('y@example.org');";
    let (ents, _) = parse_sql_dump(two, "s");
    let two_emails: Vec<&str> = ents
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        two_emails.contains(&"x@example.org") && two_emails.contains(&"y@example.org"),
        "real multi-statement dumps must still split: {two_emails:?}"
    );
}

/// `string_literal_spans` must track escape PARITY correctly across a run of
/// consecutive backslashes (each `\\` is one escaped backslash; a following
/// lone `\'` is a separate escaped quote — the two must not be conflated),
/// and a body truncated mid-string (a realistic partial/corrupted upload)
/// must neither panic/hang nor corrupt an earlier, complete statement's row.
#[test]
fn parse_sql_dump_string_scanning_handles_escape_parity_and_truncation() {
    // Three backslashes then a quote = one escaped-backslash pair (`\\`) plus
    // one escaped-quote pair (`\'`) in sequence. The string must stay OPEN
    // through both, so the embedded `INSERT INTO` text is never mistaken for
    // a real statement boundary and the row is not quarantined. A regression
    // that mishandles chained escapes would falsely close the string early,
    // truncate this statement, and drop the email entirely.
    let odd_backslash_run = "INSERT INTO u (email, bio) VALUES \
        ('a@example.org', 'a \\\\\\' still open INSERT INTO z (x) VALUES (9)');";
    let (entities, stats) = parse_sql_dump(odd_backslash_run, "s");
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "a@example.org"),
        "a chained backslash-then-quote escape run must not falsely close the string: {entities:?}"
    );
    assert_eq!(
        stats.malformed_lines, 0,
        "the escape-parity case is well-formed, not malformed"
    );

    // A body truncated mid-string (a partial/corrupted upload, e.g. a network
    // cut-off) must not panic or hang, and must not corrupt an EARLIER,
    // complete statement's row — only the truncated statement's own tuple is
    // quarantined whole (`parse_value_tuple` never emits a partial row).
    let truncated = "INSERT INTO u (email) VALUES ('good@example.org');\n\
        INSERT INTO u (email, bio) VALUES ('trunc@example.org', 'this bio never closes";
    let (entities, stats) = parse_sql_dump(truncated, "s");
    let emails: Vec<&str> = entities
        .iter()
        .filter(|e| e.kind == EntityKind::Email)
        .map(|e| e.value.as_str())
        .collect();
    assert!(
        emails.contains(&"good@example.org"),
        "the earlier, complete statement must survive a later truncation: {emails:?}"
    );
    assert!(
        !emails.contains(&"trunc@example.org"),
        "the truncated statement's own row must be quarantined whole, not \
         partially emitted: {emails:?}"
    );
    assert!(
        stats.malformed_lines >= 1,
        "the truncated tuple must be counted as malformed"
    );
}

/// A DeHashed-style breach CSV whose header uses a plausible synonym instead
/// of DeHashed's own canonical column name (`email_address` not `email`,
/// `user_name`/`pass`/`mobile`/`street_address` not `username`/`password`/
/// `phone`/`address`) must not silently drop that field. It used to: the
/// detector fires on shape (an identity column plus a `database_name`/
/// `hashed_password` hallmark), independent of exactly which identity-column
/// name is present, but the parser matched only the single canonical name —
/// so a real row with every field present reported a normal-looking import
/// with entities quietly missing and no warning, no quarantine count. The
/// SQL-dump parser (`sql_dump.rs`, same PR) already tolerated these exact
/// synonyms for the identical PII categories; `find_column` (promoted to the
/// shared `super` authority) now backs both.
/// The DeHashed-style CSV parser shares the SQL-dump parser's identity-column
/// rule (`identity_column_kind`), so the same `username`-holds-an-email shape
/// must recover the Email here too — reproduced live as the identical silent
/// drop through both the CLI and the HTTP upload.
#[test]
fn parse_dehashed_csv_recovers_an_email_held_in_the_username_column() {
    let body = "id,username,password,database_name\n\
                1,carol.tester@yahoo.com,Tr0ub4dor&3,BreachCo\n\
                2,dave.tester@protonmail.com,correcthorse,BreachCo\n";
    assert!(
        looks_like_dehashed_csv(body),
        "precondition: this shape is detected as DeHashed-style"
    );
    let (entities, stats) = parse_dehashed_csv(body, "s");
    let has =
        |kind: EntityKind, value: &str| entities.iter().any(|e| e.kind == kind && e.value == value);
    assert!(
        has(EntityKind::Email, "carol.tester@yahoo.com")
            && has(EntityKind::Email, "dave.tester@protonmail.com"),
        "the login column's emails must become Email entities: {entities:#?}"
    );
    assert!(
        !entities.iter().any(|e| e.kind == EntityKind::Username),
        "an email-shaped login is never minted as a Username"
    );
    assert_eq!(stats.emails, 2);
    assert!(has(EntityKind::Credential, "Tr0ub4dor&3"));
}

#[test]
fn parse_dehashed_csv_tolerates_synonym_column_names() {
    let body = "id,email_address,user_name,database_name,pass,mobile,street_address\n\
                1,jane@example.org,jdoe,BreachCo,hunter2,0400000000,12 Main St\n";
    assert!(
        looks_like_dehashed_csv(body),
        "precondition: this shape is detected as DeHashed-style"
    );
    let (entities, _stats) = parse_dehashed_csv(body, "s");
    let has = |kind: EntityKind, value: &str| {
        entities
            .iter()
            .any(|e| e.kind == kind && e.value.eq_ignore_ascii_case(value))
    };
    assert!(
        has(EntityKind::Email, "jane@example.org"),
        "email_address column"
    );
    assert!(has(EntityKind::Username, "jdoe"), "user_name column");
    assert!(has(EntityKind::Credential, "hunter2"), "pass column");
    // `to_e164_au` normalises the raw AU mobile format to E.164.
    assert!(has(EntityKind::Phone, "+61400000000"), "mobile column");
    assert!(
        entities
            .iter()
            .any(|e| e.kind == EntityKind::Address && e.value.contains("12 Main St")),
        "street_address column: {entities:#?}"
    );

    // Guard: DeHashed's own canonical header (the common real case) is
    // unaffected by widening the matcher.
    let canonical = "id,email,username,name,database_name,password,phone\n\
                      1,jordanavery@gmail.com,javery,Jordan Avery,ExampleBreach,Hunter2pass,+61412345678\n";
    let (canon_entities, _) = parse_dehashed_csv(canonical, "s");
    assert!(
        canon_entities
            .iter()
            .any(|e| e.kind == EntityKind::Email && e.value == "jordanavery@gmail.com")
    );
    assert!(
        canon_entities
            .iter()
            .any(|e| e.kind == EntityKind::Phone && e.value == "+61412345678")
    );
}

/// The detector alone, independent of the parser: a row whose IDENTITY column
/// also uses a synonym (`email_address` + `user_name` together, neither
/// canonical name present) must still be recognised as DeHashed-shaped. This
/// is the more severe half of the synonym gap — it used to be TOTAL loss, not
/// partial: the file was never even routed to the (already synonym-tolerant)
/// parser, so it fell through the whole detection chain. Reproduced live on
/// both surfaces that reach content-only detection (`path == ""`): a real
/// `POST /scans/import` upload got a flat `400 no verifiable entities`, and a
/// CLI import of the same content under a non-`.csv` filename (bypassing the
/// `path.ends_with(".csv")` shortcut `detect_import_format` also has) fell
/// through to the OathNet-TXT catch-all and imported zero entities.
#[test]
fn dehashed_csv_detector_recognises_synonym_identity_columns() {
    let body = "id,email_address,user_name,database_name,pass\n\
                1,jane@example.org,jdoe,BreachCo,hunter2\n";
    assert!(
        looks_like_dehashed_csv(body),
        "an email_address + user_name header with a database_name hallmark \
         must still be detected as DeHashed-shaped"
    );

    // The hallmark requirement is unrelaxed: an identity-shaped CSV with
    // neither hallmark column must still be rejected (unchanged strictness).
    assert!(!looks_like_dehashed_csv(
        "id,email_address,notes\n1,jane@example.org,hello\n"
    ));
}
