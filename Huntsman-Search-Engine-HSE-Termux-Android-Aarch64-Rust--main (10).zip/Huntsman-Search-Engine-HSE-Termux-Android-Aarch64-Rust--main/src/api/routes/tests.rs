use super::*;

    #[test]
    fn loopback_recognised() {
        assert!(is_loopback_bind("127.0.0.1:8080"));
        assert!(is_loopback_bind("127.1.2.3:9000"));
        assert!(is_loopback_bind("localhost:8080"));
        assert!(is_loopback_bind("[::1]:8080"));
        assert!(is_loopback_bind("::1"));
    }

    #[test]
    fn non_loopback_rejected() {
        assert!(!is_loopback_bind("0.0.0.0:8080"));
        assert!(!is_loopback_bind("192.168.1.10:8080"));
        assert!(!is_loopback_bind("10.0.0.5:8080"));
        assert!(!is_loopback_bind("example.com:8080"));
    }

    #[test]
    fn host_allowlist_covers_loopback_aliases_and_rejects_rebind() {
        let set = host_allowlist("127.0.0.1:8080").expect("loopback bind has an allowlist");
        // The names a user legitimately types — all accepted.
        for h in [
            "127.0.0.1:8080",
            "localhost:8080",
            "[::1]:8080",
            "localhost",
            "127.0.0.1",
        ] {
            assert!(set.contains(h), "{h} must be allowed");
        }
        // A DNS-rebind Host (the attacker's domain) is NOT in the set.
        assert!(!set.contains("evil.example.com:8080"));
        assert!(!set.contains("evil.example.com"));
    }

    #[test]
    fn host_allowlist_is_none_for_non_loopback_bind() {
        // A 0.0.0.0 bind is an explicit operator choice to expose the API; the
        // valid Host set is the box's own (unknowable) addresses, so no guard.
        assert!(host_allowlist("0.0.0.0:8080").is_none());
    }

    #[test]
    fn loopback_edge_cases() {
        assert!(is_loopback_bind("localhost"));
        assert!(!is_loopback_bind("localhostx:8080"));
        assert!(!is_loopback_bind(""));
    }

    #[test]
    fn cors_loopback_includes_localhost_alias() {
        let layer = build_cors_layer("127.0.0.1:8080");
        let _ = layer;
    }

    #[test]
    fn cors_non_loopback_excludes_localhost() {
        let layer = build_cors_layer("192.168.1.5:8080");
        let _ = layer;
    }

    #[test]
    fn cors_ipv6_loopback() {
        let layer = build_cors_layer("[::1]:8080");
        let _ = layer;
    }

    #[test]
    fn if_none_match_hits_star_exact_and_list() {
        let etag = concat!("\"", env!("CARGO_PKG_VERSION"), "\"");
        assert!(if_none_match_hit("*", etag), "wildcard matches");
        assert!(if_none_match_hit(etag, etag), "exact match");
        assert!(
            if_none_match_hit(&format!("\"old\", {etag}"), etag),
            "match within a comma list"
        );
        assert!(!if_none_match_hit("\"old\"", etag), "different tag misses");
        assert!(!if_none_match_hit("", etag), "empty header misses");
    }

    // ── Airtight, offline-by-construction local console ────────────────────────
    //
    // The console is a self-contained binary that, on the project's flaky-
    // cellular phone target, must talk to nothing but itself: no CDN, no font
    // host, no analytics beacon, no exfiltration path for the sensitive findings
    // it holds. The integration tests assert the strict CSP directives are
    // PRESENT on served responses; these source-level tests assert nothing
    // external was ADDED — a gap a `contains("connect-src 'self'")` check leaves
    // open, since `connect-src 'self' https://exfil.example` contains it too.

    /// Tokens a CSP fetch/navigation directive may legitimately carry. Anything
    /// else — notably an `http(s)://` host or a `*` wildcard — would let the
    /// console reach an external origin, the one thing this policy forbids.
    /// `'wasm-unsafe-eval'` is the narrow CSP3 token for WebAssembly
    /// compilation specifically (required for the wasm-ui build to run at
    /// all — confirmed directly in a real browser) — not the general
    /// `'unsafe-eval'`, which stays absent and would still fail this list.
    const ALLOWED_CSP_TOKENS: &[&str] = &[
        "'self'",
        "'unsafe-inline'",
        "'none'",
        "data:",
        "'wasm-unsafe-eval'",
    ];

    #[test]
    fn csp_names_no_external_origin() {
        for needle in ["http://", "https://", "//", "*"] {
            assert!(
                !CONTENT_SECURITY_POLICY.contains(needle),
                "CSP must name no external origin/wildcard, found {needle:?}: \
                 {CONTENT_SECURITY_POLICY}"
            );
        }
    }

    #[test]
    fn csp_directives_use_only_self_or_inline_tokens() {
        for directive in CONTENT_SECURITY_POLICY.split(';') {
            let mut parts = directive.split_whitespace();
            let Some(name) = parts.next() else { continue };
            for token in parts {
                assert!(
                    ALLOWED_CSP_TOKENS.contains(&token),
                    "CSP directive {name:?} carries a non-self token {token:?}"
                );
            }
        }
    }

    #[test]
    fn permissions_policy_denies_phone_sensors() {
        // Every powerful feature must be present with an empty `()` allowlist.
        for feature in ["camera", "microphone", "geolocation", "usb", "bluetooth"] {
            assert!(
                PERMISSIONS_POLICY.contains(&format!("{feature}=()")),
                "Permissions-Policy must deny {feature}: {PERMISSIONS_POLICY}"
            );
        }
        // A non-empty allowlist would grant the feature — none may appear.
        assert!(
            !PERMISSIONS_POLICY.contains("=(self)") && !PERMISSIONS_POLICY.contains("=*"),
            "Permissions-Policy must grant nothing: {PERMISSIONS_POLICY}"
        );
    }

    /// Any external (`http(s)://` or protocol-relative `//host`) resource the
    /// embedded SPA auto-loads via `<script src>`, `<link href>`, or `<img src>`.
    /// Navigational `<a href>` links and the SVG `xmlns` identifier are not
    /// resource loads and are intentionally not inspected.
    fn external_resource_refs(html: &str) -> Vec<String> {
        fn attr_value<'a>(tag: &'a str, attr: &str) -> Option<&'a str> {
            for q in ['"', '\''] {
                let needle = format!("{attr}={q}");
                if let Some(p) = tag.find(&needle) {
                    let rest = &tag[p + needle.len()..];
                    if let Some(e) = rest.find(q) {
                        return Some(&rest[..e]);
                    }
                }
            }
            None
        }
        let mut hits = Vec::new();
        for (tag, attr) in [("<script", "src"), ("<link", "href"), ("<img", "src")] {
            let mut idx = 0;
            while let Some(rel) = html[idx..].find(tag) {
                let start = idx + rel;
                let end = html[start..].find('>').map_or(html.len(), |e| start + e);
                if let Some(v) = attr_value(&html[start..end], attr) {
                    let v = v.trim();
                    if v.starts_with("http://") || v.starts_with("https://") || v.starts_with("//")
                    {
                        hits.push(format!("{tag} {attr}={v:?}"));
                    }
                }
                idx = end;
            }
        }
        hits
    }

    /// Look up an embedded first-party SPA module's source by its served path
    /// (e.g. `"js/api.js"`, `"js/scan_info/graph.js"`, `"css/app.css"`) — the
    /// same keys [`APP_FILES`] serves at `/static/{path}`. The former
    /// monolithic `spa.html` held every view in one string; now that the SPA
    /// is split into per-concern modules (see `src/web/js/`), a test that
    /// used to search `SPA_HTML` for one view's content instead searches
    /// that view's own file directly — which also keeps each test's
    /// boundary-slicing (`split_once`/`find`) scoped to the single file that
    /// actually owns the content, exactly as it was scoped to that file's
    /// region of the old monolith.
    fn app_file(served_path: &str) -> &'static str {
        APP_FILES
            .iter()
            .find(|(name, _, _)| *name == served_path)
            .map_or_else(
                || panic!("no APP_FILES entry named {served_path:?}"),
                |(_, _, bytes)| std::str::from_utf8(bytes).expect("APP_FILES entry is valid UTF-8"),
            )
    }

    #[test]
    fn embedded_spa_auto_loads_nothing_external() {
        let hits = external_resource_refs(SPA_HTML);
        assert!(
            hits.is_empty(),
            "the embedded SPA must auto-load no external resource (CDN/font/\
             beacon); found: {hits:?}"
        );
    }

    #[test]
    fn embedded_spa_wires_the_key_diagnostics_endpoints() {
        // The /keys/status + /keys/patterns operator-telemetry endpoints exist and
        // are tested server-side; this guards that the SPA actually FETCHES them
        // (the Settings "Key diagnostics" panel) so they cannot silently revert to
        // dead-from-the-UI endpoints.
        let api = app_file("js/api.js");
        assert!(
            api.contains("/api/v1/keys/status"),
            "SPA must call /api/v1/keys/status (Key diagnostics panel)"
        );
        assert!(
            api.contains("/api/v1/keys/patterns"),
            "SPA must call /api/v1/keys/patterns (detector-coverage telemetry)"
        );
    }

    #[test]
    fn embedded_spa_wires_the_module_health_endpoint() {
        // /api/v1/modules/health (PROBLEM_TREE T2.7 / SOLUTION_TREE
        // SOL-HEALTH-SIGNAL) was previously reachable only from `hse doctor`;
        // guard that the Dashboard's "Module Health" panel actually fetches
        // and renders it, so it can't silently regress to dead-from-the-UI.
        let api = app_file("js/api.js");
        assert!(
            api.contains("/api/v1/modules/health"),
            "SPA must call /api/v1/modules/health (Dashboard Module Health panel)"
        );
        let dash = app_file("js/views/dash.js");
        assert!(
            // Ported to wasm-ui/src/views/dash.rs (renderModuleHealthPanelHtml,
            // called here via /static/hse_wasm_ui.js) — the JS-side call site
            // is the string that must keep wiring the fetched data in.
            dash.contains("renderModuleHealthPanelHtml("),
            "the Dashboard must render the module-health panel"
        );
    }

    #[test]
    fn embedded_spa_wires_the_capability_probe_endpoint() {
        // /api/v1/capabilities/probe (v1.14+) is the proactive live capability
        // preflight — the in-browser twin of `hse doctor --live`. Guard that the
        // Engines page actually fetches and renders it, so the panel can't
        // silently regress to dead-from-the-UI like the health endpoints it
        // complements.
        let api = app_file("js/api.js");
        assert!(
            api.contains("/api/v1/capabilities/probe"),
            "SPA must call /api/v1/capabilities/probe (Engines live capability probe)"
        );
        let engines = app_file("js/views/engines.js");
        assert!(
            engines.contains("renderCapabilityProbePanel(") && engines.contains("runCapabilityProbe"),
            "the Engines page must render the capability-probe panel and its run action"
        );
    }

    #[test]
    fn embedded_spa_wires_the_per_scan_analysis_endpoints() {
        // Per-scan endpoints that were implemented + routed but the SPA never
        // surfaced. Each is now a section in the scan report; guard the wiring so
        // they cannot silently become dead-from-the-UI again.
        let api = app_file("js/api.js");
        for path in ["/benchmark", "/identities", "/location"] {
            assert!(
                api.contains(path),
                "SPA report must fetch the {path} per-scan endpoint"
            );
        }
        // The render sections must be composed into a scan surface so these
        // endpoints stay live-from-the-UI. Post-streamline the Summary
        // (report.js) headlines Location (the "where is the subject" residency
        // finding); Identities and Benchmark are lenses under the lazy Insights
        // tab (insights.js). Guard both homes.
        let summary = app_file("js/scan_info/report.js");
        let insights = app_file("js/scan_info/insights.js");
        assert!(
            summary.contains("renderLocation("),
            "the Summary must compose renderLocation() (the residency headline)"
        );
        assert!(
            insights.contains("renderIdentities("),
            "the Insights tab must compose renderIdentities()"
        );
        assert!(
            insights.contains("renderBenchmark("),
            "the Insights tab must compose renderBenchmark()"
        );
    }

    #[test]
    fn embedded_spa_surfaces_the_exposure_index() {
        // `core::exposure::assess` headlines the CLI dossier and the debug
        // bundle, but had no API consumer at all — so the web console (the only
        // interface on a Termux/Android device without a second terminal) never
        // showed the calibrated 0–100 verdict that summarises the whole scan.
        // Guard both ends of the wire so it cannot go dead again.
        let api = app_file("js/api.js");
        assert!(
            api.contains("/exposure"),
            "SPA must fetch the per-scan /exposure endpoint"
        );
        let info = app_file("js/scan_info/info.js");
        assert!(
            info.contains("API.exposure("),
            "the Info tab must call API.exposure()"
        );
        // The panel markup and per-component rendering moved to
        // wasm-ui/src/scan_info/info.rs's render_exposure_html — a
        // sibling-crate source read, same pattern as the leads.js/
        // correlations.js ports' own fitness-test updates.
        let info_rs = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/wasm-ui/src/scan_info/info.rs"
        ))
        .expect("info.rs source readable");
        assert!(
            info_rs.contains("Exposure Index"),
            "the Exposure Index panel must be rendered"
        );
        // Every component field the backend serialises must be consumed — a
        // breakdown that drops `detail` or `max` reduces the transparent
        // per-signal explanation to a bare number.
        for field in ["c.name", "c.score", "c.max", "c.detail"] {
            assert!(
                info_rs.contains(field),
                "the Exposure breakdown must render {field} in wasm-ui/src/scan_info/info.rs"
            );
        }
    }

    #[test]
    fn embedded_spa_wires_the_autonomous_plan_and_sweep_endpoints() {
        // The autonomous loop's read-only queue preview (/scan/auto/plan) and the
        // multi-target sweep (/scan/auto/sweep) are routed + tested server-side but
        // were dead-from-the-UI: the API methods existed yet no control invoked
        // them. Both are now wired into the New-Scan "Autonomous investigation"
        // panel; guard that the call sites stay present.
        let api = app_file("js/api.js");
        for path in ["/scan/auto/plan", "/scan/auto/sweep"] {
            assert!(
                api.contains(path),
                "SPA must fetch the {path} autonomous endpoint"
            );
        }
        // The handlers must be invoked from real UI controls, not merely defined.
        let new_scan = app_file("js/views/new_scan.js");
        assert!(
            new_scan.contains("autoQueuePreview(") && new_scan.contains("autoSweepGo("),
            "SPA must wire the queue-preview + auto-sweep controls"
        );
        assert!(
            new_scan.contains("API.autoPlan(") && new_scan.contains("API.autoSweep("),
            "the controls must call the autoPlan/autoSweep API methods"
        );
    }

    #[test]
    fn embedded_spa_styles_every_entity_kind() {
        // Rendering contract: every `EntityKind` a module can produce must have a
        // distinct `.k-<snake_case>` pill style, or it renders as an
        // undifferentiated default pill in Browse / the graph. The list is the
        // serde snake_case tags of `core::entity::EntityKind`; a drift count
        // against the enum keeps it honest when a kind is added.
        const KIND_STYLES: &[&str] = &[
            "abn_acn",
            "address",
            "api_key",
            "asn",
            "cidr",
            "coordinates",
            "credential",
            "crypto_address",
            "device_id",
            "domain",
            "email",
            "ip_address",
            "mac_address",
            "organisation",
            "other",
            "password",
            "person",
            "phone",
            "ssid",
            "tracking_id",
            "url",
            "username",
        ];
        // The Browse/report pill surface — a `.k-<kind>` CSS rule.
        let css = app_file("css/app.css");
        for k in KIND_STYLES {
            assert!(
                css.contains(&format!(".k-{k}{{")),
                "SPA has no `.k-{k}` pill style — EntityKind `{k}` renders as a \
                 default/undifferentiated pill; add a colour"
            );
        }
        // The graph surface — a NODE_COLOR entry. A kind missing here renders as
        // the undifferentiated '#888' grey node, indistinguishable from `other`.
        let node_colors = app_file("js/scan_info/graph.js")
            .split_once("const NODE_COLOR = {")
            .and_then(|(_, b)| b.split_once("};"))
            .map(|(b, _)| b)
            .expect("NODE_COLOR map present in graph.js");
        for k in KIND_STYLES {
            assert!(
                node_colors.contains(&format!("{k}:")),
                "EntityKind `{k}` has no NODE_COLOR entry — it renders as a grey \
                 default node in the graph; add a colour matching its pill"
            );
        }
        // Drift guard: pin to the real enum (every variant is a bare unit ident
        // except the `Other(String)` tuple, so count both forms). `EntityKind`
        // lives in the sibling `hse-core` crate (extracted so the entity model
        // can be shared with a wasm32 web-UI build) — a directory next to
        // `src/`, not inside it, hence the path below is not under `src/`.
        let src = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/hse-core/src/lib.rs"
        ))
        .expect("entity source readable");
        let body = src
            .split_once("pub enum EntityKind {")
            .and_then(|(_, b)| b.split_once("\n}"))
            .map(|(b, _)| b)
            .expect("EntityKind enum present");
        let variant_count = body
            .lines()
            .filter(|l| {
                let t = l.trim_start();
                // 4-space-indented PascalCase ident, ending `,` or `(…` — not a
                // doc line (`///`) or attribute (`#`).
                l.starts_with("    ")
                    && !l.starts_with("        ")
                    && t.chars().next().is_some_and(|c| c.is_ascii_uppercase())
            })
            .count();
        assert_eq!(
            variant_count,
            KIND_STYLES.len(),
            "core::entity::EntityKind has {variant_count} variants but the SPA \
             pill-style list pins {} — add the new kind's `.k-<snake_case>` style",
            KIND_STYLES.len()
        );
    }

    #[test]
    fn embedded_spa_graph_ships_no_vendored_engine_and_runs_no_simulation() {
        // The graph was drawn by a vendored D3 v3 force layout. Two things made
        // that the wrong trade for this crate's target (Termux/Android aarch64,
        // no root, RAM shared with the OS): the 151 KB payload rode along in a
        // single-binary artefact, and the force simulation ticked continuously
        // over hundreds of nodes — mutating every `<line>` and `<g>` transform
        // per frame — on the same device that was running the scan producing
        // those nodes.
        //
        // It is now a deterministic flow chart (one row per expansion
        // generation) computed once in O(nodes), drawn against the DOM
        // directly. These asserts pin that the dependency does not creep back
        // and that no per-frame loop returns.
        let graph = app_file("js/scan_info/graph.js");
        assert!(
            !graph.contains("d3."),
            "graph.js must not call into D3 — the graph is drawn directly \
             against the DOM so no rendering engine ships in the binary"
        );
        for banned in ["force(", "on('tick'", "requestAnimationFrame("] {
            assert!(
                !graph.contains(banned),
                "graph.js must not run a per-frame simulation loop ({banned}) — \
                 layout is computed once, then the chart is static until the \
                 operator interacts with it"
            );
        }
        // Endpoints still resolve to shared node objects: the draw loop reads
        // every position off one object per node rather than re-looking up ids.
        let build = graph
            .split_once("function buildGraph(")
            .map(|(_, b)| b)
            .expect("buildGraph() present in graph.js");
        assert!(
            build.contains("nodesById.get(l.source)") && build.contains("nodesById.get(l.target)"),
            "link source/target must resolve to node objects via nodesById \
             once, rather than re-looking up ids in the draw loop"
        );
        // The vendored asset itself must be gone from the served set.
        assert!(
            !SPA_HTML.contains("d3.min.js"),
            "spa.html must not load a vendored d3.min.js"
        );
        assert!(
            !VENDOR_FILES.iter().any(|(n, _, _)| n.contains("d3")),
            "d3 must not be embedded in VENDOR_FILES"
        );
    }

    #[test]
    fn embedded_spa_graph_is_bounded_and_never_builds_correlation_cliques() {
        // buildGraph historically drew a *clique* per correlation cluster:
        //   for (let i=0;i<uids.length;i++) for (let j=i+1;j<uids.length;j++)
        //     links.push({source:uids[i], target:uids[j], corr:true});
        // That is O(k²) in the cluster size. Real scans routinely produce
        // correlation clusters spanning 600+ members (a single 607-member
        // cluster is 183_921 edges); one observed scan — 1089 entities, several
        // 607-member clusters — expanded to ~15.27M `<line>` elements, which
        // hangs or crashes the browser tab and renders an unreadable hairball.
        // The fix caps the rendered node/edge counts and represents each
        // correlation as a bounded *star* (O(k)), not a clique. These asserts
        // pin that so the O(k²) construct cannot silently return.
        let graph = app_file("js/scan_info/graph.js");
        for c in ["GRAPH_MAX_NODES", "GRAPH_MAX_LINKS", "CORR_MAX_SPOKES"] {
            assert!(
                graph.contains(c),
                "graph.js must define the rendering ceiling `{c}` — without it a \
                 large scan builds millions of SVG edges and crashes the tab"
            );
        }
        // The exact clique double-loop over correlation member UIDs must be gone.
        assert!(
            !graph.contains("for (let j=i+1;j<uids.length;j++)"),
            "graph.js still contains the O(k²) correlation-clique double-loop — a \
             600+-member cluster expands to >180k edges; represent correlations \
             as a bounded star (CORR_MAX_SPOKES) instead"
        );
        let build = graph
            .split_once("function buildGraph(")
            .map(|(_, b)| b)
            .expect("buildGraph() present in graph.js");
        assert!(
            build.contains(".slice(0, GRAPH_MAX_NODES)"),
            "buildGraph must cap rendered entity nodes via \
             .slice(0, GRAPH_MAX_NODES)"
        );
        assert!(
            build.contains("CORR_MAX_SPOKES") && build.contains("GRAPH_MAX_LINKS"),
            "buildGraph must bound correlation fan-out (CORR_MAX_SPOKES) and \
             the total edge count (GRAPH_MAX_LINKS)"
        );
        // The summary notice element that tells the operator the view is capped
        // (and where the complete graph lives) must exist and be populated.
        assert!(
            graph.contains("id=\"graph-cap\"") && graph.contains("#graph-cap"),
            "graph.js must render and populate the #graph-cap notice so a capped \
             graph points the operator to Browse / Relations / GEXF"
        );
    }

    #[test]
    fn embedded_spa_deep_links_resolve_to_a_visible_section() {
        // The Location "no leads yet" hint links to `#/scaninfo?...&tab=network`,
        // and the Summary's correlation-count callout navigates to `&tab=corr`.
        // Post streamline, Correlations is its own tab (the tab=corr jump
        // resolves straight to it) and the network section lives on the
        // Summary (the &tab=network link folds onto Summary and scrolls to
        // #sum-network). Guard both the anchor/nav and the dispatch so a link
        // can never go inert again.
        // The anchor itself now lives in wasm-ui/src/scan_info/leads.rs (the
        // empty-state's HTML templating moved to WASM; leads.js's own text no
        // longer contains it) — a sibling-crate source read, same pattern as
        // the `EntityKind` drift guard below.
        let leads_rs = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/wasm-ui/src/scan_info/leads.rs"
        ))
        .expect("leads.rs source readable");
        assert!(
            // Raw string: the .rs file's own text escapes this quote as `\"`
            // (it's inside a Rust string literal), so the search pattern must
            // match that literal backslash rather than a bare `"`.
            leads_rs.contains(r#"tab=network\">Network</a>"#),
            "expected deep-link anchor text `tab=network\">Network</a>` in \
             wasm-ui/src/scan_info/leads.rs"
        );
        // report.js navigates programmatically (`nav(...)`) rather than
        // rendering an `<a>` — the Summary's correlation-count callout is a
        // clickable stat card, not inline prose, so it wires a click handler
        // instead of an anchor. status.js used to carry the equivalent
        // `<a ...&tab=corr">Correlations</a>` prose link, but it had zero
        // importers (dead since the tab streamline) and was removed; this is
        // the live mechanism that actually reaches the Correlations tab today.
        assert!(
            app_file("js/scan_info/report.js").contains("&tab=corr`"),
            "expected a tab=corr navigation in report.js's live correlation callout"
        );
        let dispatch = app_file("js/scan_info/index.js")
            .split_once("const body = $('#scan-body');")
            .and_then(|(_, b)| b.split_once("\n\n"))
            .map(|(b, _)| b)
            .expect("renderScanInfo's tab dispatch block present");
        assert!(
            dispatch.contains("activeTab==='corr'") && dispatch.contains("renderCorrelations("),
            "tab=corr must render the Correlations tab (renderCorrelations)"
        );
        assert!(
            dispatch.contains("tab==='network'") && dispatch.contains("$('#sum-network')"),
            "tab=network must fold onto the Summary and scroll to #sum-network"
        );
    }

    #[test]
    fn embedded_spa_scan_detail_is_streamlined() {
        // The scan-detail view was streamlined (SpiderFoot-style) from a single
        // ~90-screen "Report" scroll (~15 sections, ~17 API calls on open) into a
        // slim Summary + a lazy Insights drawer + a dedicated Correlations tab.
        // Pin the shape so it cannot regress into the kitchen-sink scroll.
        let index = app_file("js/scan_info/index.js");
        for t in [
            "subTab('summary'",
            "subTab('browse'",
            "subTab('graph'",
            "subTab('corr'",
            "subTab('insights'",
        ] {
            assert!(index.contains(t), "scan-detail tab bar must include {t}");
        }
        // The Summary leads with the calibrated Exposure Index (the headline the
        // CLI dossier opens with) — which was previously dead-from-the-UI.
        let summary = app_file("js/scan_info/report.js");
        assert!(
            summary.contains("renderExposure("),
            "the Summary must headline the Exposure Index"
        );
        // Insights is a lazy lens switcher — it renders one lens on demand, not
        // all ~10 analytical sections (and their fetches) at once.
        let insights = app_file("js/scan_info/insights.js");
        assert!(
            insights.contains("data-lens") && insights.contains("insights-lens"),
            "Insights must be a lazy per-lens switcher"
        );
        // Correlation member rows are built lazily on expand — a 607-member
        // cluster must not put tens of thousands of hidden DOM nodes on the page
        // up front (the same unbounded-render class as the graph clique bug).
        // The lazy-build orchestration (dataset.built) stays in correlations.js;
        // the card markup carrying data-corr-idx moved to
        // wasm-ui/src/scan_info/correlations.rs's render_corr_card_html.
        let corr = app_file("js/scan_info/correlations.js");
        assert!(
            corr.contains("dataset.built"),
            "correlation members must be built lazily on card expand, not up front"
        );
        let corr_rs = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/wasm-ui/src/scan_info/correlations.rs"
        ))
        .expect("correlations.rs source readable");
        assert!(
            corr_rs.contains("data-corr-idx"),
            "expected data-corr-idx in wasm-ui/src/scan_info/correlations.rs's card markup"
        );
    }

    #[test]
    fn embedded_spa_renders_every_event_kind() {
        // Event contract: every `EventKind` variant the engine/live loop emits
        // over the bus must have a friendly `mapEvent` case in the SPA, or it
        // renders as a raw-JSON blob in the live log / Live-activity panel. The
        // snake_case names below are the serde `type` tags of `core::event::
        // EventKind` — keep in sync when a variant is added (the same pin-the-list
        // discipline as the architecture guards). The `live_*` trio is the case
        // that was actually rendering raw before this guard existed.
        const EVENT_TYPES: &[&str] = &[
            "module_start",
            "module_done",
            "module_error",
            "module_skipped",
            "entity_found",
            "scan_start",
            "scan_complete",
            "expansion_tick",
            "expansion_stop",
            "entity_excluded",
            "dispatch_utility_computed",
            "breach_sweep",
            "consensus_audit",
            "correlation_found",
            "correlations_done",
            "live_start",
            "live_tick",
            "live_stop",
        ];
        let log_js = app_file("js/scan_info/log.js");
        for ty in EVENT_TYPES {
            assert!(
                log_js.contains(&format!("t==='{ty}'")),
                "SPA mapEvent has no case for EventKind `{ty}` — it would render \
                 as raw JSON in the live log; add a friendly row"
            );
        }
        // Drift guard: pin the list to the real enum so a NEW EventKind variant
        // can't be added without giving it a mapEvent case. Every variant carries
        // fields (`Variant {`), so count 4-space-indented PascalCase openings.
        let src =
            std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/src/core/event/mod.rs"))
                .expect("event source readable");
        let body = src
            .split_once("pub enum EventKind {")
            .and_then(|(_, b)| b.split_once("\n}"))
            .map(|(b, _)| b)
            .expect("EventKind enum present");
        let variant_count = body
            .lines()
            .filter(|l| {
                let t = l.trim_start();
                l.starts_with("    ")
                    && !l.starts_with("        ")
                    && t.chars().next().is_some_and(|c| c.is_ascii_uppercase())
                    && t.trim_end().ends_with('{')
            })
            .count();
        assert_eq!(
            variant_count,
            EVENT_TYPES.len(),
            "core::event::EventKind has {variant_count} variants but the SPA \
             event-contract list pins {} — add the new variant's snake_case type \
             here (and a mapEvent case in spa.html)",
            EVENT_TYPES.len()
        );
    }

    #[test]
    fn embedded_spa_fetches_relations_only_for_the_graph_tab() {
        // renderScanInfo fetched entities, correlations AND relations on every
        // render — all 7 tabs, plus this page's own 8s live-refresh while a
        // scan runs — but S.relations has exactly one consumer: graph.js.
        // Every other tab paid for a full relations round-trip it never used,
        // repeated roughly 450 times an hour by a Summary/Browse tab left open
        // during a scan. Guard the elision so the fetch can't silently
        // become unconditional again.
        let index = app_file("js/scan_info/index.js");
        assert!(
            index.contains("const wantRelations = activeTab === 'graph';"),
            "renderScanInfo must gate the relations fetch on the active tab"
        );
        assert!(
            index.contains("wantRelations ? API.relations(id) : Promise.resolve({ relations: [] })"),
            "the relations fetch must be skipped (not fetched-and-discarded) \
             on every tab but graph — Promise.resolve avoids the network \
             round-trip entirely"
        );
        // entities/correlations remain UNCONDITIONAL: browse, correlations,
        // graph and the header stat cards all read them regardless of tab.
        assert!(
            index.contains("API.scan(id),") && index.contains("API.entities(id),") && index.contains(
                "API.correlations(id),"
            ),
            "entities and correlations must stay unconditional — only \
             relations is graph-exclusive"
        );
    }

    #[test]
    fn embedded_spa_graph_is_a_flowchart_not_a_node_graph() {
        // The maintainer's explicit direction: remove the node-link graph
        // (concentric rings of circles, free-form drag) and replace it with a
        // basic 2D flow chart — rows of boxes by expansion generation, with
        // arrows showing which entity's discovery led to which. Pin the shape
        // so a future change can't quietly drift back to a graph-visualisation
        // idiom.
        let graph = app_file("js/scan_info/graph.js");
        assert!(
            graph.contains("function layoutFlowchart("),
            "graph.js must lay entities out by expansion generation (row),              not a concentric/ring layout"
        );
        assert!(
            !graph.contains("function layoutConcentric("),
            "the ring layout this replaced must not still be present"
        );
        // Rows come from the entity's own `generation` field (how many pivots
        // from the seed it was first found at) — the literal structure of a
        // scan, not an arbitrary rank-derived ring.
        assert!(
            graph.contains("gen: e.generation ?? 0"),
            "each node's row must be derived from the entity's own generation"
        );
        // Node dragging must be fully gone: a flow chart's box positions ARE
        // the structure (row = generation, rank = significance), so letting
        // an operator drag one out of place would misrepresent it. This also
        // means no per-node pointerdown listener and no drag state remain.
        for gone in ["dragNode", "moveNode", "cursor: 'grab'", "n.el.addEventListener('pointerdown'"] {
            assert!(
                !graph.contains(gone),
                "graph.js must not retain node-drag machinery ({gone}) — a                  flow chart's layout is structural, not rearrangeable"
            );
        }
        // "Re-layout" is gone: it re-ran the same deterministic function over
        // unchanged input, so it was already a no-op click before this
        // rewrite (the ring layout it used to trigger was equally pure
        // arithmetic over an already-sorted list, with no randomness to
        // reshuffle) and remains one now. A control with no observable effect
        // must not ship.
        // Checked as the concrete DOM id / wiring, not the bare word
        // "Re-layout" — that also appears in this file's own explanatory
        // comment above, which legitimately names the removed feature.
        assert!(
            !graph.contains("id=\"g-relayout\"") && !graph.contains("$('#g-relayout')"),
            "the Re-layout control (button + click handler) must be removed \
             — it has never had an observable effect on a deterministic layout"
        );
        // The seed-anchor fallback edge must be CONDITIONAL — only for nodes
        // with no other relation/correlation edge — not unconditional for
        // every entity as the prior graph drew it (redundant on top of the
        // relation/correlation edges the same node already had).
        let build = graph
            .split_once("export function buildGraph()")
            .map(|(_, b)| b)
            .expect("buildGraph() present in graph.js");
        assert!(
            build.contains("if (touched.has(e.uid)) continue;"),
            "the seed fallback edge must be skipped for entities that already              have a more specific relation/correlation edge: {build}"
        );
        // `derived_from` — the literal expansion-lineage relation — must be
        // the chart's directional arrow (the other typed relations stay
        // undirected lines, matching their more associative semantics).
        assert!(
            graph.contains("lineage: r.kind === 'derived_from'")
                && graph.contains("marker-end")
                && graph.contains("'flow-arrow'"),
            "derived_from relations must render as directional arrows — the              flow chart's primary lineage signal"
        );
    }

    #[test]
    fn embedded_spa_graph_keeps_the_operators_viewport_across_rebuilds() {
        // While a scan runs, scan-info re-renders every 8s, and that re-runs
        // renderGraph -> buildGraph. The pan/zoom state used to be declared
        // INSIDE buildGraph, so every rebuild snapped the canvas back to
        // origin at scale 1 — for the whole duration of a scan the Graph tab
        // could not usefully be panned or zoomed, which is exactly when it is
        // most worth exploring.
        let graph = app_file("js/scan_info/graph.js");
        let build = graph
            .split_once("export function buildGraph()")
            .map(|(_, b)| b)
            .expect("buildGraph() present in graph.js");
        assert!(
            !build.contains("const view = {"),
            "the pan/zoom state must not be re-created inside buildGraph — \
             that is what discarded the viewport on every 8s refresh"
        );
        let head = graph
            .split_once("export function renderGraph(")
            .map(|(h, _)| h)
            .expect("renderGraph() present in graph.js");
        assert!(
            head.contains("const view = { x: 0, y: 0, k: 1 };") && head.contains("function resetView()"),
            "graph.js must hold pan/zoom at module scope so a rebuild re-applies it"
        );
        // Retained state must still be scoped to ONE scan: opening a different
        // scan should start centred, not inherit the previous scan's viewport.
        let render = graph
            .split_once("export function renderGraph(")
            .and_then(|(_, b)| b.split_once("\n}"))
            .map(|(b, _)| b)
            .expect("renderGraph() body present");
        assert!(
            render.contains("viewScanId") && render.contains("resetView()"),
            "renderGraph must reset the viewport when the mounted scan changes: {render}"
        );
        // And "Reset view" must still work — it is now the only thing that
        // recentres, so losing it would leave a zoomed-in operator stuck.
        assert!(
            graph.contains("window.__graphResetZoom = ()=>{ resetView(); applyView(); }"),
            "the Reset view control must recentre through the shared resetView"
        );
    }

    #[test]
    fn embedded_spa_pauses_every_background_poller() {
        // Six views poll on a timer, and each tick is a real cost on the one
        // platform this ships to: scan-info re-pulls the scan plus its FULL
        // entity, correlation and relation sets every 8s and rebuilds the view
        // (on the Graph tab, the whole layout); the Live monitor re-pulls the
        // session list every 8s; the Engines page triggers a multi-engine
        // server-side liveness sweep every 30s; Settings polls a self-update's
        // phase and a cell-DB import's phase every 2.5s each, plus the
        // post-update restart overlay's health probe, also every 2.5s. A
        // no-root Termux device runs `hse serve` and the browser SIDE BY SIDE,
        // so a tab left in the background was making the phone do all of
        // that, for nothing, for as long as the job/scan lasted.
        //
        // Each poller must consult the shared `pageHidden` helper. Single
        // source so none of the six can drift, and so the reasoning lives once.
        let timers = app_file("js/timers.js");
        assert!(
            timers.contains("export function pageHidden()") && timers.contains("document.hidden"),
            "timers.js must export the shared page-visibility predicate"
        );
        for (file, view) in [
            ("js/scan_info/index.js", "scan-info auto-refresh"),
            ("js/views/live.js", "Live monitor session poll"),
            ("js/views/engines.js", "Engines liveness sweep"),
            ("js/views/opts.js", "Settings update/cells/restart pollers"),
        ] {
            let src = app_file(file);
            assert!(
                src.contains("pageHidden"),
                "the {view} ({file}) must skip its poll while the page is \
                 hidden — a backgrounded tab kept doing the work every tick"
            );
            assert!(
                src.contains("from '/static/js/timers.js'") && src.contains("pageHidden }"),
                "{file} must import pageHidden from the shared timers module \
                 rather than re-implementing the visibility check"
            );
        }
        // opts.js carries THREE independent setInterval pollers (update
        // status, cell-DB import status, restart-overlay health probe) — every
        // one of them, not just one, must gate on pageHidden.
        let opts = app_file("js/views/opts.js");
        let poller_count = opts.matches("setInterval(").count();
        let guard_count = opts.matches("if (pageHidden()) return;").count();
        assert_eq!(
            poller_count, 3,
            "opts.js poller count changed — update this guard alongside it \
             instead of letting a new poller go unaudited: {poller_count} \
             setInterval site(s) found"
        );
        assert_eq!(
            guard_count, poller_count,
            "every setInterval in opts.js must open with the pageHidden \
             guard — found {guard_count} guard(s) for {poller_count} poller(s)"
        );
        // The scan-info refresh must RE-ARM while hidden rather than tear its
        // schedule down: dropping the timer would leave the view frozen after
        // the operator switched away and back, with nothing to restart it (the
        // alternative — a visibilitychange listener — would be registered on
        // every one of the many renders this path performs, and leak).
        let idx = app_file("js/scan_info/index.js");
        let tick = idx
            .split_once("function scanRefreshTick()")
            .and_then(|(_, b)| b.split_once("\n}"))
            .map(|(b, _)| b)
            .expect("scanRefreshTick() present in scan_info/index.js");
        assert!(
            tick.contains("pageHidden()") && tick.contains("setTimeout(scanRefreshTick"),
            "the hidden branch must re-arm the tick, so the refresh resumes \
             within one interval of the tab becoming visible again: {tick}"
        );
        assert!(
            !idx.contains("addEventListener('visibilitychange'"),
            "no per-render visibilitychange listener — scan-info re-renders \
             every 8s and would accumulate one listener per render"
        );
    }

    #[test]
    fn embedded_spa_bounds_the_event_log_dom_and_discloses_the_drop() {
        // The scan log appended one permanent DOM node per event and removed
        // nothing. Captured runs already reach 598 events, this file's sibling
        // note records a 764-row log, and DEFAULT_SCAN_DEPTH went 3 -> 5 — so a
        // deep scan's log grows several times further, under a live SSE stream,
        // on a no-root Termux/Android browser. Unbounded growth there is how the
        // tab dies mid-scan. Guard both halves of the fix: the bound exists, and
        // it is disclosed rather than silently truncating.
        let log_js = app_file("js/scan_info/log.js");
        assert!(
            log_js.contains("const LOG_MAX_ROWS"),
            "log.js must define a rendered-row ceiling — without it the event \
             log grows without bound for the life of the view"
        );
        assert!(
            log_js.contains("box.childElementCount > LOG_MAX_ROWS")
                && log_js.contains("box.removeChild(box.firstElementChild)"),
            "log.js must actually evict oldest-first once over the cap; \
             defining the constant without enforcing it is worse than neither"
        );
        // Eviction must be synchronous with the append. Deferring it to the
        // rAF flush would still let the whole unbounded list exist for a frame
        // during the synchronous history render — and the peak is what OOMs.
        let append = log_js
            .split_once("export function appendLog(")
            .and_then(|(_, b)| b.split_once("\n}"))
            .map(|(b, _)| b)
            .expect("appendLog() present in log.js");
        assert!(
            append.contains("LOG_MAX_ROWS"),
            "the cap must be enforced inside appendLog, not deferred to the \
             coalesced flush: {append}"
        );
        // Silent truncation is the failure mode this must not have. The
        // per-type breakdown counts events (not rows), so it stays complete;
        // the dropped rows are disclosed on screen and in the saved file.
        assert!(
            log_js.contains("logRowsDropped"),
            "log.js must track how many rows it evicted so the drop can be \
             disclosed"
        );
        assert!(
            log_js.contains("dropped from view (Download has all)"),
            "the on-screen breakdown must disclose evicted rows and point at \
             the complete server-side log"
        );
        assert!(
            log_js.contains("this file starts mid-scan"),
            "the 'Save shown' header must warn when the saved capture begins \
             mid-scan because of the display cap"
        );
        // bumpTypeCount must run before any eviction, or the breakdown would
        // undercount and the totals would become as lossy as the rows.
        let bump = append.find("bumpTypeCount").expect("appendLog counts types");
        let evict = append.find("LOG_MAX_ROWS").expect("appendLog enforces cap");
        assert!(
            bump < evict,
            "events must be tallied before rows are evicted, so the 'By type' \
             totals keep describing the whole scan"
        );
    }

    #[test]
    fn embedded_spa_tails_the_live_session_event_stream() {
        // The per-session live SSE endpoint (/live/{id}/events) streams a running
        // session's lifecycle + every per-iteration scan's events. It had no SPA
        // consumer — the Live Monitor only polled the session list every 8s. The
        // "Live activity" panel now opens an EventSource against it; guard the
        // wiring so the stream can't silently revert to dead-from-the-UI.
        let log_js = app_file("js/scan_info/log.js");
        let live_js = app_file("js/views/live.js");
        assert!(
            log_js.contains("/live/'+encodeURIComponent(liveId)+'/events"),
            "SPA must open an EventSource against /live/{{id}}/events"
        );
        assert!(
            log_js.contains("openLiveSse(") && live_js.contains("openLiveStream("),
            "SPA must define the live-session stream tail (openLiveSse/openLiveStream)"
        );
        // The tail must be invoked from a real per-session control.
        assert!(
            live_js.contains("data-livestream") && live_js.contains("wireLiveStreams("),
            "each Active-sessions row must carry a Stream control wired to the tail"
        );
    }

    #[test]
    fn external_resource_scanner_flags_a_cdn_but_not_a_local_or_anchor() {
        // Guard the guard: the scanner must catch a real external resource load,
        // ignore same-origin ones, and ignore navigational <a> links.
        let sample = r#"
            <link rel="stylesheet" href="https://cdn.example/x.css">
            <script src="/static/app.js"></script>
            <link rel="icon" href="data:image/svg+xml,<svg/>">
            <a href="https://github.com/example">repo</a>
            <img src="//cdn.example/pixel.gif">
        "#;
        let hits = external_resource_refs(sample);
        assert_eq!(
            hits.len(),
            2,
            "exactly the CDN css + protocol-relative img: {hits:?}"
        );
        assert!(hits.iter().any(|h| h.contains("cdn.example/x.css")));
        assert!(hits.iter().any(|h| h.contains("//cdn.example/pixel.gif")));
        assert!(
            !hits.iter().any(|h| h.contains("github.com")),
            "<a> is not a resource"
        );
        assert!(
            !hits.iter().any(|h| h.contains("/static/")),
            "same-origin is fine"
        );
    }

    #[test]
    fn spa_scan_preset_modules_are_all_registered() {
        // The New-Scan use-case presets (Footprint / Investigate / …) select their
        // module set by name from a hard-coded `pick:m=>['a','b',…].includes(m.name)`
        // list in the SPA. A renamed or removed module silently drops out of the
        // preset — the name simply stops matching — quietly shrinking coverage in
        // the web UI with no error anywhere. Pin every preset name to the live
        // registry so a module rename/removal can't rot a preset unnoticed: the
        // same no-silent-drift guard the README / MODULES.md counts already carry.
        let registered: std::collections::BTreeSet<&str> =
            crate::modules::registry().iter().map(|m| m.name()).collect();

        let state_js = app_file("js/state.js");
        let mut checked = 0usize;
        let mut idx = 0;
        while let Some(rel) = state_js[idx..].find("pick:m=>[") {
            let start = idx + rel + "pick:m=>[".len();
            let end = state_js[start..]
                .find(']')
                .map_or(state_js.len(), |e| start + e);
            for raw in state_js[start..end].split(',') {
                let name = raw.trim().trim_matches(['\'', '"']);
                if name.is_empty() {
                    continue;
                }
                assert!(
                    registered.contains(name),
                    "New-Scan preset references unknown module `{name}` — update \
                     src/web/spa.html after a module rename/removal"
                );
                checked += 1;
            }
            idx = end;
        }
        // Sanity floor: the literal-list presets (Footprint + Investigate) name
        // ~20 modules between them, so a refactor that drops the `pick:m=>[…]`
        // syntax can't quietly make this guard vacuous.
        assert!(
            checked >= 20,
            "expected the SPA scan presets to name many modules, saw {checked}"
        );
    }

    #[test]
    fn every_embedded_asset_etag_is_the_hash_of_its_bytes() {
        // The tag must be derived from the bytes actually served — not the
        // crate version, which does not change across in-place upgrades from
        // `main` — so a browser revalidating after an upgrade gets new bytes
        // exactly when the bytes changed.
        use sha2::{Digest, Sha256};
        let mut tags = Vec::new();
        for (name, _, bytes) in VENDOR_FILES.iter().chain(APP_FILES.iter()) {
            let tag = asset_etag(name).unwrap_or_else(|| panic!("{name} has no ETag"));
            let expected = format!("\"{}\"", hex::encode(&Sha256::digest(bytes)[..8]));
            assert_eq!(tag.text, expected, "{name}");
            assert_eq!(tag.header.to_str().expect("ascii"), expected, "{name}");
            tags.push(tag.text);
        }
        assert!(tags.len() >= 2, "expected several embedded assets");
        tags.sort_unstable();
        tags.dedup();
        assert!(tags.len() >= 2, "distinct assets must carry distinct tags");
        assert!(!tags.contains(&concat!("\"", env!("CARGO_PKG_VERSION"), "\"")));
        assert!(asset_etag("no/such/asset.js").is_none());
    }

    #[test]
    fn endpoint_surface_doc_table_lists_every_registered_route() {
        // The module's `//!` "Endpoint surface" table at the top of this file
        // claims to enumerate the whole route set — it is the first thing a
        // reader consults to learn the API. Every `.route("<path>", …)` the
        // router body registers must therefore appear in that table, or a new
        // endpoint silently drifts out of the self-documenting surface. That had
        // already happened three times (`/favicon.ico`, `/manifest.webmanifest`
        // and `/scans/{id}/batch.txt` were each registered with no doc row)
        // before this guard existed; without it, the next one is invisible too.
        //
        // Matched EXACTLY (not by substring): the router nests every versioned
        // route under `/api/v1` (`.nest("/api", api)` over `.nest("/v1",
        // api_v1)` — the only two nests in the file) and registers a handful of
        // assets at the top level, so a registered literal `L` is documented iff
        // the table carries its full external path verbatim — `/api/v1{L}` for a
        // versioned route or `{L}` for a top-level one. A looser `contains` (or
        // even `ends_with`) check would let a missing row slip through whenever
        // the path is a trailing segment of another — a dropped `/api/v1/health`
        // row would still look "covered" by `/api/v1/engines/health`. Reads the
        // real on-disk source (same idiom as the EntityKind/EventKind drift
        // guards above) so it tracks the file as edited, not a stale snapshot.
        let src = std::fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/src/api/routes/mod.rs"
        ))
        .expect("router source readable");

        // The doc-table path cells: the first backtick-quoted token on each
        // `//!` row (the path column). Handler-column annotations like `(v1.5+)`
        // and the `(unmatched)`/`(fallback)` notes sit outside these backticks.
        let mut doc_paths = std::collections::BTreeSet::new();
        for line in src.lines() {
            let t = line.trim_start();
            if !t.starts_with("//!") {
                continue;
            }
            let Some(a) = t.find('`') else { continue };
            let Some(rel) = t[a + 1..].find('`') else {
                continue;
            };
            let cell = &t[a + 1..a + 1 + rel];
            if cell.starts_with('/') {
                doc_paths.insert(cell.to_string());
            }
        }

        let mut missing = Vec::new();
        let mut count = 0usize;
        let mut rest = src.as_str();
        while let Some(p) = rest.find(".route(\"") {
            let after = &rest[p + ".route(\"".len()..];
            let end = after.find('"').expect("a .route( path literal is closed");
            let lit = &after[..end];
            count += 1;
            let nested = format!("/api/v1{lit}");
            if !doc_paths.contains(lit) && !doc_paths.contains(&nested) {
                missing.push(lit.to_string());
            }
            rest = &after[end..];
        }

        // Sanity floors: if either extractor silently stopped matching, an empty
        // `missing` set would be a false pass. The router registers dozens of
        // routes and the table enumerates at least as many rows.
        assert!(
            count >= 60,
            "expected many `.route()` registrations, found {count} — the \
             route extractor likely broke rather than the routes vanishing"
        );
        assert!(
            doc_paths.len() >= 60,
            "expected the doc table to enumerate many routes, found {} rows — \
             the doc-cell extractor likely broke",
            doc_paths.len()
        );
        assert!(
            missing.is_empty(),
            "these registered routes have no exact row in the `//!` \"Endpoint \
             surface\" doc table — add one so the self-documenting API surface \
             cannot drift from the code: {missing:?}"
        );
    }
