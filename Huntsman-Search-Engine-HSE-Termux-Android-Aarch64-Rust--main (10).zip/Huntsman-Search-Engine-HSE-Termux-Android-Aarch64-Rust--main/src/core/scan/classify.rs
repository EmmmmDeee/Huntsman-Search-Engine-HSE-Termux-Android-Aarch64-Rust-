//! Domain and identity classification: mega-/infra-domain matching (so a scan
//! doesn't burn rounds mapping a platform's own estate), identity normalisation
//! and overlap (tying an alias back to the subject), and the wrong-identity-pivot
//! gate. Pure matching over strings + the curated INFRA/MEGA domain lists.

/// Dampening factor for domain targets. Mega-domains (top internet
/// properties that appear in nearly every search result) get a 0.15×
/// penalty so they expand after target-specific entities.
///
/// Calibrated from JLM scan: facebook.com (corr=337), reddit.com (111),
/// whitepages.com (83) are noise. Target-specific domains like
/// welcometothejungle.com (corr=262) are valuable but indistinguishable
/// by corroboration alone, so we blocklist by known mega-domain.
/// True if `domain` is — or is a subdomain of — a known mega-domain (a top
/// internet property that shows up in nearly every SERP). Used both to dampen
/// such a domain's expansion weight and (in the engine) to skip expanding one
/// that was only *incidentally* discovered, so a person/profile scan doesn't
/// burn rounds mapping a platform's own DNS/mail infrastructure.
/// Strip a leading `www.` ASCII-case-insensitively without allocating. Safe
/// on any input: the match can only succeed if the first 4 bytes are
/// literally the ASCII characters `w`/`W`, `w`/`W`, `w`/`W`, `.` (a
/// multi-byte UTF-8 continuation byte can never satisfy that comparison), so
/// the returned slice always starts on a real character boundary.
fn strip_www_ci(d: &str) -> &str {
    let b = d.as_bytes();
    if b.len() >= 4 && b[..4].eq_ignore_ascii_case(b"www.") {
        &d[4..]
    } else {
        d
    }
}

/// Registrable-suffix match: `d == m` or `d` ends with `.m` (www-stripped),
/// matched ASCII-case-insensitively against the raw value — zero allocation
/// (every `list` entry — MEGA_DOMAINS, INFRA_PROVIDER_ROOTS, INFRA_HOST_ONLY —
/// is lowercase ASCII, so
/// this is equivalent to the old lowercase-then-compare approach). The
/// suffix comparison runs on byte slices, not `&str`, so it never needs a
/// char-boundary check regardless of where it cuts.
fn matches_domain_suffix(domain: &str, list: &[&str]) -> bool {
    let d = strip_www_ci(domain.trim()).as_bytes();
    list.iter().any(|m| {
        let mb = m.as_bytes();
        d.eq_ignore_ascii_case(mb)
            || (d.len() > mb.len()
                && d[d.len() - mb.len() - 1] == b'.'
                && d[d.len() - mb.len()..].eq_ignore_ascii_case(mb))
    })
}

pub(crate) fn is_mega_domain(domain: &str) -> bool {
    matches_domain_suffix(domain, MEGA_DOMAINS)
}

/// Shared third-party infrastructure (managed DNS, registrar control-plane, CDN
/// apexes, ESP/transactional mail) that surfaces via NS/MX/SOA/reverse lookups
/// but is incidental to any subject — `ns10.dnsmadeeasy.com`,
/// `cns1.secureserver.net`, `u123.sendgrid.net`, `ns-664.awsdns-19.net`, … map
/// the provider's estate, not the target, so they are never worth deep-expanding.
/// ASCII-case-insensitive substring containment. `core` reaches `util` only
/// through the allow-list of pure leaf items in the
/// `core_does_not_import_util_directly` architecture guard, so this doesn't
/// reach for `util::str_util::find_ascii_ci`'s NEON scan —
/// the domain strings here are a handful of bytes, never a scraped body, so a
/// SIMD prefilter would buy nothing a plain scan doesn't already give.
fn contains_ascii_ci(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() {
        return true;
    }
    haystack.len() >= needle.len()
        && (0..=haystack.len() - needle.len())
            .any(|i| haystack[i..i + needle.len()].eq_ignore_ascii_case(needle))
}

pub(crate) fn is_infra_domain(domain: &str) -> bool {
    let d = strip_www_ci(domain.trim());
    // AWS Route 53 nameservers — ns-N.awsdns-NN.{com,net,org,co.uk} — whose root
    // varies with the shard number, so a plain suffix list can't catch them.
    // Both checks are ASCII-case-insensitive, matching the old
    // lowercase-then-`contains`/`starts_with` behaviour, without allocating.
    let db = d.as_bytes();
    if contains_ascii_ci(db, b".awsdns-")
        || (db.len() >= 7 && db[..7].eq_ignore_ascii_case(b"awsdns-"))
    {
        return true;
    }
    // The shared provider roots (one authority with `is_infrastructure_email`)
    // plus the hostname-only estate below.
    matches_domain_suffix(domain, crate::util::domains::INFRA_PROVIDER_ROOTS)
        || matches_domain_suffix(domain, INFRA_HOST_ONLY)
}

/// Either a mega/social platform or shared infrastructure — the haystack a lead
/// sits in, not a lead itself. The engine skips these as incidental (non-seed)
/// expansion targets so a scan doesn't map a provider's whole estate.
pub(crate) fn is_noncentral_domain(domain: &str) -> bool {
    is_mega_domain(domain) || is_infra_domain(domain)
}

/// Identity fingerprint of a name / handle / email-local: lowercase ASCII
/// alphanumerics only (an email's local part is taken before `@`). Used to tie a
/// discovered alias back to the subject without a dictionary name-split.
pub(crate) fn identity_norm(s: &str) -> String {
    let local = crate::core::validation::email_local(s);
    local
        .chars()
        .filter(char::is_ascii_alphanumeric)
        .flat_map(char::to_lowercase)
        .collect()
}

/// Minimum shared-substring length for two identities to be considered the same
/// person. 4 ties real aliases to the subject (`matt`↔`jordanavery`,
/// `becky`↔`avery`) while rejecting unrelated handles (`arizonambb`).
pub(crate) const IDENTITY_OVERLAP_MIN: usize = 4;

/// True if two identity strings share a common substring of at least
/// [`IDENTITY_OVERLAP_MIN`] characters — a cheap, dictionary-free way to decide
/// whether a discovered Username/Person plausibly belongs to the subject. Inputs
/// are normalised via [`identity_norm`]. Short identities (< MIN) must match
/// exactly. O(n·m) over the two short strings — negligible for handles/names.
pub(crate) fn identity_overlaps(a: &str, b: &str) -> bool {
    let (a, b) = (identity_norm(a), identity_norm(b));
    if a.is_empty() || b.is_empty() {
        return false;
    }
    if a.len() < IDENTITY_OVERLAP_MIN || b.len() < IDENTITY_OVERLAP_MIN {
        return a == b;
    }
    // Longest-common-substring ≥ MIN via a rolling DP row.
    let (ab, bb) = (a.as_bytes(), b.as_bytes());
    let mut prev = vec![0usize; bb.len() + 1];
    let mut cur = vec![0usize; bb.len() + 1];
    for &ca in ab {
        for (j, &cb) in bb.iter().enumerate() {
            cur[j + 1] = if ca == cb { prev[j] + 1 } else { 0 };
            if cur[j + 1] >= IDENTITY_OVERLAP_MIN {
                return true;
            }
        }
        std::mem::swap(&mut prev, &mut cur);
        cur.iter_mut().for_each(|v| *v = 0);
    }
    false
}

/// Decide whether a discovered identity entity is a *wrong-identity* pivot —
/// one that should be recorded but not expanded, because pivoting on it would
/// pull a stranger's footprint into the scan.
///
/// An entity is gated only when ALL of these hold:
///   * it is a `Username` or `Person` (the kinds that fan out into a whole
///     online footprint when searched);
///   * it is below the Verified confidence tier (`c_effective < 0.75`) — a
///     verified identity has earned its expansion;
///   * it is single-source (`source_count <= 1`) — corroboration by a second
///     independent module is itself evidence the alias is real;
///   * its handle/name shares no [`IDENTITY_OVERLAP_MIN`]-char overlap with ANY
///     of the subject's confirmed identities (`subject_identities`).
///
/// Kept as a pure function (separate from the engine loop) so the decision is
/// unit-testable in isolation and the operator override (`expand_all_identities`)
/// is the only thing layered on top of it.
pub(crate) fn is_wrong_identity_pivot(
    kind: &crate::core::entity::EntityKind,
    c_effective: f64,
    source_count: u32,
    value: &str,
    subject_identities: &[String],
) -> bool {
    use crate::core::entity::{Classification, EntityKind};
    matches!(kind, EntityKind::Username | EntityKind::Person)
        && c_effective < Classification::VERIFIED_MIN
        && source_count <= 1
        && !subject_identities
            .iter()
            .any(|s| identity_overlaps(s, value))
}

pub(super) fn domain_expansion_factor(domain: &str) -> f64 {
    if is_noncentral_domain(domain) {
        0.15
    } else {
        1.0
    }
}

/// Hostname-only additions to `util::domains::INFRA_PROVIDER_ROOTS` (see
/// [`is_infra_domain`]): managed-DNS and nameserver estates, CDN edge apexes,
/// ESP sending domains, hosted-mail security gateways and the cloud hosts'
/// platform domains — names that surface in NS/MX/SOA/reverse lookups and are
/// applied by the hostname classifier only. Suffix-matched. A root that should
/// ALSO gate role mailboxes (`abuse@…`) belongs in the shared roots instead;
/// `core::scan::tests` locks the three tables pairwise disjoint.
pub(crate) const INFRA_HOST_ONLY: &[&str] = &[
    // Managed DNS & nameserver infrastructure
    "dnsmadeeasy.com",
    "nsone.net",
    "ultradns.net",
    "akam.net",
    "akamaiedge.net",
    "akamai.net",
    "edgekey.net",
    "edgesuite.net",
    "azure-dns.com", // Azure DNS nameservers (ns1-NN.azure-dns.*)
    "azure-dns.net",
    "azure-dns.org",
    "azure-dns.info",
    "googledomains.com", // Google Cloud DNS nameservers (ns-cloud-*.googledomains.com)
    "cloudns.net",       // ClouDNS managed DNS
    "dnsimple.com",      // DNSimple managed DNS
    // Registrar / hosting control-plane hostnames (the registrars' corporate
    // roots — secureserver.net, domaincontrol.com, name.com, namecheap.com,
    // gandi.net — are shared roots, since their role mailboxes surface too)
    "registrar-servers.com",
    "jomax.net", // GoDaddy registrar/abuse mail domain (dns@jomax.net)
    "epik.com",  // Epik registrar / nameserver provider
    // CDN apex roots (edge IPs are gated by validation::is_cdn_edge_ip)
    "cloudfront.net",
    "fastly.net",
    "fastlylb.net",
    "azureedge.net",   // Azure CDN edge
    "edgecastcdn.net", // Edgecast / Verizon Media CDN
    "llnwd.net",       // Limelight Networks CDN
    // CDN / cloud provider platform domains — never the subject's own
    // infrastructure, so expanding them floods the graph with the provider's
    // estate (the providers' corporate roots are shared roots).
    "cloudflare.net",
    "cloudflare-dns.com",
    "googleusercontent.com",
    "googleapis.com",
    "gstatic.com",
    "1e100.net",
    "azurewebsites.net",
    "windows.net",
    "cloudapp.net",         // Azure cloud-service / VM endpoints
    "elasticbeanstalk.com", // AWS Elastic Beanstalk app hosting
    // ESP / transactional mail sending domains
    "mandrillapp.com",
    "sparkpostmail.com",
    "amazonses.com",
    "mcsv.net",
    "mcdlv.net",
    "rsgsv.net",
    "list-manage.com", // Mailchimp campaign / click-tracking
    "mailchimp.com",
    "postmarkapp.com", // Postmark transactional mail
    "mailjet.com",
    // Hosted-mail security gateways
    "mimecast.com",
    "pphosted.com",
    "messagelabs.com",
    "protection.outlook.com", // Microsoft 365 Exchange Online Protection MX
    "barracudanetworks.com",  // Barracuda mail security
    "emailsrvr.com",          // Rackspace hosted email infra
];

const MEGA_DOMAINS: &[&str] = &[
    // Major platforms & social media
    "amazon.com",
    "amazon.com.au",
    "apple.com",
    "discord.com",
    "facebook.com",
    "fansly.com",
    "github.com",
    "google.com",
    "google.com.au",
    "instagram.com",
    "linkedin.com",
    "microsoft.com",
    "netflix.com",
    "onlyfans.com",
    "patreon.com",
    "pinterest.com",
    "quora.com",
    "reddit.com",
    "soundcloud.com",
    "spotify.com",
    "stackoverflow.com",
    "steamcommunity.com",
    "tiktok.com",
    "tumblr.com",
    "twitch.tv",
    "twitter.com",
    "vimeo.com",
    "whatsapp.com",
    "wikipedia.org",
    "x.com",
    "yahoo.com",
    "youtube.com",
    // Search engines & AI
    "bing.com",
    "chatgpt.com",
    "duckduckgo.com",
    "openai.com",
    // Content platforms & blogs
    "blogspot.com",
    "medium.com",
    "telegram.org",
    "wordpress.com",
    // News & media
    "bbc.co.uk",
    "bbc.com",
    "businessinsider.com",
    "cnn.com",
    "forbes.com",
    "nytimes.com",
    "reuters.com",
    "techcrunch.com",
    "theguardian.com",
    "washingtonpost.com",
    // Commerce & entertainment
    "aliexpress.com",
    "ebay.com",
    "ebay.com.au",
    "imdb.com",
    "pornhub.com",
    "xhamster.com",
    "xvideos.com",
    // CDN / infrastructure
    "akamai.com",
    "cloudflare.com",
    "fastly.com",
    // People-search / OSINT aggregators (they scrape and republish each other, so
    // a person scan hits many at once as stranger co-occurrence noise).
    "advancedbackgroundchecks.com",
    "anywho.com",
    "australialookup.com",
    "beenverified.com",
    "checkpeople.com",
    "clustrmaps.com",
    "cyberbackgroundchecks.com",
    "fastbackgroundcheck.com",
    "fastpeoplesearch.com",
    "idcrawl.com",
    "instantcheckmate.com",
    "intelius.com",
    "locatefamily.com",
    "mylife.com",
    "nuwber.com",
    "peekyou.com",
    "peoplefinders.com",
    "personlookup.com.au",
    "pipl.com",
    "radaris.com",
    "rocketreach.co",
    "searchpeoplefree.com",
    "smartbackgroundchecks.com",
    "socialcatfish.com",
    "spokeo.com",
    "thatsthem.com",
    "truepeoplesearch.com",
    "truthfinder.com",
    "usphonebook.com",
    "ussearch.com",
    "whitepages.com",
    "whitepages.com.au",
    "zabasearch.com",
    "zoominfo.com",
    // Email providers (freemail) — never the subject's own infrastructure, so a
    // discovered freemail domain must not be deep-expanded.
    "gmail.com",
    "googlemail.com",
    "hotmail.com",
    "icloud.com",
    "live.com",
    "msn.com",
    "office365.com",
    "outlook.com",
    "protonmail.com",
    "proton.me",
    "ymail.com",
    "aol.com",
    "me.com",
    "mac.com",
    "mail.com",
    "gmx.com",
    "gmx.de",
    "gmx.net",
    "zoho.com",
    "yandex.com",
    "yandex.ru",
    "mail.ru",
    "tutanota.com",
    "fastmail.com",
    "fastmail.fm",
    "web.de",
    "myway.com",
    // ISP / telco webmail (US + AU) — shared mailbox providers, not a subject's
    // own domain. These flooded a real scan as stranger co-occurrence addresses.
    "comcast.net",
    "verizon.net",
    "att.net",
    "sbcglobal.net",
    "bellsouth.net",
    "cox.net",
    "charter.net",
    "earthlink.net",
    "windstream.net",
    "frontier.net",
    "swbell.net",
    "rr.com",
    "q.com",
    "bigpond.com",
    "bigpond.net.au",
    "optusnet.com.au",
    "iinet.net.au",
    "tpg.com.au",
    "internode.on.net",
    "ozemail.com.au",
    "y7mail.com",
    // DNS / IP lookup tools
    "dnschecker.org",
    "domaintools.com",
    "ip2location.com",
    "ipaddress.com",
    "iplocation.io",
    "whatismyip.com",
    "whatismyipaddress.com",
    "whois.com",
    // Australian mega-sites (common noise in AU OSINT)
    "abc.net.au",
    "news.com.au",
    "smh.com.au",
    "nine.com.au",
    "realestate.com.au",
    "seek.com.au",
    "yellowpages.com.au",
    "carsales.com.au",
    "domain.com.au",
    "gumtree.com.au",
    "ozbargain.com.au",
    "truelocal.com.au",
    "whirlpool.net.au",
    // AU news mastheads — a subject named/quoted in the press is co-occurrence
    // noise, not their own domain.
    "afr.com",
    "couriermail.com.au",
    "dailytelegraph.com.au",
    "heraldsun.com.au",
    "sbs.com.au",
    "theage.com.au",
    "theaustralian.com.au",
    "thewest.com.au",
    // Additional global platforms
    "archive.org",
    "mastodon.social",
    "paypal.com",
    "snapchat.com",
    "threads.net",
];
