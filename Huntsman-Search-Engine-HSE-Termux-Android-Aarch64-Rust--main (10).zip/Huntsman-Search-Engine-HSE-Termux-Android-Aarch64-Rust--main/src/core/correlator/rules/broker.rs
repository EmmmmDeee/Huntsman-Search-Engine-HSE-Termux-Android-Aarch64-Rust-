//! AU-070 — Connection broker (identity articulation point).
//!
//! AU-062 rewards a pair's REDUNDANCY (independent routes), AU-069 its INTEGRITY
//! (one route strong end to end), and AU-063 flags a fragile *pair* link (a single
//! route). This is the NODE-level counterpart that none of them capture: an entity
//! that is the **sole** point holding ≥3 identities together — remove it and the
//! identity network fragments. It is the analyst's prime pivot (the linchpin) and
//! the highest-value gap-fill target: corroborate the broker and you harden every
//! connection that runs through it.
//!
//! Built on the shared [`crate::core::relation::connection_brokers`] primitive over
//! the same confined adjacency the other relation rules traverse (one graph, no
//! drift). Fires only for a broker of ≥3 identities — a 2-identity split is a single
//! fragile pair, already AU-063's job.

use std::collections::BTreeMap;

use super::*;
use crate::core::relation::{connection_brokers, identity_uids, sorted_confined_adjacency};

/// AU-070 — Connection broker.
///
/// Delegates articulation detection to [`connection_brokers`], then emits one
/// correlation per node that brokers ≥3 identities. Severity rises with the number
/// of identities the broker holds together (a larger fan-out is a more critical
/// single point of failure).
pub(in crate::core::correlator) fn rule_au_070_connection_broker(
    context: &RuleContext,
    relations: &[Relation],
    scan_id: &str,
    now: u64,
) -> Vec<Correlation> {
    let entities = context.entities();
    // A 2-identity split is a fragile *pair* (AU-063); a broker is a genuine ≥3-way
    // linchpin.
    const MIN_BROKERED: usize = 3;
    // Only links at or above the Probable tier may *bind* identities — the same
    // floor AU-067 resolves under. Without it a single weak edge makes a common-name
    // node look like the linchpin of dozens of unrelated namesakes.
    const MIN_CONF: f64 = crate::core::relation::IDENTITY_LINK_MIN_CONF;

    let by_uid = context.by_uid();
    let ids = identity_uids(entities);
    // Build the traversal graph ONCE and reuse it across the articulation search.
    let adj = sorted_confined_adjacency(entities, relations);

    let mut out = Vec::new();
    for broker in connection_brokers(&adj, &ids, MIN_CONF) {
        if broker.brokered.len() < MIN_BROKERED {
            continue;
        }
        let Some(&node) = by_uid.get(broker.uid.as_str()) else {
            continue;
        };

        // Human breakdown of the brokered identities by kind (deterministic order).
        let mut kinds: BTreeMap<String, usize> = BTreeMap::new();
        for uid in &broker.brokered {
            if let Some(e) = by_uid.get(uid.as_str()) {
                *kinds.entry(e.kind.to_string()).or_insert(0) += 1;
            }
        }
        let breakdown = kinds
            .iter()
            .map(|(k, n)| format!("{n} {k}"))
            .collect::<Vec<_>>()
            .join(", ");

        let n = broker.brokered.len();
        let severity = if n >= 5 {
            Severity::High
        } else {
            Severity::Medium
        };

        // The broker first, then every identity it holds together.
        let mut uids = Vec::with_capacity(n + 1);
        uids.push(broker.uid.clone());
        uids.extend(broker.brokered.iter().cloned());
        uids.sort_unstable();
        uids.dedup();

        out.push(Correlation::new(
            "AU-070",
            "Connection broker",
            severity,
            format!(
                "{} ({}) is the sole link binding {n} identities ({breakdown}) — removing it \
                 fragments the network: a single point of failure, and the prime pivot to corroborate",
                node.value, node.kind,
            ),
            uids,
            scan_id,
            now,
        ));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::relation::{Relation, RelationKind};

    fn mk(kind: EntityKind, value: &str) -> Entity {
        Entity::new(kind, value, 0.8, "s")
    }

    fn edge(from: &Entity, to: &Entity) -> Relation {
        Relation::new(
            from.uid.clone(),
            to.uid.clone(),
            RelationKind::DerivedFrom,
            0.8,
            "s",
        )
    }

    #[test]
    fn au070_fires_on_a_hub_brokering_three_identities() {
        // A domain hub is the sole connection between three identities.
        let hub = mk(EntityKind::Domain, "x.com");
        let email = mk(EntityKind::Email, "a@x.com");
        let uname = mk(EntityKind::Username, "alice");
        let person = mk(EntityKind::Person, "Bob");
        let rels = [edge(&email, &hub), edge(&uname, &hub), edge(&person, &hub)];
        let ents = [hub.clone(), email.clone(), uname.clone(), person.clone()];

        let ctx = RuleContext::new(&ents);
        let out = rule_au_070_connection_broker(&ctx, &rels, "s", 0);
        assert_eq!(out.len(), 1);
        assert_eq!(out[0].rule_id, "AU-070");
        // The finding references the broker and every brokered identity.
        for uid in [&hub.uid, &email.uid, &uname.uid, &person.uid] {
            assert!(out[0].entity_uids.contains(uid));
        }
    }

    #[test]
    fn au070_escalates_to_high_brokering_five_identities() {
        // A domain hub is the sole link binding FIVE identities → severity
        // escalates Medium→High (n = broker.brokered.len() >= 5). The
        // three-identity sibling above covers the base Medium arm. Identity
        // kinds span Person/Email/Phone/Username, so a second Email reaches five.
        let hub = mk(EntityKind::Domain, "x.com");
        let email = mk(EntityKind::Email, "a@x.com");
        let uname = mk(EntityKind::Username, "alice");
        let person = mk(EntityKind::Person, "Bob");
        let phone = mk(EntityKind::Phone, "+61400000000");
        let email2 = mk(EntityKind::Email, "c@x.com");
        let rels = [
            edge(&email, &hub),
            edge(&uname, &hub),
            edge(&person, &hub),
            edge(&phone, &hub),
            edge(&email2, &hub),
        ];
        let ents = [
            hub.clone(),
            email.clone(),
            uname.clone(),
            person.clone(),
            phone.clone(),
            email2.clone(),
        ];

        let ctx = RuleContext::new(&ents);
        let out = rule_au_070_connection_broker(&ctx, &rels, "s", 0);
        assert_eq!(out.len(), 1);
        assert_eq!(out[0].rule_id, "AU-070");
        assert_eq!(out[0].severity, Severity::High);
        for uid in [&email.uid, &uname.uid, &person.uid, &phone.uid, &email2.uid] {
            assert!(out[0].entity_uids.contains(uid));
        }
    }

    #[test]
    fn au070_silent_on_a_two_identity_bridge() {
        // The hub joins only two identities — a single fragile pair, AU-063's job,
        // below the ≥3 broker floor.
        let hub = mk(EntityKind::Domain, "x.com");
        let email = mk(EntityKind::Email, "a@x.com");
        let uname = mk(EntityKind::Username, "alice");
        let rels = [edge(&email, &hub), edge(&uname, &hub)];
        let ents = [hub, email, uname];
        let ctx = RuleContext::new(&ents);
        assert!(
            rule_au_070_connection_broker(&ctx, &rels, "s", 0).is_empty(),
            "a 2-identity bridge is not a broker"
        );
    }

    #[test]
    fn au070_silent_when_identities_are_redundantly_linked() {
        // Three identities forming a triangle: no single removal disconnects them.
        let a = mk(EntityKind::Email, "a@x.com");
        let b = mk(EntityKind::Username, "alice");
        let c = mk(EntityKind::Phone, "+61400000000");
        let rels = [edge(&a, &b), edge(&b, &c), edge(&a, &c)];
        let ents = [a, b, c];
        let ctx = RuleContext::new(&ents);
        assert!(rule_au_070_connection_broker(&ctx, &rels, "s", 0).is_empty());
    }
}
