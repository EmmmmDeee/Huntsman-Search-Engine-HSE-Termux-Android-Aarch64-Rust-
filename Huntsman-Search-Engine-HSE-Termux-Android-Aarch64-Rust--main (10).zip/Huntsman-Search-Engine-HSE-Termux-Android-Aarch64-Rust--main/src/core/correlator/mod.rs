// Correlator — rule-based cross-correlation analysis.
//
// Two entry points share the same deterministic rule set:
//
//   * [`Correlator::run`] — the authoritative finalise-time pass. Loads the
//     scan's persisted entities *and* the typed relation edges, evaluates
//     both the entity rules and the graph-aware relation rules, and persists
//     every firing.
//   * [`correlate_entities`] — a live, in-memory pass the engine invokes
//     during ingestion (after the seed round and after each expansion round)
//     so high-confidence correlations stream out as the graph grows rather
//     than only after the scan finishes. Entity rules only — relation rules
//     need the persisted edge set, so they stay in `run`.
//
// Each firing rule produces a [`Correlation`] record persisted alongside the
// scan and emitted on the event bus. Rules are deterministic — no LLMs,
// no fuzzy matching.

use crate::core::confidence;
use std::sync::Arc;

use serde::{Deserialize, Serialize};
use tracing::{debug, warn};

use crate::core::entity::{Entity, EntityKind, Evidence, canonical_handle};
use crate::core::error::Result;
use crate::core::port::StoragePort;
use crate::core::relation::Relation;
use std::cell::RefCell;
use std::collections::HashMap;

// ─── RuleContext ───────────────────────────────────────────────────────────
// Lazy-cached precomputed indexes shared across all correlation rules,
// eliminating O(R·E) redundant index rebuilds. Each rule independently calling
// canonical_handle() on the same entities 24 times per pass is O(R·E) with a
// large constant factor. RuleContext precomputes indexes once and shares them
// via method calls, amortizing the cost to O(E) + O(R·log E) rule dispatch.

pub struct RuleContext<'a> {
    entities: &'a [Entity],
    // Lazy-cached: by_canonical_handle maps canonical_handle(entity) → vec of entities with that handle
    by_canonical_handle: RefCell<Option<HashMap<String, Vec<&'a Entity>>>>,
    // Lazy-cached: uid → entity. Fourteen entity/relation rules rebuilt this
    // identical index per pass; sharing it removes the redundant O(E) rebuilds.
    by_uid: RefCell<Option<HashMap<&'a str, &'a Entity>>>,
}

impl<'a> RuleContext<'a> {
    pub fn new(entities: &'a [Entity]) -> Self {
        Self {
            entities,
            by_canonical_handle: RefCell::new(None),
            by_uid: RefCell::new(None),
        }
    }

    pub fn entities(&self) -> &'a [Entity] {
        self.entities
    }

    /// Returns a reference to the cached `uid → entity` index over the context's
    /// entity set. Built once on first call, reused thereafter — the same
    /// lazy-cache discipline as [`by_canonical_handle`](Self::by_canonical_handle).
    /// The map is exactly what fourteen relation/entity rules each rebuilt with
    /// `entities.iter().map(|e| (e.uid.as_str(), e)).collect()`, so sharing it is
    /// behaviour-neutral — every lookup returns the same entity — and only removes
    /// the repeated per-rule rebuild.
    pub fn by_uid(&self) -> std::cell::Ref<'_, HashMap<&'a str, &'a Entity>> {
        if self.by_uid.borrow().is_none() {
            let map: HashMap<&str, &Entity> =
                self.entities.iter().map(|e| (e.uid.as_str(), e)).collect();
            *self.by_uid.borrow_mut() = Some(map);
        }
        std::cell::Ref::map(self.by_uid.borrow(), |opt| {
            opt.as_ref().expect("just populated")
        })
    }

    /// Returns a reference to the cached canonical-handle map. Builds and caches
    /// on first call, returns cached on subsequent calls.
    pub fn by_canonical_handle(&self) -> std::cell::Ref<'_, HashMap<String, Vec<&'a Entity>>> {
        if self.by_canonical_handle.borrow().is_none() {
            let mut map: HashMap<String, Vec<&Entity>> = HashMap::new();
            for entity in self.entities {
                let canonical = canonical_handle(&entity.value);
                map.entry(canonical).or_default().push(entity);
            }
            *self.by_canonical_handle.borrow_mut() = Some(map);
        }
        std::cell::Ref::map(self.by_canonical_handle.borrow(), |opt| {
            opt.as_ref().expect("just populated")
        })
    }
}

// ─── Severity ──────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Severity {
    Low,
    Medium,
    High,
    Critical,
}

impl Severity {
    pub fn as_canonical(&self) -> &'static str {
        match self {
            Self::Low => "low",
            Self::Medium => "medium",
            Self::High => "high",
            Self::Critical => "critical",
        }
    }

    /// Ordinal weight for ranking. Higher = more severe. Used as the severity
    /// factor in a correlation's rank score (`weight × max child C_eff`).
    pub fn weight(&self) -> f64 {
        match self {
            Self::Low => 1.0,
            Self::Medium => 2.0,
            Self::High => 3.0,
            Self::Critical => 4.0,
        }
    }
}

impl std::fmt::Display for Severity {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Low => write!(f, "LOW"),
            Self::Medium => write!(f, "MEDIUM"),
            Self::High => write!(f, "HIGH"),
            Self::Critical => write!(f, "CRITICAL"),
        }
    }
}

// ─── Correlation ───────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Correlation {
    pub rule_id: String,
    pub rule_name: String,
    pub severity: Severity,
    pub description: String,
    pub entity_uids: Vec<String>,
    pub scan_id: String,
    pub ts: u64,
    /// Ranking score = `severity.weight() × max(C_eff)` over the child
    /// entities. Computed once in `Correlator::run` after the rules fire (the
    /// rules themselves don't have the entity C_eff map handy) and used to
    /// order the Correlations view highest-value-first. `#[serde(default)]`
    /// keeps correlation rows persisted before this field existed readable
    /// (they deserialize with rank 0.0 and simply sort last).
    #[serde(default)]
    pub rank: f64,
}

/// Compute `severity.weight() × max(C_eff)` over the child entities of each
/// correlation, write it into `rank`, and sort the slice rank-descending with
/// a stable severity/rule_id tie-break. Shared by both the finalize pass
/// (`Correlator::run`) and the live incremental pass (engine) so a correlation
/// carries the same rank whether it was streamed mid-scan or produced at the
/// end. `ceff` maps entity uid → c_effective().
pub fn rank_and_sort(corrs: &mut [Correlation], ceff: &std::collections::HashMap<String, f64>) {
    for c in corrs.iter_mut() {
        let max_child = c
            .entity_uids
            .iter()
            .filter_map(|uid| ceff.get(uid).copied())
            .fold(0.0_f64, f64::max);
        c.rank = c.severity.weight() * max_child;
    }
    corrs.sort_by(|a, b| {
        b.rank
            .partial_cmp(&a.rank)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then(b.severity.cmp(&a.severity))
            .then(a.rule_id.cmp(&b.rule_id))
            // Total tie-break so the ORDER is deterministic even when one rule
            // fires for several entity groups (same rule_id): the per-group
            // entity_uids are already individually sorted, so comparing the lists
            // gives identical inputs an identical correlation ordering rather than
            // leaving same-rule ties to non-deterministic generation order.
            .then_with(|| a.entity_uids.cmp(&b.entity_uids))
    });
}

impl Correlation {
    pub(crate) fn new(
        rule_id: &str,
        rule_name: &str,
        severity: Severity,
        description: String,
        entity_uids: Vec<String>,
        scan_id: &str,
        ts: u64,
    ) -> Self {
        Self {
            rule_id: rule_id.into(),
            rule_name: rule_name.into(),
            severity,
            description,
            entity_uids,
            scan_id: scan_id.into(),
            ts,
            rank: 0.0,
        }
    }
}

// ─── Correlator ────────────────────────────────────────────────────────────

pub struct Correlator {
    store: Arc<dyn StoragePort>,
}

impl Correlator {
    pub fn new(store: Arc<dyn StoragePort>) -> Self {
        Self { store }
    }

    pub fn run(&self, scan_id: &str) -> Result<Vec<Correlation>> {
        let entities = self.store.entities_for_scan(scan_id)?;
        if entities.is_empty() {
            return Ok(Vec::new());
        }
        // Build the quarantine-filtered confirmed view ONCE and share it across
        // both the entity-only and the graph-aware passes. Each pass otherwise
        // re-filtered + re-cloned the full entity slice (`confirmed_only`); for a
        // finalise pass that runs both, that was two full clones of the entity
        // set per scan.
        let confirmed = confirmed_only(&entities);
        // Build shared RuleContext once, shared by both entity and relation rule
        // passes. This precomputes indexes (e.g. canonical-handle map) that all
        // rules would otherwise rebuild independently.
        let context = RuleContext::new(&confirmed);
        let now = crate::core::entity::unix_now();
        // One shared wall-clock deadline across the entity AND relation passes, so
        // the WHOLE finalise correlator phase is bounded (a huge recalled graph
        // can't hang the scan). Never reached by a normal scan.
        let deadline = Some(std::time::Instant::now() + CORRELATOR_BUDGET);
        let mut firings = evaluate_rules_on(&context, scan_id, now, deadline);

        // Graph-aware pass: rules that need the typed relation edges (the
        // attribution graph), not just the flat entity list. Relations are
        // persisted by `finalise_scan` before the correlator runs.
        let relations = self.store.relations_for_scan(scan_id)?;
        if !relations.is_empty() {
            firings.extend(evaluate_relation_rules_on(
                &context, &relations, scan_id, now, deadline,
            ));
        }

        // Rank each firing by severity × highest child C_eff and sort
        // (shared with the live incremental pass so ranks are consistent).
        let ceff: std::collections::HashMap<String, f64> = entities
            .iter()
            .map(|e| (e.uid.clone(), e.c_effective()))
            .collect();
        rank_and_sort(&mut firings, &ceff);

        for c in &firings {
            self.store.upsert_correlation(c)?;
        }
        // Report what was EXAMINED, not just what fired. `fired = 0` alone is
        // ambiguous between "the rules ran over the whole scan and nothing
        // correlated" and "almost every entity was quarantined, so the rules had
        // nothing to run over" — opposite conditions demanding opposite operator
        // responses, previously indistinguishable in the logs.
        let examined = confirmed.len();
        let quarantined = entities.len().saturating_sub(examined);
        debug!(
            scan_id,
            fired = firings.len(),
            examined,
            quarantined,
            total = entities.len(),
            "correlator done"
        );
        // A scan whose findings are overwhelmingly quarantined has not been
        // correlated in any meaningful sense, and the operator cannot see that
        // from a correlation count of zero. This is the one condition worth
        // raising above debug: it is actionable (the quarantine lifts when the
        // subject gains a confirmed location) and it silently voids the entire
        // correlation phase.
        if quarantined > 0 && examined * QUARANTINE_ALARM_RATIO < entities.len() {
            tracing::warn!(
                scan_id,
                examined,
                quarantined,
                total = entities.len(),
                "correlation ran over a small fraction of the scan — most entities are \
                 candidate-quarantined, so a low correlation count reflects what was \
                 EXAMINED, not what was found"
            );
        }
        Ok(firings)
    }
}

// ─── Rules ─────────────────────────────────────────────────────────────────

type RuleFn = fn(&RuleContext, &str, u64) -> Vec<Correlation>;

pub(crate) mod rules;
pub(crate) use rules::location::{
    au_location_corroboration, au059_synergy_fix, best_au_location_estimate,
    is_anchoring_geo_source,
};
// The shared multi-pathway corroboration detector — the AU-062 rule and the
// engine's `promote_multipath_corroborated` pass both call this one finder, so
// the correlation and the confidence boost can never drift apart. (The
// `MultipathLink` it returns is `pub(in crate::core)`, so callers read its
// fields by inference without naming the type.)
pub(in crate::core) use rules::multipath::multipath_corroborated_links;
// The shared single-pathway (fragile-link) detector — the AU-063 gap lead and
// the engine's cross-scan gap resolution (AU-066) both call this one finder, so
// the lead that flags a gap and the logic that fills it can't drift apart.
pub(in crate::core) use rules::gap::single_route_identity_links;
// Active gap-fill: the gap endpoints + the orthogonal families missing from each,
// and the source-family classifier the engine maps those families to modules
// with — so what AU-063 names, the engine actually pursues.
pub(in crate::core) use rules::gap::gap_fill_probes;
pub(in crate::core) use rules::source_family;
// The reused-secret classifier + handle-canonicaliser: `core::relation::builders`'
// `derive_reused_secret_link` calls both directly so the `SharesSecretWith` graph
// edge and the AU-047/AU-048/AU-106 correlations can never disagree on which
// secrets/handles qualify.
pub(in crate::core) use rules::Secret;
pub(in crate::core) use rules::is_anchorable_handle;
// Shared with the engine's autonomous-seed / expansion gates so an infrastructure
// geo entity (a WHOIS registrant / hosting address, an `infra:` map-feature
// coordinate, or the radar `0,0` sentinel) is excluded from seeding a scan by the
// SAME canonical guard the correlator's location rules apply — the engine
// previously hand-rolled a partial tag subset that drifted.
pub(in crate::core) use rules::location::is_infrastructure_geo;
// Shared with `core::relation::builders::persona_key` so the AliasOf handle-pivot
// excludes the SAME generic role-mailbox / placeholder handles the correlator's
// identity rules exclude — a `info@`/`support@` address must never fan a
// cross-org identity clique.
pub(in crate::core) use rules::is_generic_handle;
// The breach/stealer corpus classifier: `core::breach_consensus` grades an
// entity's corroboration by counting DISTINCT breach sources, and must agree
// exactly with the correlator on which sources those are — a second, drifting
// list would let the consensus pass certify agreement the rules never saw.
pub(in crate::core) use rules::breach_pii::{
    DOB_KEYS, breach_corpus_key, is_breach_source, normalise_dob,
};
use rules::*;

const RULES: &[RuleFn] = &[
    rule_au_001_multi_breach,
    rule_au_002_identity_cluster,
    rule_au_003_high_corroboration,
    rule_au_004_malicious_infrastructure,
    rule_au_005_anonymous_network,
    rule_au_006_proxy_vpn,
    rule_au_007_high_risk_reputation,
    rule_au_008_exposed_service,
    rule_au_009_stealer_log,
    rule_au_010_infra_consensus,
    rule_au_011_cross_platform_username,
    rule_au_012_identity_linked_domain,
    rule_au_013_local_network_discovery,
    rule_au_014_geo_cluster,
    rule_au_015_threat_intel_hit,
    rule_au_016_breach_ip_geo_chain,
    rule_au_017_multi_geo_convergence,
    rule_au_018_email_address_colocation,
    rule_au_019_temporal_breach_cluster,
    rule_au_020_person_entity_cluster,
    rule_au_021_api_key_exposure,
    // AU-097: subject's IP/ASN belongs to an Australian ISP (Telstra/Optus/TPG/…)
    // or AARNet — a network-layer AU residency/affiliation signal.
    rule_au_097_au_isp_network,
    // AU-095: ranked exposure-intelligence portfolio over all harvested ApiKey
    // entities (provider × criticality × detection) — a revoke-first priority
    // order, complementing AU-021's flat per-key findings. Catalogue-only.
    rule_au_095_exposed_key_portfolio,
    // AU-096: a harvested key for an OSINT provider (Shodan/Dehashed/IntelX/…)
    // identifies its holder as an OSINT practitioner — provider + tradecraft
    // categories as the pivot. Reads the osint-practitioner/osint-category tags.
    rule_au_096_osint_practitioner,
    rule_au_022_organisation_with_breach,
    rule_au_023_cross_platform_identity,
    rule_au_024_email_fraud_signal,
    rule_au_025_corporate_identity_link,
    rule_au_026_validated_address,
    rule_au_027_address_coordinates_chain,
    rule_au_028_subdomain_takeover_risk,
    rule_au_029_cloud_storage_exposure,
    rule_au_030_geo_convergence_score,
    rule_au_033_abn_organisation_link,
    rule_au_034_handle_reuse_identity,
    rule_au_035_confirmed_derived_handle,
    rule_au_036_email_alias_convergence,
    rule_au_037_credential_exposure,
    rule_au_038_verified_cross_platform_identity,
    rule_au_039_wallet_identity,
    rule_au_040_wallet_breach_exposure,
    rule_au_041_ens_identity,
    rule_au_042_pgp_email_identity,
    rule_au_043_paste_exposure,
    rule_au_044_shared_tracking_id,
    rule_au_045_multi_service_identity,
    rule_au_072_payid_payment_surface,
    rule_au_073_subject_date_of_birth,
    rule_au_074_au_government_id_exposure,
    rule_au_075_named_associate,
    // AU-090: the subject's AU state/territory mined from a breach `state` /
    // state-of-issue field — a residency/jurisdiction geo anchor (sits with the
    // AU-073/074/075 breach-field family it shares breach_pii.rs with).
    rule_au_090_au_jurisdiction,
    // AU-091: the subject's residential postcode mined from a breach `postcode`
    // field, resolved offline to its state + gazetteer coordinate — finer than
    // AU-090's state grain.
    rule_au_091_au_postcode_locality,
    // AU-092: cross-checks the breach-stated state/postcode (AU-090/091) against
    // the geolocated coordinate/address footprint — agreement corroborates
    // residency, a disjoint state flags stale data / a move / a namesake.
    rule_au_092_breach_locality_footprint_crosscheck,
    // AU-093: assembles the subject's suburb / full residential address from the
    // co-located fields of one breach record, offline-geocoded — the dwelling-
    // grade locator AU-090/091 (single-field) can't reach.
    rule_au_093_au_address_from_breach,
    // AU-098: the multi-source residency verdict — fuses coordinate + address +
    // breach-record + phone-area-code into one jurisdiction, scored by how many
    // independent signal classes agree. The gold-standard geolocation finding.
    rule_au_098_residency_consensus,
    // Free, offline identity-resolution rules — require no API keys.
    // AU-076: email local-part ↔ username canonical match (zero-API bridge).
    // AU-077: name-derived username independently confirmed on a platform.
    // AU-078: hub entity observed in 3+ distinct prior investigations.
    // AU-079: profile bio / twitter attr names another username in the graph.
    // AU-080: recurring co-occurrence pair from cross-scan history now active.
    // AU-081: two Person records from different sources share a canonical name.
    // AU-082: same API key found in 2+ independent source families (dual-pathway).
    rule_au_076_email_username_localpart_bridge,
    rule_au_077_name_derived_username_confirmed,
    rule_au_078_hub_entity,
    rule_au_079_bio_cross_mention,
    rule_au_080_recurring_cooccurrence_link,
    rule_au_081_canonical_person_name_match,
    rule_au_082_api_key_dual_pathway,
    // AU-083: ≥2 emails independently match the same locale naming pattern.
    rule_au_083_locale_multi_email_corroboration,
    rule_au_046_cross_platform_identity_resolution,
    rule_au_068_anonymous_sim,
    rule_au_047_reused_secret_identity,
    rule_au_048_shared_public_key,
    rule_au_049_shared_address_association,
    rule_au_050_shared_phone_association,
    rule_au_051_shared_surname_kin,
    rule_au_052_geographic_area_of_operation,
    rule_au_053_out_of_area_location,
    rule_au_054_data_broker_exposure,
    rule_au_055_primary_source_accounts,
    rule_au_056_jurisdiction_cross_check,
    // AU-099: reverse-geocode a coordinate fix to its nearest AU population
    // centre (offline) — a human locality label for a bare GPS/EXIF lat-long.
    rule_au_099_coordinate_reverse_geocode,
    rule_au_057_synthesised_location_fix,
    rule_au_058_professional_profile_geo,
    rule_au_059_cross_seed_geo_synergy,
    rule_au_061_family_geo_corroboration,
    // AU-103: the radar's autonomous self-location — fuses the passively
    // collected on-device signals (GPS/network fix + Wi-Fi/cell/Bluetooth/LAN
    // presence) into the operator device's own position, with no seed input.
    rule_au_103_device_self_location,
    // AU-084: dual-source cell tower corroboration (live sensor × crowdsourced DB).
    rule_au_084_cell_tower_dual_source,
    // AU-085: AU fixed-line area code cross-checked against address/coordinate state.
    rule_au_085_phone_region_jurisdiction,
    // AU-102: phone line-type profile — classifies every AU number the subject
    // carries (mobile / geographic fixed line / VoIP / business-service) into a
    // contactability, premises and organisational-tie picture; portability-proof.
    rule_au_102_phone_line_type_profile,
    // AU-086: a name-derived email guess independently confirmed in real data.
    rule_au_086_name_derived_email_confirmed,
    // AU-087: ≥2 identities share a specific (non-freemail) organisational email
    // domain — an employer / university / agency affiliation surface.
    rule_au_087_shared_org_email_domain,
    // AU-088: subject confirmed by N authoritative AU public registers (AHPRA,
    // ASIC, electoral, property, AustLII, ACNC, ABR) — government-grounded ID.
    rule_au_088_authoritative_register_confirmation,
    // AU-089: ≥2 distinct registered AU companies (checksum-valid ACN/company-
    // ABN) in the graph — an officeholder/controller corporate-network footprint.
    rule_au_089_corporate_network,
    // AU-094: a non-company ABN (sole trader / trust / partnership) — the people-
    // centric complement to AU-089, tying a natural person to an operating
    // business. The majority of AU ABN holders are non-company.
    rule_au_094_sole_trader_abn,
    // AU-100: the subject's employer/affiliation from their own AU organisational
    // email domain (.com.au/.gov.au/.edu.au/…), classified by registrant type.
    rule_au_100_au_employer_affiliation,
    // AU-101: identity-resolution breadth — how many distinct identity facet
    // classes (name, email, phone, username, address, business id, DOB, gov ID)
    // are pinned to the subject. The people-centric analogue of AU-098's
    // residency consensus, measuring breadth rather than single-value depth.
    rule_au_101_identity_resolution,
    // AU-104: resolves an exposed Australian BSB to its bank (AusPayNet
    // allocation), escalating to a full account-credential finding when a bank
    // account number co-occurs — financial attribution for almost every AU adult.
    rule_au_104_bank_account_exposure,
    // AU-105: the same secret reused across >=2 distinct breaches — the subject's
    // credential-stuffing / account-takeover surface, never echoing the secret.
    rule_au_105_credential_reuse,
    // AU-106: a shared device fingerprint (hwid/machine_id) ties >=2 distinct
    // accounts to one controller — the same physical machine (device-level
    // analogue of AU-047's reused-secret link).
    rule_au_106_shared_device_identity,
    // AU-107: the subject's breach-stated employer/affiliation — the breach-tagged
    // Organisation (0.50) that AU-022's 0.60 co-location gate never names.
    rule_au_107_breach_employer_affiliation,
    // AU-108: the subject's breach-listed accounts across >=2 platforms — a stated
    // cross-platform footprint from the `platform:handle` breach Usernames.
    rule_au_108_breach_social_footprint,
    // AU-111: a CDN-fronted domain's SPF-authorised mail-sender IP is a likely
    // origin/hosting-network candidate — mail isn't proxied by the CDN edge.
    rule_au_111_cdn_origin_candidate,
    // AU-112: an independently-discovered IP address falling within a narrow
    // network block also discovered this scan — shared hosting infrastructure,
    // reusing util::spf's CIDR-containment maths rather than duplicating it.
    rule_au_112_shared_cidr_infrastructure,
    // AU-114: a confirmed Person/Organisation flagged on a sanctions / debarment
    // / PEP list (opensanctions definitive match, Wikidata PEP signal) — the
    // highest-consequence OSINT screening signal, graded Critical/High/Medium by
    // the strongest flag. Surfaces what previously sat un-named in the graph.
    rule_au_114_sanctions_exposure,
    // AU-115: a personal Wi-Fi SSID that WiGLE geolocated (ssid-located
    // Coordinates naming it) — a subject-owned network placing its owner, a
    // high-value GEOINT lead previously surfaced by no correlation.
    rule_au_115_personal_wifi_geolocated,
    // AU-117: the operator's OWN bonded (paired) Bluetooth kit whose members
    // broadcast persistent hardware MACs — a self-carried tracking fingerprint,
    // the bonded counterpart to AU-122's third-party trackable devices.
    rule_au_117_personal_device_constellation,
    // AU-118: two distinct registrable domains in one scan whose brand labels
    // are homoglyph/typo look-alikes — a phishing/brand-abuse domain standing up
    // beside the genuine one (dnstwist at the correlation layer, across every
    // discovered domain rather than only seed permutations).
    rule_au_118_lookalike_domain_impersonation,
    // AU-119: the subject's confirmed dating-platform profiles — a location-
    // bearing personal-exposure surface the generic footprint rules bury in a
    // list; surfaced on its own at a severity that reflects the exposure.
    rule_au_119_dating_platform_exposure,
    // AU-120: the subject's confirmed subscription-creator / webcam / adult
    // profiles — a deliberate, identity-linked (payment/KYC) footprint elevated
    // above the generic account roster.
    rule_au_120_monetized_creator_exposure,
    // AU-121: the transitive closure of reused-secret links — a chain of
    // accounts no single secret spans (AU-047's blind spot), reported as one
    // credential-reuse blast radius. (Renumbered from AU-114 on merge — main's
    // AU-114 is sanctions exposure.)
    rule_au_121_credential_reuse_blast_radius,
    // AU-122: an RF-observed (radar/WiGLE) sweep's trackable hardware devices —
    // universally-administered MACs a real device broadcasts — separated from
    // the randomized privacy addresses that rotate and can't be followed.
    // (Renumbered from AU-115 on merge — main's AU-115 is personal-wifi-geo.)
    rule_au_122_trackable_rf_device,
    // AU-123: Username handles that share a digit-folded stem (jdiegmann /
    // jdiegmann92 / jdiegmann_2024) across ≥2 sources — the base-handle-plus-
    // number pattern one operator reuses across platforms, which the exact-match
    // handle rules (canonical_handle keeps digits) never join. A Medium lead.
    rule_au_123_numeric_variant_handle_persona,
    // AU-124: elevates the `ransomware-victim` tag + `group:` attribution
    // (emitted by ransomware_live/ransomlook) to one grouped High finding — the
    // sole consumer of both, which no other rule reads.
    rule_au_124_ransomware_victim_exposure,
];

fn evaluate_rules(entities: &[Entity], scan_id: &str) -> Vec<Correlation> {
    let now = crate::core::entity::unix_now();
    // Quarantine: speculative `candidate` entities never enter correlation.
    // These are the non-target breach-dump rows (other people returned by a
    // broad name search), unconfirmed username permutations, and search-only
    // guesses — each tagged `candidate` by its module. Excluding them here is
    // what stops a single broad search from fusing hundreds of strangers into
    // a "critical identity cluster" (AU-002) or manufacturing AU-003/AU-018
    // corroboration out of noise. The entities remain in the store and the
    // candidates view; they simply don't get to assert relationships.
    let confirmed = confirmed_only(entities);
    let context = RuleContext::new(&confirmed);
    // The live incremental pass is per-round and small — no budget, full
    // determinism (its streaming correlations must be reproducible).
    evaluate_rules_on(&context, scan_id, now, None)
}

/// Wall-clock budget for the FINALISE correlator pass (entity rules + the
/// graph-aware relation rules share it). The rule set is near-instant on a
/// normal scan, but a very large recalled entity/relation graph — a deep
/// `--expand-all-identities` sweep that pulls a big prior graph in via recall —
/// can push the graph-traversal rules (transitive closure, clustering) into
/// MINUTES. Observed at 20+ on a ~500-entity recalled set, which left scans hung
/// at finalise and (before the recovery fix) lost everything. Cap it: run as
/// many rules as fit, then finalise with the correlations computed so far — the
/// full entity set and the partial correlations still persist and the scan
/// COMPLETES instead of hanging. Only the pathological large-graph case ever
/// reaches this deadline; a normal scan finishes in well under a second, so the
/// finalise stays deterministic in every realistic case. Generous so legitimate
/// scans keep every correlation.
const CORRELATOR_BUDGET: std::time::Duration = std::time::Duration::from_secs(120);

/// Raise the quarantine alarm when the examined set is under `1/N` of the scan.
///
/// Four (i.e. under 25% examined) is deliberately well clear of a scan that
/// merely carries some breach candidates — quarantining a minority is the
/// system working as designed. It fires on the pathological shape actually
/// observed: a 1081-entity dossier in which every breach record stayed
/// quarantined because the subject never gained a confirmed location, leaving
/// ~7 entities for the rules and a correlation count of zero that read as
/// "nothing correlated" rather than "nothing was examined".
const QUARANTINE_ALARM_RATIO: usize = 4;

/// Run every entity-only rule over an already quarantine-filtered, confirmed
/// entity slice using a pre-built RuleContext. Split out from [`evaluate_rules`]
/// so a caller that runs both the entity and the relation passes (`Correlator::run`)
/// can filter once and share the confirmed view and RuleContext instead of
/// cloning per pass. `deadline` (set only on the finalise pass) caps total
/// wall-time: once reached, no further rule is started and the pass returns what
/// it has — a complete scan with partial correlations beats one hung forever.
fn evaluate_rules_on(
    context: &RuleContext,
    scan_id: &str,
    now: u64,
    deadline: Option<std::time::Instant>,
) -> Vec<Correlation> {
    let mut out = Vec::new();
    for (i, rule) in RULES.iter().enumerate() {
        if deadline.is_some_and(|dl| std::time::Instant::now() >= dl) {
            warn!(
                scan_id,
                ran = i,
                total = RULES.len(),
                "correlator entity-rule budget exceeded — finalising with partial correlations"
            );
            break;
        }
        out.extend(rule(context, scan_id, now));
    }
    out
}

/// Entities minus the `candidate`-tagged quarantine set — the view every
/// correlation rule sees. Returns a [`Cow`](std::borrow::Cow): when nothing is quarantined (the
/// common case for a focused email/username/domain scan) the caller's slice is
/// BORROWED, avoiding a full clone of the entity set — each [`Entity`] owns its
/// `Vec<Evidence>`, so that clone is far from free on a large recalled graph and
/// ran on every correlation round. Only when a `candidate` entity is actually
/// present does it allocate the filtered copy. Both call sites pass `&confirmed`
/// to a `&[Entity]` parameter, so deref coercion keeps them unchanged.
fn confirmed_only(entities: &[Entity]) -> std::borrow::Cow<'_, [Entity]> {
    if entities
        .iter()
        .all(|e| !e.has_tag(crate::core::tags::CANDIDATE))
    {
        std::borrow::Cow::Borrowed(entities)
    } else {
        std::borrow::Cow::Owned(
            entities
                .iter()
                .filter(|e| !e.has_tag(crate::core::tags::CANDIDATE))
                .cloned()
                .collect(),
        )
    }
}

/// Evaluate the entity-only rules against an in-memory entity slice.
///
/// This is the live-ingestion entry point: the engine calls it against the
/// working entity map after each dispatch round so correlations stream out
/// during the scan, with no store round-trip. The graph-aware relation rules
/// are intentionally excluded here — they need the persisted edge set, which
/// only exists once [`Correlator::run`] derives it at finalise.
pub(crate) fn correlate_entities(entities: &[Entity], scan_id: &str) -> Vec<Correlation> {
    evaluate_rules(entities, scan_id)
}

// ─── Bench-only entry points (F.3 / SOL-F3: "widen criterion to the
// correlation pass") ────────────────────────────────────────────────────────
//
// `benches/*.rs` are separate compilation units that link against this
// crate's PUBLIC API only — unlike `#[cfg(test)]` code (see `perf`, below),
// they never see `pub(crate)` items and don't run under `cargo bench`'s
// release-profile build, so `correlate_entities` — deliberately `pub(crate)`,
// an internal fast path, not published API — was unreachable from a
// criterion bench. This is the same narrow, documented `#[doc(hidden)] pub
// fn` widening `cert_intel::fuzz_entry_parse_der` established for
// `cargo-fuzz` (SOL-F3's other leg): additive, harness-only, no new
// production surface.
//
// `bench_synthetic_entities` is also the single generator `perf`'s in-crate
// `#[ignore]`d guard (`scaling_baseline`/`pass_is_subquadratic`) delegates
// to, so the two harnesses can never silently diverge on what "representative
// load" means — the single-sourced-vocabulary rule.

/// Build a representative confirmed-entity set of `n` entities that exercises
/// the heavier correlation rules with *real* work (not early-outs):
///
/// * ~¼ `Username` + ~¼ `Email` drawn from a shared, overlapping handle space,
///   so AU-034 (handle reuse) actually matches across the two sets — the path
///   that was once quadratic. Username and email of a shared handle carry
///   *different* evidence sources, so the rule's ≥2-distinct-source gate is
///   satisfied and the match work is performed rather than skipped.
/// * the remaining half spread across the other kinds, a fraction tagged
///   `breach`/`stealer-log` with multi-source evidence, to give the breach /
///   identity / corroboration rules realistic input.
///
/// Pure and deterministic (no RNG) so runs are comparable across `cargo
/// bench`/`cargo test -- --ignored` invocations.
#[doc(hidden)]
#[must_use]
pub fn bench_synthetic_entities(n: usize) -> Vec<Entity> {
    let mut out = Vec::with_capacity(n);
    let quarter = n / 4;
    // Shared handle space: handles repeat every `handle_space` indices so a
    // username and an email can land on the same canonical handle.
    let handle_space = (quarter / 2).max(1);

    for i in 0..n {
        let bucket = i % 4;
        let mut e = match bucket {
            0 => {
                // Username on a shared handle, observed on a platform.
                let mut e = Entity::new(
                    EntityKind::Username,
                    format!("handle{:04}", i % handle_space),
                    confidence::HIGH_PLUSPLUS,
                    "scan",
                );
                e.add_evidence(Evidence::new("username_search", "observed"));
                e
            }
            1 => {
                // Email whose local-part is the same shared handle, from a
                // *different* source so AU-034's ≥2-source gate passes.
                let mut e = Entity::new(
                    EntityKind::Email,
                    format!("handle{:04}@example{}.com", i % handle_space, i % 7),
                    confidence::HIGH_PLUSPLUS,
                    "scan",
                );
                e.add_evidence(Evidence::new("hunter_io", "observed"));
                if i % 5 == 0 {
                    e.tag(crate::core::tags::BREACH);
                    e.add_evidence(Evidence::new("oathnet_pro", "breach row"));
                }
                e
            }
            2 => {
                let kind = match (i / 4) % 4 {
                    0 => EntityKind::IpAddress,
                    1 => EntityKind::Domain,
                    2 => EntityKind::Person,
                    _ => EntityKind::Address,
                };
                let mut e = Entity::new(kind, format!("v{i}"), confidence::HIGH_PLUS, "scan");
                e.add_evidence(Evidence::new("name_intel", "derived"));
                if i % 11 == 0 {
                    e.tag(crate::core::tags::STEALER_LOG);
                }
                e
            }
            _ => {
                let kind = match (i / 4) % 3 {
                    0 => EntityKind::Url,
                    1 => EntityKind::CryptoAddress,
                    _ => EntityKind::Organisation,
                };
                let mut e = Entity::new(kind, format!("w{i}"), confidence::MEDIUM_PLUS, "scan");
                e.add_evidence(Evidence::new("exa_search", "hit"));
                e
            }
        };
        e.tag("src");
        out.push(e);
    }
    out
}

/// Bench-visible entry point for the correlation pass itself — see
/// [`bench_synthetic_entities`] for the generator that feeds it.
#[doc(hidden)]
pub fn bench_correlate_entities(entities: &[Entity], scan_id: &str) -> Vec<Correlation> {
    correlate_entities(entities, scan_id)
}

// ─── Graph-aware rules ───────────────────────────────────────────────────────
// Rules that consume the typed `Relation` edge set in addition to entities.
// Kept separate from `RULES` so the 30 entity-only rules need no signature
// change.

type RelationRuleFn = fn(&RuleContext, &[Relation], &str, u64) -> Vec<Correlation>;

const RELATION_RULES: &[RelationRuleFn] = &[
    rule_au_031_malicious_adjacency,
    rule_au_032_colocation_cluster,
    rule_au_060_transitive_identity_closure,
    rule_au_062_multipath_corroboration,
    rule_au_063_corroboration_gap,
    rule_au_064_generalized_pathway_template,
    rule_au_067_resolved_identity_cluster,
    rule_au_069_high_integrity_connection,
    rule_au_070_connection_broker,
    rule_au_071_robust_identity_cluster,
    rule_au_109_shared_registrant,
    rule_au_110_shared_hosting_ip,
    rule_au_113_direct_connect_origin_candidate,
    // AU-116: the multi-hop transitive closure of the infrastructure graph — a
    // hosting footprint chained across ≥2 IPs that no single-shared-host rule
    // (AU-110) can see; the infra analogue of AU-060's identity closure.
    rule_au_116_infrastructure_pivot_closure,
];

/// `(entity-only rule count, graph-aware relation rule count)` — the live,
/// authoritative split behind every "N rules (E entity + R graph-aware
/// relation)" prose mention (`README.md`). A
/// hand-maintained copy of this pair drifted silently every time a rule was
/// added in this same session (four cycles' worth of manual reconciliation
/// across the docs) — this accessor lets an architecture test tie the prose
/// to the registry directly, the same guard `modules::registry().len()`
/// already gives the module count.
#[must_use]
pub fn rule_counts() -> (usize, usize) {
    (RULES.len(), RELATION_RULES.len())
}

/// Run every relation-aware rule over an already quarantine-filtered, confirmed
/// entity slice (see [`evaluate_rules_on`]). Lets `Correlator::run` reuse the
/// single confirmed view and shared RuleContext it already built for the entity pass.
fn evaluate_relation_rules_on(
    context: &RuleContext,
    relations: &[Relation],
    scan_id: &str,
    now: u64,
    deadline: Option<std::time::Instant>,
) -> Vec<Correlation> {
    let mut out = Vec::new();
    for (i, rule) in RELATION_RULES.iter().enumerate() {
        // The graph-aware rules are the costly ones on a large recalled graph, so
        // the shared finalise deadline matters most here.
        if deadline.is_some_and(|dl| std::time::Instant::now() >= dl) {
            warn!(
                scan_id,
                ran = i,
                total = RELATION_RULES.len(),
                "correlator relation-rule budget exceeded — finalising with partial correlations"
            );
            break;
        }
        out.extend(rule(context, relations, scan_id, now));
    }
    out
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod perf;
