use super::*;
use crate::core::relation::{Relation, RelationKind};
use crate::core::test_support::InMemoryStore;

fn ent(kind: EntityKind, value: &str, conf: f64, scan: &str) -> Entity {
    Entity::new(kind, value, conf, scan)
}

#[test]
fn candidate_gate_picks_specific_personal_identifiers_only() {
    // Specific personal identifiers qualify…
    assert!(is_cross_scan_candidate(&ent(
        EntityKind::Email,
        "a@b.com",
        0.6,
        "s"
    )));
    assert!(is_cross_scan_candidate(&ent(
        EntityKind::Phone,
        "+61400000000",
        0.6,
        "s"
    )));
    assert!(is_cross_scan_candidate(&ent(
        EntityKind::Person,
        "Jane Citizen",
        0.5,
        "s"
    )));

    // …but infrastructure, single-token names, coarse geo, speculative
    // permutations, low confidence, and already-recalled nodes do NOT.
    assert!(!is_cross_scan_candidate(&ent(
        EntityKind::Domain,
        "google.com",
        0.9,
        "s"
    )));
    assert!(!is_cross_scan_candidate(&ent(
        EntityKind::Person,
        "Madonna",
        0.9,
        "s"
    )));
    let mut coarse = ent(EntityKind::Address, "QLD 4000, Australia", 0.6, "s");
    coarse.tag("postcode-only");
    assert!(!is_cross_scan_candidate(&coarse));
    let mut perm = ent(EntityKind::Username, "jcitizen", 0.6, "s");
    perm.tag("permuted");
    assert!(!is_cross_scan_candidate(&perm));
    assert!(!is_cross_scan_candidate(&ent(
        EntityKind::Email,
        "a@b.com",
        0.2,
        "s"
    )));
    let mut recalled = ent(EntityKind::Email, "a@b.com", 0.6, "s");
    recalled.tag(crate::core::tags::RECALLED);
    assert!(!is_cross_scan_candidate(&recalled));
}

#[test]
fn bridges_a_finding_seen_in_an_earlier_scan_without_inflating_confidence() {
    let store = InMemoryStore::new();
    // A PRIOR scan (a different investigation) recorded this phone.
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan"))
        .expect("should succeed");

    // This scan freshly discovers the same phone plus a brand-new email.
    let shared = ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan");
    let conf_before = shared.c_effective();
    let sources_before = shared.source_count();
    let fresh = ent(EntityKind::Email, "nobody@example.com", 0.6, "this-scan");
    let mut entities = vec![shared, fresh];

    let linked = link_cross_scan_history(&store, &mut entities, "this-scan");
    assert_eq!(linked, 1, "only the phone bridges to the prior scan");

    let shared = entities
        .iter()
        .find(|e| e.kind == EntityKind::Phone)
        .expect("should succeed");
    assert!(shared.has_tag("cross-scan"));
    assert!(
        shared.evidence.iter().any(|ev| ev.source
            == "cross_scan_history"
            && ev.summary.contains("earlier scan")),
        "carries the cross-scan provenance evidence"
    );
    // Non-corroborating: the history link must NOT inflate confidence or sources
    // (a recurrence can't tell a re-scan from an independent sighting).
    assert!((shared.c_effective() - conf_before).abs() < 1e-9);
    assert_eq!(shared.source_count(), sources_before);

    // The brand-new email (no prior sighting) is untouched.
    let fresh = entities
        .iter()
        .find(|e| e.kind == EntityKind::Email)
        .expect("should succeed");
    assert!(!fresh.has_tag("cross-scan"));

    // Idempotent: a second pass bridges nothing new.
    assert_eq!(
        link_cross_scan_history(&store, &mut entities, "this-scan"),
        0
    );
}

#[test]
fn cooccurrence_bridges_a_pair_seen_together_before() {
    let store = InMemoryStore::new();
    // A PRIOR investigation recorded a phone and an email TOGETHER.
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan"))
        .expect("should succeed");
    store
        .upsert_entity(&ent(
            EntityKind::Email,
            "jane@example.com",
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");

    // This scan freshly rediscovers BOTH of them (not yet persisted).
    let mut entities = vec![
        ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan"),
        ent(EntityKind::Email, "jane@example.com", 0.55, "this-scan"),
    ];

    let linked = link_cross_scan_cooccurrence(&store, &mut entities, "this-scan");
    assert_eq!(linked, 2, "both endpoints of the recurring pair are bridged");

    let phone = entities
        .iter()
        .find(|e| e.kind == EntityKind::Phone)
        .expect("should succeed");
    let email = entities
        .iter()
        .find(|e| e.kind == EntityKind::Email)
        .expect("should succeed");
    assert!(phone.has_tag("cross-scan-cooccurrence"));
    assert!(email.has_tag("cross-scan-cooccurrence"));
    // Each endpoint's evidence names the OTHER as the co-occurring partner.
    assert!(
        phone.evidence.iter().any(|ev| ev.source == CROSS_SCAN_SOURCE
            && ev.summary.starts_with(COOCCURRENCE_MARKER)
            && ev.summary.contains("jane@example.com")),
        "phone names the email partner"
    );
    assert!(
        email.evidence.iter().any(|ev| ev.source == CROSS_SCAN_SOURCE
            && ev.summary.starts_with(COOCCURRENCE_MARKER)
            && ev.summary.contains("+61400111222")),
        "email names the phone partner"
    );
}

#[test]
fn no_cooccurrence_when_pair_never_shared_a_prior_scan() {
    let store = InMemoryStore::new();
    // The phone and the email each recur, but in DIFFERENT prior scans — they
    // were never seen together, so there is no recurring association to bridge.
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-a"))
        .expect("should succeed");
    store
        .upsert_entity(&ent(EntityKind::Email, "jane@example.com", 0.7, "prior-b"))
        .expect("should succeed");

    let mut entities = vec![
        ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan"),
        ent(EntityKind::Email, "jane@example.com", 0.55, "this-scan"),
    ];

    let linked = link_cross_scan_cooccurrence(&store, &mut entities, "this-scan");
    assert_eq!(
        linked, 0,
        "co-recurrence in separate scans is not co-occurrence"
    );
    assert!(
        entities
            .iter()
            .all(|e| !e.has_tag("cross-scan-cooccurrence"))
    );
}

#[test]
fn cooccurrence_is_idempotent_and_never_inflates_confidence() {
    let store = InMemoryStore::new();
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan"))
        .expect("should succeed");
    store
        .upsert_entity(&ent(
            EntityKind::Email,
            "jane@example.com",
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");

    // Capture the phone endpoint's pre-link confidence/sources.
    let phone = ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan");
    let conf_before = phone.c_effective();
    let sources_before = phone.source_count();
    let mut entities = vec![
        phone,
        ent(EntityKind::Email, "jane@example.com", 0.55, "this-scan"),
    ];

    assert_eq!(
        link_cross_scan_cooccurrence(&store, &mut entities, "this-scan"),
        2
    );
    let phone_after = entities
        .iter()
        .find(|e| e.kind == EntityKind::Phone)
        .expect("should succeed");
    let evidence_after = phone_after.evidence.len();
    // Non-corroborating: the co-occurrence evidence reuses CROSS_SCAN_SOURCE, so
    // it must not raise the effective confidence or the corroborating-source count.
    assert!((phone_after.c_effective() - conf_before).abs() < 1e-9);
    assert_eq!(phone_after.source_count(), sources_before);

    // Idempotent: a second pass adds no new links and no duplicate evidence.
    assert_eq!(
        link_cross_scan_cooccurrence(&store, &mut entities, "this-scan"),
        0
    );
    assert_eq!(
        entities
            .iter()
            .find(|e| e.kind == EntityKind::Phone)
            .expect("should succeed")
            .evidence
            .len(),
        evidence_after,
        "re-run attaches no duplicate co-occurrence evidence"
    );
}

#[test]
fn idempotency_probes_match_the_delimited_partner_token_not_a_substring() {
    // Regression: the probes keyed on `summary.contains(partner)`, an unanchored
    // substring, so an entity already linked to `alice2` / `bob2` was mistaken for
    // already carrying a NEW link to `alice` / `bob` (substrings), silently dropping
    // the genuine distinct link on re-run. They now match the DELIMITED token the
    // summary writes (`` `{partner}` `` for co-occurrence; `({kind})` + `` `{partner}` ``
    // for relation recall).
    let mut e = Entity::new(EntityKind::Email, "hub@example.com", 0.7, "s");
    e.add_evidence(Evidence::new(
        CROSS_SCAN_SOURCE,
        cooccurrence_summary("alice2", 1),
    ));
    e.add_evidence(Evidence::new(
        CROSS_SCAN_SOURCE,
        relation_recall_summary("subdomain_of", "bob2", 1),
    ));

    // The exact recorded partners are still found (idempotency preserved)…
    assert!(endpoint_has_cooccurrence(&e, "alice2"));
    assert!(endpoint_has_relation_recall(&e, "subdomain_of", "bob2"));
    // …but a partner that is only a SUBSTRING of a recorded one must NOT match
    // (fail-before: these returned true, dropping the real new link).
    assert!(
        !endpoint_has_cooccurrence(&e, "alice"),
        "a substring partner must not false-match an existing co-occurrence link"
    );
    assert!(
        !endpoint_has_relation_recall(&e, "subdomain_of", "bob"),
        "a substring partner must not false-match an existing relation-recall link"
    );
}

#[test]
fn cooccurrence_partners_recorded_in_deterministic_order() {
    let store = InMemoryStore::new();
    // One prior scan recorded a phone alongside TWO emails.
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan"))
        .expect("should succeed");
    store
        .upsert_entity(&ent(EntityKind::Email, "aaa@example.com", 0.7, "prior-scan"))
        .expect("should succeed");
    store
        .upsert_entity(&ent(EntityKind::Email, "zzz@example.com", 0.7, "prior-scan"))
        .expect("should succeed");

    // Insert the current entities in a DIFFERENT (reverse-sorted) order than the
    // partners' value order, so a stable result can only come from sorting.
    let mut entities = vec![
        ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan"),
        ent(EntityKind::Email, "zzz@example.com", 0.55, "this-scan"),
        ent(EntityKind::Email, "aaa@example.com", 0.55, "this-scan"),
    ];

    link_cross_scan_cooccurrence(&store, &mut entities, "this-scan");

    // The phone's two co-occurrence records name its partners in a stable,
    // value-sorted order regardless of discovery order.
    let phone = entities
        .iter()
        .find(|e| e.kind == EntityKind::Phone)
        .expect("should succeed");
    let partners: Vec<&str> = phone
        .evidence
        .iter()
        .filter(|ev| ev.summary.starts_with(COOCCURRENCE_MARKER))
        .map(|ev| {
            if ev.summary.contains("aaa@example.com") {
                "aaa@example.com"
            } else {
                "zzz@example.com"
            }
        })
        .collect();
    assert_eq!(partners, vec!["aaa@example.com", "zzz@example.com"]);
}

#[test]
fn relation_recall_surfaces_a_prior_linked_connection() {
    let store = InMemoryStore::new();
    // A PRIOR investigation linked a phone to an address (located_at).
    let prior_phone = ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan");
    let prior_addr = ent(
        EntityKind::Address,
        "42 Wallaby Way, Brisbane QLD 4000",
        0.7,
        "prior-scan",
    );
    store.upsert_entity(&prior_phone).expect("should succeed");
    store.upsert_entity(&prior_addr).expect("should succeed");
    store
        .upsert_relation(&Relation::new(
            prior_phone.uid.clone(),
            prior_addr.uid.clone(),
            RelationKind::LocatedAt,
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");

    // This scan rediscovers ONLY the phone — the address is NOT present, so the
    // recall is the only way the prior connection resurfaces.
    let mut entities = vec![ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan")];

    let linked = link_cross_scan_relations(&store, &mut entities, "this-scan");
    assert_eq!(linked, 1, "the reappearing phone recalls its prior address link");

    let phone = &entities[0];
    assert!(phone.has_tag("cross-scan-relation"));
    assert!(
        phone.evidence.iter().any(|ev| ev.source == CROSS_SCAN_SOURCE
            && ev.summary.starts_with(RELATION_RECALL_MARKER)
            && ev.summary.contains("located_at")
            && ev.summary.contains(&prior_addr.value)),
        "the recall names the relationship kind and the prior partner value"
    );
}

#[test]
fn relation_recall_is_silent_without_a_prior_link() {
    let store = InMemoryStore::new();
    // The phone recurs, but it was never part of any relation in the prior scan.
    store
        .upsert_entity(&ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan"))
        .expect("should succeed");
    let mut entities = vec![ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan")];
    assert_eq!(
        link_cross_scan_relations(&store, &mut entities, "this-scan"),
        0
    );
    assert!(!entities[0].has_tag("cross-scan-relation"));
}

#[test]
fn relation_recall_ignores_infrastructure_relations() {
    let store = InMemoryStore::new();
    // A prior scan linked an email to a PERSON (identified_by — an identity edge)
    // and to a DOMAIN (belongs_to_domain — an infrastructure edge).
    let prior_person = ent(EntityKind::Person, "Jane Citizen", 0.7, "prior-scan");
    let prior_email = ent(EntityKind::Email, "jane@example.com", 0.7, "prior-scan");
    let prior_domain = ent(EntityKind::Domain, "example.com", 0.7, "prior-scan");
    store.upsert_entity(&prior_person).expect("should succeed");
    store.upsert_entity(&prior_email).expect("should succeed");
    store.upsert_entity(&prior_domain).expect("should succeed");
    store
        .upsert_relation(&Relation::new(
            prior_person.uid.clone(),
            prior_email.uid.clone(),
            RelationKind::IdentifiedBy,
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");
    store
        .upsert_relation(&Relation::new(
            prior_email.uid.clone(),
            prior_domain.uid.clone(),
            RelationKind::BelongsToDomain,
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");

    let mut entities = vec![ent(EntityKind::Email, "jane@example.com", 0.55, "this-scan")];
    let linked = link_cross_scan_relations(&store, &mut entities, "this-scan");
    assert_eq!(linked, 1, "only the identity-bearing link is recalled");

    let email = &entities[0];
    let recall = email
        .evidence
        .iter()
        .find(|ev| ev.summary.starts_with(RELATION_RECALL_MARKER))
        .expect("an identity-relation recall is attached");
    assert!(recall.summary.contains("identified_by"));
    assert!(recall.summary.contains(&prior_person.value));
    // The infrastructure edge to the domain is NOT recalled.
    assert!(
        !email
            .evidence
            .iter()
            .any(|ev| ev.summary.contains("belongs_to_domain")),
        "infrastructure relations are excluded from recall"
    );
}

#[test]
fn relation_recall_is_idempotent_and_never_inflates_confidence() {
    let store = InMemoryStore::new();
    let prior_phone = ent(EntityKind::Phone, "+61400111222", 0.7, "prior-scan");
    let prior_addr = ent(
        EntityKind::Address,
        "42 Wallaby Way, Brisbane QLD 4000",
        0.7,
        "prior-scan",
    );
    store.upsert_entity(&prior_phone).expect("should succeed");
    store.upsert_entity(&prior_addr).expect("should succeed");
    store
        .upsert_relation(&Relation::new(
            prior_phone.uid.clone(),
            prior_addr.uid.clone(),
            RelationKind::LocatedAt,
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");

    let phone = ent(EntityKind::Phone, "+61400111222", 0.55, "this-scan");
    let conf_before = phone.c_effective();
    let sources_before = phone.source_count();
    let mut entities = vec![phone];

    assert_eq!(
        link_cross_scan_relations(&store, &mut entities, "this-scan"),
        1
    );
    let evidence_after = entities[0].evidence.len();
    // Non-corroborating: the recall reuses CROSS_SCAN_SOURCE, so it must not raise
    // the effective confidence or the corroborating-source count.
    assert!((entities[0].c_effective() - conf_before).abs() < 1e-9);
    assert_eq!(entities[0].source_count(), sources_before);

    // Idempotent: a second pass recalls nothing new and adds no duplicate evidence.
    assert_eq!(
        link_cross_scan_relations(&store, &mut entities, "this-scan"),
        0
    );
    assert_eq!(entities[0].evidence.len(), evidence_after);
}

#[test]
fn bridges_an_email_to_a_username_recorded_under_a_different_kind() {
    let store = InMemoryStore::new();
    // A PRIOR investigation recorded the handle as a Username.
    store
        .upsert_entity(&ent(EntityKind::Username, "jordanmeyers", 0.7, "prior-scan"))
        .expect("should succeed");

    // This scan only ever sees the address. The UID-keyed recurrence pass cannot
    // bridge it — different kind means a different UID.
    let email = ent(
        EntityKind::Email,
        "jordan.meyers@example.com",
        0.6,
        "this-scan",
    );
    let conf_before = email.c_effective();
    let mut entities = vec![email];

    assert_eq!(
        link_cross_scan_history(&store, &mut entities, "this-scan"),
        0,
        "same-kind recurrence cannot see across kinds"
    );
    assert_eq!(
        link_cross_scan_kind_aliases(&store, &mut entities, "this-scan"),
        1
    );

    let bridged = &entities[0];
    assert!(bridged.has_tag(crate::core::cross_scan::ALIAS_TAG));
    assert!(!bridged.has_tag("cross-scan"), "the weaker tier only");
    assert!(
        bridged
            .evidence
            .iter()
            .any(|ev| ev.source == "cross_scan_history"
                && ev.summary.contains("jordanmeyers")
                && ev.summary.contains("not a confirmed")),
        "names the matched handle and states the link is not confirmed"
    );
    // Provenance only — a handle collision must never inflate confidence.
    assert!((bridged.c_effective() - conf_before).abs() < 1e-9);

    assert_eq!(
        link_cross_scan_kind_aliases(&store, &mut entities, "this-scan"),
        0,
        "idempotent"
    );
}

#[test]
fn alias_pass_skips_entities_the_stronger_recurrence_pass_already_bridged() {
    let store = InMemoryStore::new();
    store
        .upsert_entity(&ent(
            EntityKind::Email,
            "jordanmeyers@example.com",
            0.7,
            "prior-scan",
        ))
        .expect("should succeed");
    store
        .upsert_entity(&ent(EntityKind::Username, "jordanmeyers", 0.7, "prior-scan"))
        .expect("should succeed");

    let mut entities = vec![ent(
        EntityKind::Email,
        "jordanmeyers@example.com",
        0.6,
        "this-scan",
    )];

    assert_eq!(
        link_cross_scan_history(&store, &mut entities, "this-scan"),
        1
    );
    assert_eq!(
        link_cross_scan_kind_aliases(&store, &mut entities, "this-scan"),
        0,
        "already bridged by the stronger same-kind pass"
    );
    assert!(!entities[0].has_tag(crate::core::cross_scan::ALIAS_TAG));
}

#[test]
fn alias_pass_ignores_role_mailboxes_and_unseen_handles() {
    let store = InMemoryStore::new();
    store
        .upsert_entity(&ent(EntityKind::Username, "admin", 0.7, "prior-scan"))
        .expect("should succeed");

    let mut entities = vec![
        // Role mailbox: the handle identifies nobody.
        ent(EntityKind::Email, "admin@example.com", 0.6, "this-scan"),
        // Real handle, but no earlier scan recorded it.
        ent(EntityKind::Email, "unseenhandle@example.com", 0.6, "this-scan"),
    ];

    assert_eq!(
        link_cross_scan_kind_aliases(&store, &mut entities, "this-scan"),
        0
    );
    assert!(
        entities
            .iter()
            .all(|e| !e.has_tag(crate::core::cross_scan::ALIAS_TAG))
    );
}
