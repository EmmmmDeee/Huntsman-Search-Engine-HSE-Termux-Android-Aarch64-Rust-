use super::*;
    use crate::core::entity::{Entity, EntityKind, Evidence};

    #[test]
    fn gexf_has_xml_header() {
        let xml = entities_to_gexf(&[], &[], "test-scan");
        assert!(xml.starts_with("<?xml"));
        assert!(xml.contains("<gexf"));
        assert!(xml.contains("</gexf>"));
    }

    #[test]
    fn gexf_contains_nodes_for_entities() {
        let e = Entity::new(EntityKind::Email, "alice@example.com", 0.9, "s");
        let xml = entities_to_gexf(&[e], &[], "test-scan");
        assert!(xml.contains("alice@example.com"));
        assert!(xml.contains("<node"));
    }

    #[test]
    fn gexf_exports_the_diamond_vertex_per_kind() {
        // The attribution vertex is a first-class node attribute so Gephi can
        // partition the whole graph by Diamond role, not just by kind. It must
        // reflect the per-kind classification, not a single bucket.
        let email = Entity::new(EntityKind::Email, "alice@example.com", 0.9, "s"); // victim
        let ip = Entity::new(EntityKind::IpAddress, "203.0.113.7", 0.9, "s"); // infrastructure
        let pw = Entity::new(EntityKind::Password, "leaked", 0.9, "s"); // capability
        let xml = entities_to_gexf(&[email, ip, pw], &[], "s");
        assert!(
            xml.contains(r#"<attribute id="7" title="diamond_vertex" type="string"/>"#),
            "the diamond_vertex attribute must be declared: {xml}"
        );
        assert!(xml.contains(r#"<attvalue for="7" value="victim"/>"#), "{xml}");
        assert!(
            xml.contains(r#"<attvalue for="7" value="infrastructure"/>"#),
            "{xml}"
        );
        assert!(
            xml.contains(r#"<attvalue for="7" value="capability"/>"#),
            "{xml}"
        );
    }

    #[test]
    fn gexf_exports_generation_as_a_node_attribute() {
        // `generation` (pivot distance from the seed) is a first-class node
        // attribute so a Gephi analyst can size/colour the graph by expansion
        // depth — the debug bundle and CSV export already carry it, and GEXF was
        // the last graph artifact dropping it.
        let seed = Entity::new(EntityKind::Email, "seed@example.com", 0.9, "s"); // generation 0
        let mut deep = Entity::new(EntityKind::Username, "farpivot", 0.6, "s");
        deep.generation = 3;
        let xml = entities_to_gexf(&[seed, deep], &[], "s");
        assert!(
            xml.contains(r#"<attribute id="8" title="generation" type="integer"/>"#),
            "the generation attribute must be declared: {xml}"
        );
        assert!(
            xml.contains(r#"<attvalue for="8" value="0"/>"#),
            "the seed's generation (0) must be emitted: {xml}"
        );
        assert!(
            xml.contains(r#"<attvalue for="8" value="3"/>"#),
            "a pivoted entity's generation must be emitted verbatim: {xml}"
        );
    }

    #[test]
    fn gexf_creates_edges_for_a_shared_evidence_record() {
        // Two selectors that appear in the SAME breach record (identical source
        // AND summary) genuinely co-occur → one edge, labelled by the source.
        let mut a = Entity::new(EntityKind::Email, "a@x.com", 0.8, "s");
        a.add_evidence(Evidence::new("hibp", "Breach 'Apollo'"));
        let mut b = Entity::new(EntityKind::Domain, "x.com", 0.7, "s");
        b.add_evidence(Evidence::new("hibp", "Breach 'Apollo'"));
        let xml = entities_to_gexf(&[a, b], &[], "test-scan");
        assert!(
            xml.contains("<edge"),
            "a shared evidence record should create an edge"
        );
        assert!(xml.contains(r#"label="hibp""#));
    }

    #[test]
    fn gexf_co_occurrence_is_record_level_not_source_level() {
        // MUST-NOT-FIRE: a one-to-many fan-out enumeration (`username_search`
        // probing one handle across platforms) attaches a DISTINCT per-platform
        // summary to a separate entity each — independent existence-proofs of the
        // same selector, not a joint sighting. They must NOT be wired together.
        // Under the old source-NAME key both carried `username_search` and an edge
        // was drawn; this is the regression guard for that false clique (which, on
        // a real username scan, was ~80% of all export edges).
        let mut insta = Entity::new(EntityKind::Url, "https://instagram.com/h", 0.6, "s");
        insta.add_evidence(Evidence::new(
            "username_search",
            "@h has a profile on Instagram",
        ));
        let mut tiktok = Entity::new(EntityKind::Url, "https://tiktok.com/@h", 0.6, "s");
        tiktok.add_evidence(Evidence::new("username_search", "@h has a profile on TikTok"));
        let xml = entities_to_gexf(&[insta, tiktok], &[], "s");
        assert!(
            !xml.contains(r#"<edge "#),
            "same source name but different per-platform records must NOT co-occur:\n{xml}"
        );

        // MUST-FIRE: the SAME source AND SAME summary is one shared record — a
        // genuine joint sighting → exactly one edge, labelled by that source.
        let mut a = Entity::new(EntityKind::Email, "a@x.com", 0.6, "s");
        a.add_evidence(Evidence::new("hibp", "Breach 'Apollo'"));
        let mut b = Entity::new(EntityKind::Username, "aaa", 0.6, "s");
        b.add_evidence(Evidence::new("hibp", "Breach 'Apollo'"));
        let xml = entities_to_gexf(&[a, b], &[], "s");
        assert_eq!(
            xml.matches(r#"<edge "#).count(),
            1,
            "one shared breach record → exactly one edge:\n{xml}"
        );
        assert!(xml.contains(r#"label="hibp""#));
    }

    #[test]
    fn gexf_no_edges_for_unrelated_entities() {
        let mut a = Entity::new(EntityKind::Email, "a@x.com", 0.8, "s");
        a.add_evidence(Evidence::new("hibp", "breach"));
        let mut b = Entity::new(EntityKind::Domain, "y.com", 0.7, "s");
        b.add_evidence(Evidence::new("dns_intel", "resolved"));
        let xml = entities_to_gexf(&[a, b], &[], "test-scan");
        assert!(!xml.contains(r#"<edge "#));
    }

    #[test]
    fn gexf_excludes_non_corroborating_co_occurrence() {
        // Two candidates that share ONLY `name_intel` (the seed's permutation
        // engine) must NOT draw a co-occurrence edge: that is common-derivation,
        // not a shared sighting, and would wire every name-guess into a false
        // cluster. Their lineage is carried by the typed `DerivedFrom` edges.
        let mut a = Entity::new(EntityKind::Username, "jmeyers", 0.4, "s");
        a.add_evidence(Evidence::new("name_intel", "derived"));
        let mut b = Entity::new(EntityKind::Email, "jmeyers@gmail.com", 0.4, "s");
        b.add_evidence(Evidence::new("name_intel", "derived"));
        let xml = entities_to_gexf(&[a, b], &[], "s");
        assert!(
            !xml.contains(r#"<edge "#),
            "name_intel-only derivation must not draw a co-occurrence edge"
        );

        // Once an INDEPENDENT source (hibp) names both, they genuinely co-occur —
        // and the edge is labelled by the corroborating source alone, never the
        // derivation pass.
        let mut a = Entity::new(EntityKind::Username, "jmeyers", 0.4, "s");
        a.add_evidence(Evidence::new("name_intel", "derived"));
        a.add_evidence(Evidence::new("hibp", "breach"));
        let mut b = Entity::new(EntityKind::Email, "jmeyers@gmail.com", 0.4, "s");
        b.add_evidence(Evidence::new("name_intel", "derived"));
        b.add_evidence(Evidence::new("hibp", "breach"));
        let xml = entities_to_gexf(&[a, b], &[], "s");
        assert!(
            xml.contains(r#"label="hibp""#),
            "a genuine shared source must co-occur, labelled by that source"
        );
        assert!(
            !xml.contains("name_intel"),
            "the derivation source is not a co-occurrence basis"
        );
    }

    #[test]
    fn gexf_emits_typed_relation_edges() {
        use crate::core::relation::{Relation, RelationKind};
        let parent = Entity::new(EntityKind::Domain, "example.com", 0.9, "s");
        let child = Entity::new(EntityKind::Domain, "blog.example.com", 0.8, "s");
        let rel = Relation::new(
            child.uid.clone(),
            parent.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let xml = entities_to_gexf(&[parent.clone(), child.clone()], &[rel], "test-scan");
        // Typed edge labelled by kind…
        assert!(
            xml.contains(r#"label="subdomain_of""#),
            "expected a kind-labelled edge, got:\n{xml}"
        );
        // …referencing the same (full) node ids the <node> elements use.
        let src = &child.uid;
        let tgt = &parent.uid;
        assert!(
            xml.contains(&format!(r#"source="{src}" target="{tgt}""#)),
            "relation edge must reference existing node ids"
        );
    }

    #[test]
    fn gexf_drops_relation_edges_referencing_a_filtered_out_node() {
        use crate::core::relation::{Relation, RelationKind};
        // A caller (the candidate-quarantining exports) passes a CONFIRMED entity
        // subset as the node set but the FULL relation set. A relation whose
        // endpoint is a filtered-out node must NOT produce an `<edge>` — that would
        // reference an undeclared node id, which is structurally-invalid GEXF.
        let subject = Entity::new(EntityKind::Domain, "example.com", 0.9, "s");
        let child = Entity::new(EntityKind::Domain, "blog.example.com", 0.8, "s");
        let candidate = Entity::new(EntityKind::Email, "stranger@breach.example", 0.5, "s");
        let good = Relation::new(
            child.uid.clone(),
            subject.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let dangling = Relation::new(
            child.uid.clone(),
            candidate.uid.clone(), // endpoint absent from the node set below
            RelationKind::DerivedFrom,
            0.7,
            "s",
        );
        // Node set omits the candidate; relation set includes the dangling edge.
        let xml = entities_to_gexf(&[subject, child.clone()], &[good, dangling], "s");

        // The in-set relation edge is still emitted…
        assert!(
            xml.contains(r#"label="subdomain_of""#),
            "the in-set relation edge must survive: {xml}"
        );
        // …but no edge references the filtered-out candidate node.
        let cand_id = &candidate.uid;
        assert!(
            !xml.contains(&format!(r#"target="{cand_id}""#)),
            "an edge must not reference a node absent from <nodes>: {xml}"
        );
    }

    #[test]
    fn gexf_escapes_the_kind_attribute_and_the_scan_id() {
        // An `Other(<custom>)` kind is data-derived and can carry XML metachars;
        // unescaped, it would break the node's `kind` attvalue and thus the whole
        // document in Gephi. The scan id likewise sits in `<description>` text.
        // Both are now escaped (the node label, tags, and edge labels already were).
        let e = Entity::new(EntityKind::Other("a<b>&\"c".to_string()), "v", 0.9, "s");
        let xml = entities_to_gexf(&[e], &[], "sc<a>n&\"1");

        assert!(
            xml.contains(r#"<attvalue for="0" value="other:a&lt;b&gt;&amp;&quot;c"/>"#),
            "the kind attvalue must be XML-escaped, got:\n{xml}"
        );
        assert!(
            xml.contains(r#"<description>Scan sc&lt;a&gt;n&amp;&quot;1</description>"#),
            "the scan id in <description> must be XML-escaped, got:\n{xml}"
        );
        // Defence-in-depth: no raw metachar from our injected data reaches an
        // attribute or text node (which would make the .gexf unparseable).
        assert!(
            !xml.contains(r#"value="other:a<b>"#) && !xml.contains(r#"Scan sc<a>n"#),
            "raw metachars must never leak into the kind attribute or description"
        );
    }

    #[test]
    fn xml_escape_special_chars() {
        assert_eq!(
            xml_escape("a<b>c&d\"e'f"),
            "a&lt;b&gt;c&amp;d&quot;e&apos;f"
        );
    }

    #[test]
    fn xml_escape_drops_illegal_control_chars() {
        // A stray C0 control byte in an entity value must be dropped, not emitted —
        // otherwise the whole .gexf is unparseable. tab/LF/CR are legal and kept.
        assert_eq!(
            xml_escape("ab\u{0}c\u{7}d\u{1b}e"),
            "abcde",
            "NUL/BEL/ESC must be stripped"
        );
        assert_eq!(
            xml_escape("a\tb\nc\rd"),
            "a\tb\nc\rd",
            "tab/LF/CR preserved"
        );
        // C1 controls (0x80–0x9F) are valid in XML 1.0 and must be kept.
        assert_eq!(
            xml_escape("a\u{85}b"),
            "a\u{85}b",
            "C1 NEL kept (legal in XML 1.0)"
        );
        // Noncharacters are illegal and dropped.
        assert_eq!(xml_escape("a\u{FFFF}b"), "ab", "U+FFFF dropped");
    }

    /// Characterisation golden: pins the EXACT byte output for a deterministic
    /// input (entity uids are SHA-256(kind:value), so they're stable). Locks the
    /// full document — header, node attvalues, typed relation edge, and
    /// shared-evidence co-occurrence edge — so any byte-level change during a
    /// refactor is caught, not just the presence of substrings.
    #[test]
    fn gexf_golden_output_is_byte_stable() {
        use crate::core::relation::{Relation, RelationKind};
        let mut a = Entity::new(EntityKind::Domain, "example.com", 0.9, "s");
        a.add_evidence(Evidence::new("crtsh", "cert"));
        a.tag("breach");
        a.tag("geoint");
        let mut b = Entity::new(EntityKind::Domain, "blog.example.com", 0.8, "s");
        b.add_evidence(Evidence::new("crtsh", "cert"));
        let rel = Relation::new(
            b.uid.clone(),
            a.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let xml = entities_to_gexf(&[a, b], &[rel], "scan-1");
        // Both entities are connected by the relation edge — each has degree 1
        // in the undirected view, so coreness = 1 for both.
        let expected = r#"<?xml version="1.0" encoding="UTF-8"?>
<gexf xmlns="http://gexf.net/1.3" version="1.3">
  <meta>
    <creator>Huntsman Search Engine</creator>
    <description>Scan scan-1</description>
  </meta>
  <graph defaultedgetype="directed" mode="static">
    <attributes class="node" mode="static">
      <attribute id="0" title="kind" type="string"/>
      <attribute id="1" title="confidence" type="float"/>
      <attribute id="2" title="c_effective" type="float"/>
      <attribute id="3" title="classification" type="string"/>
      <attribute id="4" title="corroboration" type="integer"/>
      <attribute id="5" title="coreness" type="integer"/>
      <attribute id="6" title="tags" type="string"/>
      <attribute id="7" title="diamond_vertex" type="string"/>
      <attribute id="8" title="generation" type="integer"/>
    </attributes>
    <nodes>
      <node id="ed152b32b035d8e873341938ca5f75d242725beae5a202c27e413eb4477f8739" label="example.com">
        <attvalues>
          <attvalue for="0" value="domain"/>
          <attvalue for="1" value="0.900"/>
          <attvalue for="2" value="0.900"/>
          <attvalue for="3" value="VERIFIED"/>
          <attvalue for="4" value="1"/>
          <attvalue for="5" value="1"/>
          <attvalue for="6" value="breach|geoint"/>
          <attvalue for="7" value="infrastructure"/>
          <attvalue for="8" value="0"/>
        </attvalues>
      </node>
      <node id="df4bda23ac181f24c2f80cb94caa9745ce198e6164e5564186c27eeeaf90e273" label="blog.example.com">
        <attvalues>
          <attvalue for="0" value="domain"/>
          <attvalue for="1" value="0.800"/>
          <attvalue for="2" value="0.800"/>
          <attvalue for="3" value="VERIFIED"/>
          <attvalue for="4" value="1"/>
          <attvalue for="5" value="1"/>
          <attvalue for="6" value=""/>
          <attvalue for="7" value="infrastructure"/>
          <attvalue for="8" value="0"/>
        </attvalues>
      </node>
    </nodes>
    <edges>
      <edge id="0" source="df4bda23ac181f24c2f80cb94caa9745ce198e6164e5564186c27eeeaf90e273" target="ed152b32b035d8e873341938ca5f75d242725beae5a202c27e413eb4477f8739" weight="0.800" label="subdomain_of"/>
      <edge id="1" source="ed152b32b035d8e873341938ca5f75d242725beae5a202c27e413eb4477f8739" target="df4bda23ac181f24c2f80cb94caa9745ce198e6164e5564186c27eeeaf90e273" weight="1.0" label="crtsh"/>
    </edges>
  </graph>
</gexf>
"#;
        assert_eq!(xml, expected);
    }

    /// Coreness is emitted in the GEXF output: an isolated entity gets 0,
    /// entities in a connected pair (degree 1) get 1, and a triangle gets 2.
    /// This distinguishes the fragile hub (star centre, coreness 1 despite high
    /// degree) from the robust core (triangle member, coreness 2) — the key
    /// insight surfaced in Gephi via the coreness attribute.
    #[test]
    fn gexf_coreness_attribute_is_emitted() {
        use crate::core::relation::{Relation, RelationKind};
        // Triangle: a — b — c — a. All members have coreness 2.
        let a = Entity::new(EntityKind::Domain, "a.com", 0.9, "s");
        let b = Entity::new(EntityKind::Domain, "b.com", 0.8, "s");
        let c = Entity::new(EntityKind::Domain, "c.com", 0.8, "s");
        let rel_ab = Relation::new(
            a.uid.clone(),
            b.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let rel_bc = Relation::new(
            b.uid.clone(),
            c.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let rel_ca = Relation::new(
            c.uid.clone(),
            a.uid.clone(),
            RelationKind::SubdomainOf,
            0.8,
            "s",
        );
        let xml = entities_to_gexf(&[a, b, c], &[rel_ab, rel_bc, rel_ca], "s");
        // All three triangle members must carry coreness 2.
        let count_c2 = xml
            .lines()
            .filter(|l| l.contains(r#"for="5" value="2""#))
            .count();
        assert_eq!(count_c2, 3, "triangle: all three nodes have coreness 2\n{xml}");

        // Isolated entity (no edges) gets coreness 0.
        let iso = Entity::new(EntityKind::Email, "x@x.com", 0.5, "s");
        let xml2 = entities_to_gexf(&[iso], &[], "s");
        assert!(
            xml2.contains(r#"for="5" value="0""#),
            "isolated node must have coreness 0"
        );
    }

    /// Regression: node ids used to be the uid truncated to 12 hex chars (48
    /// bits), so two distinct entities whose FULL uids merely agreed on that
    /// prefix collided onto one `<node id>` — structurally-invalid GEXF (Gephi
    /// silently keeps only one node's data). These two usernames are a real,
    /// independently-verified SHA-256 preimage collision on the first 12 hex
    /// chars of `derive_uid`'s `"username:<value>"` hash (found by an offline
    /// birthday search — not a contrived string): both start `5ae30bc175a5`
    /// but diverge immediately after (`c869…` vs `f247…`). Two entities, two
    /// nodes, two ids.
    #[test]
    fn gexf_node_ids_do_not_collide_on_a_shared_twelve_hex_char_uid_prefix() {
        let a = Entity::new(EntityKind::Username, "u24143496", 0.5, "s");
        let b = Entity::new(EntityKind::Username, "u34619274", 0.5, "s");
        assert_eq!(
            &a.uid[..12],
            &b.uid[..12],
            "test setup: these two values must share a 12-hex-char uid prefix"
        );
        assert_ne!(a.uid, b.uid, "test setup: the full uids must still differ");

        let xml = entities_to_gexf(&[a.clone(), b.clone()], &[], "s");
        let node_count = xml.matches("<node id=").count();
        assert_eq!(
            node_count, 2,
            "two distinct entities must produce two distinct <node> elements, got:\n{xml}"
        );
        assert!(xml.contains(&format!(r#"<node id="{}""#, a.uid)));
        assert!(xml.contains(&format!(r#"<node id="{}""#, b.uid)));
    }

