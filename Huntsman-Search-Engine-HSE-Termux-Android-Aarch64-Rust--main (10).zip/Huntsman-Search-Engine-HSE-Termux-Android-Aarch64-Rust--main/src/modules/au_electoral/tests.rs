use crate::core::entity::EntityKind;
use crate::core::scan::{Target, TargetKind};

use super::{
    AuElectoral,
    division_map::division_centroid,
    entity::build_electoral_entities,
    parse::{extract_division, strip_electoral_html},
};

use crate::core::module::Module;

#[test]
fn division_centroid_returns_sydney_for_sydney() {
    let info = division_centroid("Sydney").expect("should succeed");
    assert_eq!(info.state, "NSW");
    assert!((info.lat - -33.8688).abs() < 0.01);
    assert!((info.lon - 151.2093).abs() < 0.01);
}

#[test]
fn division_centroid_is_case_insensitive() {
    assert!(division_centroid("MELBOURNE").is_some());
    assert!(division_centroid("brisbane").is_some());
    assert!(division_centroid("Perth").is_some());
}

#[test]
fn division_centroid_returns_none_for_unknown() {
    assert!(division_centroid("Xyzzy").is_none());
    assert!(division_centroid("").is_none());
}

// Table-driven: (html_snippet, expected_division, expected_suburb_contains)
#[test]
fn extract_division_parses_aec_pattern() {
    let cases: &[(&str, &str, Option<&str>)] = &[
        (
            "<p>You are enrolled for the Division of Sydney, NSW.</p>",
            "Sydney",
            None,
        ),
        (
            "<div>enrolled for Melbourne (VIC) 3000 Southbank</div>",
            "Melbourne",
            None,
        ),
        (
            "<span>You are enrolled in the Division of Brisbane</span>",
            "Brisbane",
            None,
        ),
        (
            "Division of North Sydney – electorate details",
            "North Sydney",
            None,
        ),
    ];
    for (html, expected_div, _suburb) in cases {
        let result = extract_division(html);
        assert!(result.is_some(), "expected a division from: {html}");
        let (div, _) = result.expect("should succeed");
        assert!(
            div.to_lowercase().contains(&expected_div.to_lowercase()),
            "expected '{expected_div}' in div '{div}'"
        );
    }
}

#[test]
fn extract_division_returns_none_for_not_enrolled() {
    let cases = &[
        "We could not find an enrolment for this name.",
        "No results found.",
        "<p>Your name was not found on the electoral roll.</p>",
    ];
    for html in cases {
        assert!(
            extract_division(html).is_none(),
            "should not extract from: {html}"
        );
    }
}

#[test]
fn build_electoral_entities_emits_address_and_coords() {
    let ents = build_electoral_entities("Sydney", None, "Haigen Bamford", "s");
    assert!(!ents.is_empty(), "Sydney division must produce entities");
    let kinds: Vec<_> = ents.iter().map(|e| &e.kind).collect();
    assert!(kinds.contains(&&EntityKind::Address), "must emit Address");
    assert!(
        kinds.contains(&&EntityKind::Coordinates),
        "must emit Coordinates"
    );
    // All entities must be AU-tagged.
    for e in &ents {
        assert!(e.has_tag("country:AU"), "entity must carry country:AU");
        assert!(e.has_tag("au-state:NSW"), "Sydney division must be NSW");
    }
}

#[test]
fn build_electoral_entities_unknown_division_emits_address_only() {
    let ents = build_electoral_entities("Xyzzy", None, "Test", "s");
    assert!(
        ents.iter().any(|e| e.kind == EntityKind::Address),
        "must still emit Address for unknown division"
    );
    assert!(
        !ents.iter().any(|e| e.kind == EntityKind::Coordinates),
        "no Coordinates for unknown division (no centroid)"
    );
}

#[test]
fn address_confidence_reflects_whether_a_suburb_was_resolved() {
    // A confirmed division WITH a resolvable suburb (from the offline
    // centroid table) gets the higher, module-doc-promised 0.72 tier —
    // electoral roll enrolment is compulsory and address-verified.
    let with_suburb = build_electoral_entities("Sydney", None, "Test", "s");
    let addr = with_suburb
        .iter()
        .find(|e| e.kind == EntityKind::Address)
        .expect("should succeed");
    assert!(
        (addr.confidence - 0.72).abs() < 1e-9,
        "suburb-level match must score 0.72, got {}",
        addr.confidence
    );

    // A division with NO suburb resolved (no centroid, no hint) is a
    // materially weaker locate — a division can span many suburbs — so it
    // must score the documented lower 0.58 tier, not the flat 0.72 a
    // suburb-level match gets.
    let division_only = build_electoral_entities("Xyzzy", None, "Test", "s");
    let addr2 = division_only
        .iter()
        .find(|e| e.kind == EntityKind::Address)
        .expect("should succeed");
    assert!(
        (addr2.confidence - 0.58).abs() < 1e-9,
        "division-only match must score 0.58, not the suburb-level 0.72: got {}",
        addr2.confidence
    );
}

#[test]
fn build_electoral_entities_suburb_hint_overrides_centroid_suburb() {
    let ents = build_electoral_entities("Sydney", Some("Newtown"), "Test", "s");
    let addr = ents
        .iter()
        .find(|e| e.kind == EntityKind::Address)
        .expect("should succeed");
    assert!(
        addr.value.contains("Newtown"),
        "suburb hint should override centroid suburb: {}",
        addr.value
    );
}

#[test]
fn strip_electoral_html_separates_adjacent_tags() {
    let html = "<div>Division</div><span>of</span><p>Sydney</p>";
    let text = strip_electoral_html(html);
    // Tags must be replaced by spaces so "DivisionofSydney" doesn't occur.
    assert!(
        !text.contains("Divisionof"),
        "tags must inject word breaks: {text}"
    );
    assert!(text.contains("Division"), "content must survive: {text}");
    assert!(text.contains("Sydney"), "content must survive: {text}");
}

#[test]
fn extract_division_returns_none_for_the_real_retired_aec_namesearch_response() {
    // Golden fixture (T2.7 corpus): a REAL response captured live
    // (2026-07-13) from `electorate.aec.gov.au/NameSearch.aspx`, the
    // endpoint this module's now-removed AEC leg used to query. Both a
    // nonsense name and a real enrolled public figure got the identical
    // generic "Temporarily Unavailable" error page rather than a
    // query-specific result, confirming the name-search capability is
    // permanently retired (see the module doc comment) — this pins that
    // real observed shape so `extract_division` never mistakes the error
    // page's boilerplate for an enrolment result if anything is ever
    // repointed at this endpoint again.
    let html = include_str!("testdata/aec_namesearch_retired.html");
    assert!(
        extract_division(html).is_none(),
        "the retired AEC error page must not parse as an enrolment result"
    );
}

#[test]
fn module_no_longer_dispatches_the_retired_aec_leg() {
    // Regression for the AEC-leg removal: three sequential state EC lookups
    // (NSW -> VIC -> ECQ), not four (the retired AEC national leg no longer
    // budgeted for).
    let m = AuElectoral;
    assert_eq!(m.max_timeout_ms(), 15_000);
}

#[test]
fn infer_state_from_division_maps_name_fragments() {
    use super::division_map::infer_state_from_division;
    assert_eq!(infer_state_from_division("North Sydney"), Some("NSW"));
    assert_eq!(infer_state_from_division("parramatta"), Some("NSW"));
    assert_eq!(infer_state_from_division("Hunter"), Some("NSW"));
    assert_eq!(infer_state_from_division("Newcastle"), Some("NSW"));
    assert_eq!(infer_state_from_division("MELBOURNE"), Some("VIC"));
    assert_eq!(infer_state_from_division("Geelong"), Some("VIC"));
    assert_eq!(infer_state_from_division("Ballarat"), Some("VIC"));
    assert_eq!(infer_state_from_division("Brisbane"), Some("QLD"));
    assert_eq!(infer_state_from_division("Gold Coast"), Some("QLD"));
    assert_eq!(infer_state_from_division("Perth"), Some("WA"));
    assert_eq!(infer_state_from_division("Fremantle"), Some("WA"));
    assert_eq!(infer_state_from_division("Adelaide"), Some("SA"));
    assert_eq!(infer_state_from_division("Hobart"), Some("TAS"));
    assert_eq!(infer_state_from_division("Launceston"), Some("TAS"));
    assert_eq!(infer_state_from_division("Canberra"), Some("ACT"));
    assert_eq!(infer_state_from_division("Darwin"), Some("NT"));
    assert_eq!(infer_state_from_division("Wentworth"), None);
}

#[test]
fn module_metadata_is_valid() {
    let m = AuElectoral;
    assert_eq!(m.name(), "au_electoral");
    assert!(m.accepts(&Target::new(TargetKind::FullName, "Haigen Bamford")));
    assert!(!m.accepts(&Target::new(TargetKind::Email, "x@example.com")));
    assert!(m.attack_techniques().contains(&"T1591.001"));
    assert!(m.attack_techniques().contains(&"T1589.003"));
}

#[test]
fn extract_division_no_panic_on_multibyte_before_marker() {
    // Regression (PROBLEM_TREE T0.1): a multibyte uppercase char before the
    // marker shifted a `to_lowercase()`-derived offset onto a non-char-boundary
    // in the original text → `str` slice panic. `find_ascii_ci` is boundary-safe.
    let html = "<p>İstanbul — Division of Sydney.</p>";
    let (div, _) = extract_division(html).expect("division parses without panic");
    assert!(div.starts_with("Sydney"), "got {div:?}");
}

/// Adversarial-input coverage (PROBLEM_TREE T2.7): `au_electoral` was one of
/// the two modules (alongside `au_property`) still missing the never-panics
/// proptest already applied to `au_people`'s HTML parsers. `html` is the
/// untrusted, scraped AEC/state-EC response; a plain proptest string covers
/// it directly since `extract_division` takes no seed name.
mod prop {
    use proptest::prelude::*;

    use super::extract_division;

    proptest! {
        #[test]
        fn extract_division_never_panics(s in ".{0,256}") {
            let _ = extract_division(&s);
        }
    }
}

// ─── Outage must not read as "not enrolled" ───────────────────────────────

use super::{RollOutcome, rolls_wholly_unreachable};

/// Enrolment is compulsory in Australia, so an empty result from this module
/// reads as *not on any roll* — a strong negative claim about a person. It must
/// only be reachable when a commission actually said so.
///
/// Before the `RollOutcome` split, each leg was one
/// `if let Ok(resp) = … && let Some(body) = … && let Some(div) = …` chain, so a
/// transport failure, an unreadable reply and a page naming no division were
/// indistinguishable — all three fell through to the same empty `Ok`.
#[test]
fn an_unreachable_commission_is_not_the_same_as_an_absent_enrolment() {
    // All three registries down: nothing was established, so this must be
    // reported rather than rendered as a clean negative.
    assert!(rolls_wholly_unreachable(&[
        RollOutcome::Unreachable,
        RollOutcome::Unreachable,
        RollOutcome::Unreachable,
    ]));

    // A commission that answered with no division is a REAL negative — the
    // lookup path demonstrably works. This must not be reported as an outage.
    // First-hit-wins makes this single-leg shape the common success case.
    assert!(!rolls_wholly_unreachable(&[RollOutcome::Answered]));

    // ...and its mirror: one leg tried, and it could not be reached. Nothing
    // was established, so this IS an outage even though only one leg ran.
    assert!(rolls_wholly_unreachable(&[RollOutcome::Unreachable]));

    // One answer rescues the rest: the empties alongside it are genuine.
    assert!(!rolls_wholly_unreachable(&[
        RollOutcome::Unreachable,
        RollOutcome::Answered,
        RollOutcome::Unreachable,
    ]));
    assert!(!rolls_wholly_unreachable(&[
        RollOutcome::Unreachable,
        RollOutcome::Unreachable,
        RollOutcome::Answered,
    ]));

    // No legs ran at all — cancellation, or a name that never got queried.
    // That is its own condition and must NOT be blamed on the registries.
    assert!(!rolls_wholly_unreachable(&[]));
}
