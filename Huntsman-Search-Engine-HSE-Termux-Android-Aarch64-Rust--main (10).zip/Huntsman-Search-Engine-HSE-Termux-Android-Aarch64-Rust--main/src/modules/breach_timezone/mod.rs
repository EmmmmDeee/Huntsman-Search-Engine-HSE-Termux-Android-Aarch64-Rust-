//! Breach timestamp timezone inference — cluster observed timestamps to infer
//! the target's active timezone.
//!
//! Stealer logs and breach records carry timestamps. If 70%+ of a
//! target's activity falls within a consistent 14-hour window, the
//! midpoint of that window reveals the local timezone (±1 hour). The
//! clustering algorithm itself ([`infer_timezone`]) is correct and directly
//! unit-tested.
//!
//! No network calls.
//!
//! **Known limitation**: `ModuleContext` (`src/core/module/mod.rs`) carries no
//! accessor for the scan's accumulated entity/evidence graph — only
//! `scan_id`/`bus`/`http`/`keys`/`cancel` — so [`Module::process`] cannot
//! read "evidence attributes already attached to entities" despite that
//! being this module's original intent (and the reason for its late,
//! priority-7 dispatch). What it does instead is slide a 10-digit window
//! across the bare `target.value` string (an Email/Username/Phone) looking
//! for embedded Unix timestamps — which a realistic target value essentially
//! never contains 5+ of, so `process()` returns empty on effectively every
//! real scan. The architecturally correct fix is a correlator rule (which
//! does see the full post-scan entity graph, e.g. via
//! `core::timeline::reconstruct`) reusing this file's existing clustering
//! algorithm, not a `Module`; that is a genuine redesign beyond a tactical
//! per-module audit fix, so it stays a documented follow-up rather than a
//! guess at one.

use async_trait::async_trait;

use crate::core::{
    confidence,
    entity::{Entity, EntityKind, Evidence},
    error::Result,
    module::{Module, ModuleCategory, ModuleContext, ModuleResult},
    scan::{Target, TargetKind},
};

const SRC: &str = "breach_timezone";
const MIN_TIMESTAMPS: usize = 5;
const MIN_CONCENTRATION: f64 = confidence::HIGH_PLUS;

pub struct BreachTimezone;

#[async_trait]
impl Module for BreachTimezone {
    fn name(&self) -> &'static str {
        SRC
    }
    fn description(&self) -> &'static str {
        "Timezone triangulation — infers a target's timezone from clustering of breach/stealer timestamps"
    }
    fn priority(&self) -> u8 {
        7
    }
    fn is_passive(&self) -> bool {
        true
    }

    /// Pure transform of data already in the graph — no observation of its
    /// own, so its evidence never counts as a corroborating source (see
    /// `Module::is_derivation` / `ENRICHMENT_ONLY_SOURCES`).
    fn is_derivation(&self) -> bool {
        true
    }
    fn accepts(&self, t: &Target) -> bool {
        matches!(
            t.kind,
            TargetKind::Email | TargetKind::Username | TargetKind::Phone
        )
    }

    fn category(&self) -> ModuleCategory {
        // The module makes no network calls; it clusters unix-timestamp digit
        // windows already present in the target value/evidence to infer a UTC
        // offset, then emits Address/Coordinates entities naming a physical
        // region (e.g. "US/Pacific", "Australia Eastern") — exactly Determine
        // Physical Locations. It never touches DNS/WHOIS/certs/scan databases
        // (ruling out T1596.x), never queries open/closed external sources or
        // performs scanning (ruling out T1593-T1597), and doesn't gather
        // identity/network/host attributes (ruling out T1589/T1590/T1592), so
        // the Geo category's default is both accurate and already maximally
        // tight for this module.
        ModuleCategory::Geo
    }

    fn produces(&self) -> &'static [EntityKind] {
        const KINDS: &[EntityKind] = &[EntityKind::Address, EntityKind::Coordinates];
        KINDS
    }

    async fn process(&self, target: &Target, ctx: &ModuleContext) -> Result<ModuleResult> {
        let mut result = ModuleResult::new();

        let hours = extract_hours_from_value(&target.value);
        if hours.len() < MIN_TIMESTAMPS {
            return Ok(result);
        }

        if let Some(tz) = infer_timezone(&hours) {
            for e in entities_for_inference(&tz, hours.len(), &ctx.scan_id) {
                result.push(e);
            }
        }

        Ok(result)
    }
}

/// Build the Address (+ optional derived Coordinates) entities for a resolved
/// [`TimezoneInference`] — pulled out of [`Module::process`] so this
/// entity-construction logic is directly unit-testable without going through
/// [`extract_hours_from_value`]'s digit-window parsing, and so the two
/// entities' tagging can't silently diverge from each other again (see
/// `coordinates_entity_carries_the_same_jurisdiction_tag_as_the_address_entity`
/// in the tests below — the Coordinates entity used to be built here without
/// the AU/NZ jurisdiction tag the Address entity got).
fn entities_for_inference(
    tz: &TimezoneInference,
    sample_count: usize,
    scan_id: &str,
) -> Vec<Entity> {
    let mut entities = Vec::with_capacity(2);

    let mut e = Entity::new(EntityKind::Address, tz.region, tz.confidence, scan_id);
    e.tag("geoint");
    e.tag(crate::core::tags::COARSE);
    e.tag("timezone-inferred");
    // Tag AU/NZ jurisdiction so the AU-056 cross-check can use it.
    tag_timezone_jurisdiction(&mut e, tz.utc_offset, tz.region);
    e.add_evidence(
        Evidence::new(
            SRC,
            format!(
                "Activity clustering suggests UTC{:+} ({})",
                tz.utc_offset, tz.region
            ),
        )
        .with_attr("utc_offset", tz.utc_offset.to_string())
        .with_attr("sample_count", sample_count.to_string())
        .with_attr("concentration", format!("{:.0}%", tz.concentration * 100.0)),
    );

    if let Some((lat, lon)) = crate::util::city_coords::city_coords(tz.region) {
        let coord_val = format!("{lat:.4},{lon:.4}");
        let mut c = Entity::new(
            EntityKind::Coordinates,
            &coord_val,
            confidence::derived_from(tz.confidence),
            scan_id,
        );
        c.tag("addr-derived");
        c.tag("geoint");
        c.tag("timezone-inferred");
        // Same jurisdiction signal as the Address entity `e` above — the
        // AU-056 cross-check reads `au-state:`/`country:` tags off
        // Coordinates entities specifically, so without this the derived
        // coordinate carries no jurisdiction even though the module just
        // inferred one.
        tag_timezone_jurisdiction(&mut c, tz.utc_offset, tz.region);
        c.add_evidence(
            Evidence::new(
                SRC,
                format!("Geocode of timezone-inferred region '{}'", tz.region),
            )
            .with_attr("utc_offset", tz.utc_offset.to_string()),
        );
        entities.push(c);
    }

    entities.push(e);
    entities
}

struct TimezoneInference {
    utc_offset: i32,
    region: &'static str,
    confidence: f64,
    concentration: f64,
}

fn extract_hours_from_value(value: &str) -> Vec<u32> {
    // Each 10-digit window that parses as a plausible unix timestamp
    // (2001–2033) is reduced to its UTC hour-of-day. `windows(10)` on a
    // shorter digit string yields nothing, so no length guard is needed.
    crate::util::str_util::ascii_digits(value)
        .as_bytes()
        .windows(10)
        .filter_map(|chunk| {
            let ts = std::str::from_utf8(chunk).ok()?.parse::<u64>().ok()?;
            (1_000_000_000..2_000_000_000)
                .contains(&ts)
                .then_some(((ts % 86400) / 3600) as u32)
        })
        .collect()
}

fn infer_timezone(hours: &[u32]) -> Option<TimezoneInference> {
    if hours.len() < MIN_TIMESTAMPS {
        return None;
    }

    let mut histogram = [0u32; 24];
    for &h in hours {
        histogram[h as usize % 24] += 1;
    }
    let total = hours.len() as f64;

    // Slide a 14-hour window; first-wins on ties, EXCEPT that a mapped offset
    // beats an unmapped one on a count tie. The search range spans offsets with
    // no region label (see `offset_to_region`), and the region gates emission
    // below (`offset_to_region(best_offset)?`); without this preference a plain
    // first-wins could land on an unmapped offset and drop an inference that a
    // tied, mapped offset would have produced. Among equally-mapped ties the
    // original first-wins order is preserved.
    let (best_offset, best_count) = (-12_i32..=12)
        .map(|offset| {
            let count: u32 = (8_i32..22)
                .map(|h| histogram[(h - offset).rem_euclid(24) as usize])
                .sum();
            (offset, count)
        })
        .fold((0_i32, 0_u32), |(best_off, best_cnt), (off, cnt)| {
            let breaks_tie = cnt == best_cnt
                && offset_to_region(off).is_some()
                && offset_to_region(best_off).is_none();
            if cnt > best_cnt || breaks_tie {
                (off, cnt)
            } else {
                (best_off, best_cnt)
            }
        });

    let concentration = best_count as f64 / total;
    if concentration < MIN_CONCENTRATION {
        return None;
    }

    // concentration ranges over [MIN_CONCENTRATION, 1.0], so this formula's
    // own maximum is confidence::TENTATIVE + (1.0 - MIN_CONCENTRATION) * 0.5
    // = 0.50 — well under confidence::MEDIUM_PLUS, so no further clamp is
    // needed (a `.min(confidence::MEDIUM_PLUS)` here would be dead code).
    let confidence = confidence::TENTATIVE + (concentration - MIN_CONCENTRATION) * 0.5;
    // No inference at all for an offset with no known region: the region is
    // emitted as the VALUE of a geoint Address entity, so a placeholder string
    // would surface as a fabricated finding. Yield nothing instead.
    let region = offset_to_region(best_offset)?;

    Some(TimezoneInference {
        utc_offset: best_offset,
        region,
        confidence,
        concentration,
    })
}

/// Map a bare integer UTC offset to a representative region label, or `None`
/// when no region is mapped for it.
///
/// `infer_timezone` searches `best_offset` over the full `-12..=12` range but
/// only a subset has a label; the uncovered offsets (`-12,-11,-10,-9,-4,-2,-1,
/// 4,6,7`) return `None` so the caller emits no entity, rather than a
/// fabricated `"Unknown timezone region"` value — the same yield-nothing
/// discipline the other extractors follow.
fn offset_to_region(offset: i32) -> Option<&'static str> {
    Some(match offset {
        -8 => "US/Pacific",
        -7 => "US/Mountain",
        -6 => "US/Central",
        -5 => "US/Eastern",
        -3 => "South America (Brazil/Argentina)",
        0 => "Western Europe (UK/Ireland)",
        1 => "Central Europe (France/Germany)",
        2 => "Eastern Europe (Finland/South Africa)",
        3 => "Middle East / Moscow",
        5 => "South Asia (Pakistan)",
        8 => "East Asia (China/Singapore/Perth)",
        9 => "East Asia (Japan/Korea)",
        10 | 11 => "Australia Eastern (Sydney/Melbourne)",
        12 => "Pacific (New Zealand)",
        _ => return None,
    })
}

/// Attach an AU/NZ jurisdiction tag for a timezone inference, but only where a
/// bare integer UTC offset can actually support the claim.
///
/// UTC+10/+11 is characteristically AU-eastern (AEST/AEDT), and UTC+12's
/// dominant/representative country is New Zealand — those claims are sound. A
/// bare +8/+9 offset CANNOT: UTC+8 is dominated by China/Singapore/Malaysia/
/// Taiwan (~1.4B) with Perth (~2M) a tiny minority the hour histogram cannot
/// single out, and Darwin is actually UTC+9:30 (unrepresentable in an
/// integer-hour histogram) while UTC+9 is Japan/Korea. Tagging every +8 subject
/// `country:AU`/`au-state:WA` (or +9 → NT) would fabricate an Australian
/// jurisdiction the data does not support, so those offsets get no AU tag. Pure,
/// so the jurisdiction logic is unit-testable.
fn tag_timezone_jurisdiction(e: &mut Entity, utc_offset: i32, region: &str) {
    match utc_offset {
        10 | 11 => {
            e.tag("country:AU");
            e.tag("au-state:AU");
        }
        12 if region.contains("New Zealand") => {
            e.tag("country:NZ");
        }
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    include!("tests.rs");
}
