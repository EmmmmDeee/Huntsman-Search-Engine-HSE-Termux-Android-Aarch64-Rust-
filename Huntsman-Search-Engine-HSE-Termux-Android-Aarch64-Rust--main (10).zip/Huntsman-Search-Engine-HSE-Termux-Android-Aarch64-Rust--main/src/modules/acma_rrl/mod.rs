//! ACMA Radiocommunications Register lookup.
//! Free; no key required.
//!
//! Endpoint: `GET https://web.acma.gov.au/rrl/licence_search.do?submit=Search&clientName={name}`
//! Also supports: clientAbn={abn}, latitude={lat}&longitude={lon}&radius={km}

#[cfg(test)]
mod tests;

use async_trait::async_trait;

use crate::core::{
    confidence,
    entity::{Entity, EntityKind, Evidence},
    error::Result,
    module::{Module, ModuleCategory, ModuleContext, ModuleCost, ModuleResult},
    scan::{Target, TargetKind},
};
use crate::util::http::RequestBuilderExt;

const SRC: &str = "acma_rrl";

pub struct AcmaRrl;

/// Scrape the ACMA RRL search-results table into
/// `(licensee_name, licence_number, service)` rows.
///
/// A deliberately dependency-free HTML walk (no scraper/html5ever crate, in
/// keeping with the lean Termux build): it splits on `<tr>`/`</tr>`, pulls each
/// `<td>` via [`strip_tags_plain`](crate::util::html::strip_tags_plain), and
/// keeps rows with at least three cells.
/// The header row (`Licensee`) and rows missing a name or licence number are
/// dropped, so the result is data-only. Pure given `html` — unit-testable
/// against a captured response without a network round-trip.
pub(super) fn parse_acma_html(html: &str) -> Vec<(String, String, String)> {
    // Returns Vec<(licensee_name, licence_number, service)>. The `<tr>`/`<td>`
    // table walk is shared via `util::html::table_rows`; this keeps only the
    // ACMA-specific column mapping and header/empty-row drop.
    let mut results = Vec::new();
    for cells in crate::util::html::table_rows(html) {
        if cells.len() >= 3 {
            let name = cells[0].clone();
            let lic_no = cells[1].clone();
            let service = cells[2].clone();
            if !name.is_empty() && name != "Licensee" && !lic_no.is_empty() {
                results.push((name, lic_no, service));
            }
        }
    }
    results
}

/// One `Organisation` entity per parsed licensee — EVERY row, no cap. The HTML
/// body is already size-bounded by `read_body_capped` (the real resource limit)
/// and the ACMA request sends no server-side page-size, so capping here would
/// silently drop licensees 21..N of a large multi-licence org or a
/// coordinate-radius search. Pure and testable.
pub(super) fn build_licensee_entities(
    licences: &[(String, String, String)],
    scan_id: &str,
) -> Vec<Entity> {
    let mut out = Vec::with_capacity(licences.len());
    for (name, lic_no, service) in licences {
        let mut org = Entity::new(EntityKind::Organisation, name, confidence::HIGH, scan_id);
        org.tag("acma");
        org.tag("radiocommunications-licensee");
        if !service.is_empty() {
            org.tag(format!(
                "service:{}",
                service.to_lowercase().replace(' ', "-")
            ));
        }
        org.add_evidence(
            Evidence::new(SRC, format!("ACMA RRL licence {lic_no} held by {name}"))
                .with_attr("licence_number", lic_no)
                .with_attr("service_type", service)
                .with_attr("source", "acma.gov.au"),
        );
        out.push(org);
    }
    out
}

/// Pull the licensee's ABN out of the RRL detail HTML, if present.
///
/// Finds the `ABN:</…>` label cell, takes the digits from the following table
/// cell, and returns them only when exactly 11 — the strict ABN length — so a
/// stray or malformed number is rejected rather than emitted as a bogus
/// `AbnAcn`. `None` when no ABN label is present (the common case for an
/// individual licensee).
pub(super) fn extract_abn_from_html(html: &str) -> Option<String> {
    let marker = "ABN:</";
    let pos = html.find(marker)?;
    let after = &html[pos + marker.len()..];
    let td_end = after.find("</td>")?;
    let raw = &after[..td_end];
    let abn = crate::util::str_util::ascii_digits(raw);
    if abn.len() == 11 { Some(abn) } else { None }
}

/// Remove HTML tags from a table cell, returning its visible text.
///
/// A single-pass character filter that drops everything between `<` and `>`.
/// Sufficient for the flat, well-formed RRL cells (no nested-bracket or
/// entity-decoding concerns here); the caller trims the result.

#[async_trait]
impl Module for AcmaRrl {
    fn name(&self) -> &'static str {
        "acma_rrl"
    }

    fn description(&self) -> &'static str {
        "ACMA Radiocommunications Register recon — enumerates licence holders by organisation name, ABN, or coordinates"
    }

    fn priority(&self) -> u8 {
        48
    }

    fn cost(&self) -> ModuleCost {
        ModuleCost::Free
    }

    fn accepts(&self, t: &Target) -> bool {
        matches!(
            t.kind,
            TargetKind::Organisation | TargetKind::AbnAcn | TargetKind::Coordinates
        )
    }

    fn category(&self) -> ModuleCategory {
        ModuleCategory::Corporate
    }

    fn attack_techniques(&self) -> &'static [&'static str] {
        // Resolves the licensee behind a radiocommunications licence —
        // T1591.002 Business Relationships. T1591.001 (Physical Locations)
        // does NOT apply: unlike the sibling AU registries that geocode a
        // registered address into Coordinates/Address, this module never
        // parses or emits a location — only Organisation and AbnAcn.
        &["T1591.002"]
    }

    fn produces(&self) -> &'static [EntityKind] {
        const KINDS: &[EntityKind] = &[EntityKind::Organisation, EntityKind::AbnAcn];
        KINDS
    }

    fn max_timeout_ms(&self) -> u64 {
        10_000
    }

    async fn process(&self, target: &Target, ctx: &ModuleContext) -> Result<ModuleResult> {
        let value = target.value.trim();
        let param = match target.kind {
            TargetKind::AbnAcn => format!("clientAbn={}", crate::util::http::urlencode(value)),
            TargetKind::Coordinates => {
                // Expect "lat,lon" format
                let parts: Vec<&str> = value.splitn(2, ',').collect();
                if parts.len() != 2 {
                    return Ok(ModuleResult::new());
                }
                let lat = parts[0].trim();
                let lon = parts[1].trim();
                format!("latitude={lat}&longitude={lon}&radius=10&submit=Search")
            }
            _ => format!("clientName={}", crate::util::http::urlencode(value)),
        };
        let url = format!("https://web.acma.gov.au/rrl/licence_search.do?submit=Search&{param}");

        let resp = ctx
            .http
            .get(&url)
            .header("Accept", "text/html,application/xhtml+xml")
            .send_tagged(SRC)
            .await?;

        let Some(resp) = crate::util::http::ok_or_absent(SRC, resp, &[404]).await? else {
            return Ok(ModuleResult::new());
        };
        // An empty result from this registry is a NEGATIVE CLAIM about the
        // subject, which an analyst will act on, so a connection reset while
        // streaming the body must never be able to produce one — see
        // `read_body_capped_or_fail`. Fail closed, as the sibling AU scrapers
        // already do (`asic_director::request_failed`, `au_electoral`'s
        // `RollOutcome::Unreachable`, `app_links`' `FetchOutcome::TransportFailed`).
        let html = crate::util::http::read_body_capped_or_fail(SRC, resp, 512 * 1024).await?;

        let licences = parse_acma_html(&html);
        let mut result = ModuleResult::new();
        result.extend(build_licensee_entities(&licences, &ctx.scan_id));

        // The RRL page carries at most ONE ABN (a single page-level field), so it
        // must be extracted and emitted exactly once — not re-extracted inside the
        // per-licensee loop above, which re-attributed the same ABN to every row.
        // Attribute it to the licensee only when the result is unambiguous (one
        // row); with multiple rows record it page-level so it isn't falsely bound
        // to a single name.
        if !licences.is_empty()
            && let Some(abn) = extract_abn_from_html(&html)
        {
            let mut abn_entity = Entity::new(
                EntityKind::AbnAcn,
                &abn,
                confidence::HIGH_PLUS,
                &ctx.scan_id,
            );
            abn_entity.tag("acma");
            let note = if licences.len() == 1 {
                format!("ABN for {} from ACMA RRL", licences[0].0)
            } else {
                "ABN listed on ACMA RRL licence page".to_string()
            };
            abn_entity.add_evidence(Evidence::new(SRC, note));
            result.push(abn_entity);
        }

        Ok(result)
    }
}
