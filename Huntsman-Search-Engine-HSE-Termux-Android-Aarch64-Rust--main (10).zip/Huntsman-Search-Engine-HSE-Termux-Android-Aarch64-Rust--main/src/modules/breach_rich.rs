//! Shared "maximum raw data" extractor for breach/stealer records.
//!
//! Both paid breach pools — `see_know` and `oathnet_pro` — receive verbose
//! per-record detail objects (infostealer device fingerprints, social handles,
//! address parts, employer, and a long tail of provider-specific scalar fields).
//! This module turns that long tail into first-class, pivotable entities so
//! nothing valuable stays locked inside the evidence blob (operator directive:
//! "I want everything. Maximum raw data.").
//!
//! It lives here, shared and source-parameterised, so the two providers extract
//! the **same** field set with the **same** semantics — the field knowledge
//! can't drift between them, and a new provider gets the full pass for free. The
//! caller supplies its own `source` tag (`"see-know"` / `"oathnet-pro"`) and the
//! evidence record; entities are pushed at full confidence and the caller
//! applies its own non-target demotion (see_know range-demotes after the call,
//! oathnet per row) — this pass stays demotion-agnostic.

use std::collections::HashSet;

use serde_json::Value;

use crate::core::{
    confidence,
    entity::{Entity, EntityKind, Evidence},
    module::ModuleResult,
    tags,
};
use crate::util::extract::is_placeholder_secret;
use crate::util::json::{is_null_sentinel, val_str};

/// Maximum length of an IEEE 802.11 SSID, in octets. A value in an `ssid` field
/// longer than this is not a network name (a truncated blob, a joined list), so
/// it must not be typed as one — see the saved-Wi-Fi pass in
/// [`extract_rich_detail`], which still surfaces such a value rather than
/// dropping it.
const MAX_SSID_OCTETS: usize = 32;

/// A value that is an *absence/redaction marker*, not real data: a SQL NULL
/// sentinel (`\N`, written for an empty column in dumped exports) or a provider
/// redaction placeholder (`UPGRADE_TO_SEE_FULL`, `REDACTED`, bracketed
/// `[NULL]`/`[FAIL]`…). Such a value must NEVER mint a graph node — two records
/// that each carry `\N`/`REDACTED` in, say, `company` would otherwise both yield
/// an `Organisation("\N")` node and falsely co-occur, poisoning correlation.
fn is_absent_marker(s: &str) -> bool {
    is_null_sentinel(s) || is_placeholder_secret(s)
}

/// A hardware-fingerprint value that is a well-known BIOS/SMBIOS/dmidecode
/// PLACEHOLDER (or a trivial all-zero / broadcast filler), not a real per-machine
/// id. Infostealer logs capture these verbatim from boards whose OEM never burned
/// a real serial, so the SAME string recurs across thousands of UNRELATED
/// machines — typing it as a `DeviceId`/`MacAddress` would defeat AU-106's
/// uniqueness assumption and let a shared placeholder falsely link two strangers
/// as "one physical machine". Compared case-insensitively and whitespace-trimmed.
fn is_placeholder_fingerprint(s: &str) -> bool {
    let t = s.trim();
    if t.is_empty() {
        return true;
    }
    // Trivial all-zero / all-`F` fillers, ignoring separators (`00:00:..`,
    // `00000000`, the null GUID, `FF-FF-..`/broadcast MAC).
    let core: String = t.chars().filter(char::is_ascii_alphanumeric).collect();
    if !core.is_empty()
        && (core.bytes().all(|b| b == b'0') || core.bytes().all(|b| b == b'f' || b == b'F'))
    {
        return true;
    }
    // Documented SMBIOS / dmidecode placeholder strings.
    let u = t.to_ascii_uppercase();
    matches!(
        u.as_str(),
        "TO BE FILLED BY O.E.M."
            | "TO BE FILLED BY OEM."
            | "TO BE FILLED BY OEM"
            | "SYSTEM SERIAL NUMBER"
            | "CHASSIS SERIAL NUMBER"
            | "BASE BOARD SERIAL NUMBER"
            | "DEFAULT STRING"
            | "NOT SPECIFIED"
            | "NOT APPLICABLE"
            | "NOT AVAILABLE"
            | "SERIAL NUMBER"
            | "SYSTEM MANUFACTURER"
            | "SYSTEM PRODUCT NAME"
            | "DEFAULT"
            | "NONE"
            | "UNKNOWN"
            | "O.E.M."
            | "OEM"
            | "STANDARD"
            | "INVALID"
            | "N/A"
            | "NA"
            | "NULL"
    )
}

/// Field names already turned into typed entities by the providers' primary
/// extractors (or deliberately suppressed as structural/metadata noise). The
/// catch-all pass skips these so it only emits the *long tail* — every other
/// value-bearing field — without duplicating a node already created or surfacing
/// envelope bookkeeping. Lower-cased compare so schema casing variants can't
/// leak through.
const RICH_DETAIL_SKIP: &[&str] = &[
    // Already typed by the primary identity/credential extractors.
    "email",
    "username",
    "phone",
    "phone_number",
    "full_name",
    "name",
    "ip",
    "country",
    "discord_id",
    "discordid",
    "steam_id",
    "steamid",
    "steam_id64",
    "password",
    "passwordhash",
    "password_hash",
    "hashed_password",
    "hash",
    "url",
    "url_str",
    "domain",
    // Composed/typed in the rich pass itself.
    "first_name",
    "firstname",
    "last_name",
    "lastname",
    "company",
    "employer",
    "organization",
    "organisation",
    "org",
    "mac",
    "mac_address",
    "bssid",
    // Saved Wi-Fi network names — typed as `Ssid` (or, when over the 802.11
    // length limit, surfaced as `Other` by that same pass), so the catch-all must
    // not also mint a duplicate node from the `@other:` namespace.
    "ssid",
    "wifi_ssid",
    "wifi_name",
    "network_name",
    "hwid",
    "machine_id",
    "device_id",
    "uuid",
    "guid",
    "computer_name",
    "machine",
    "hostname",
    "imei",
    "serial",
    "serial_number",
    "device_serial",
    "telegram",
    "skype",
    "facebook",
    "instagram",
    "twitter",
    "linkedin",
    "vk",
    "snapchat",
    "github",
    "tiktok",
    "reddit",
    // Mined for alternate emails/phones in the rich pass, not emitted verbatim.
    "bio",
    "city",
    "state",
    "region",
    "province",
    "zip",
    "zipcode",
    "postal",
    "postal_code",
    "postcode",
    "street",
    "address",
    "address_line",
    // Structural / metadata / provenance bookkeeping (kept verbatim on evidence,
    // but not worth a standalone graph node).
    "source",
    "source_db",
    "dbname",
    "_origin",
    "id",
    "_id",
    // Provider-internal record IDs — the pools stamp a `uid` and a
    // `migration_id` on every row (their own database keys, not the subject's).
    // Left un-skipped they leaked as `Other("uid")` / `Other("migration_id")`
    // junk nodes — one per record — diluting the graph with plumbing.
    "uid",
    "migration_id",
    "log_id",
    "log",
    "salt",
    // Validated + typed by each provider's own IBAN branch (OathNet's breach
    // path, SeekNow's extract path) — the mod-97 check-digit gate there refuses a
    // bad/redacted value. Skipped here so the UNVALIDATED catch-all can't also
    // mint an `Other("iban")` financial artifact for any string.
    "iban",
    "response_time_ms",
    "type",
    "success",
    "total",
    "breach_count",
    "stealer_count",
    "external_count",
    "index",
    "score",
    "_score",
    // Domain WHOIS/RDAP metadata — surfaced as Domain *attributes* by the
    // dedicated DNS/RDAP modules, not worth duplicating as standalone graph
    // nodes (and `dns` is a record map, never an entity value).
    "registrar",
    "dns",
    "nameservers",
    "name_servers",
    "created",
    "created_date",
    "creation_date",
    "updated",
    "updated_date",
    "last_changed",
    "expires",
    "expiry",
    "expiration_date",
    "status",
    "whois",
];

/// `O(1)` membership view over [`RICH_DETAIL_SKIP`], built once on first use.
/// The catch-all pass runs this lookup per field per record, so a `HashSet`
/// replaces a linear scan of the ~100 `&str` entries.
static RICH_DETAIL_SKIP_SET: std::sync::LazyLock<HashSet<&'static str>> =
    std::sync::LazyLock::new(|| RICH_DETAIL_SKIP.iter().copied().collect());

/// Push a breach-PII entity: tags `breach`, the provider `source`, plus any
/// `extra_tags`, then a cloned evidence record. (Source-sector tagging is
/// applied universally at engine admission, so it is not done per-module.)
fn push_breach_entity(
    result: &mut ModuleResult,
    e: Entity,
    ev: &Evidence,
    source: &str,
    extra_tags: &[&str],
) {
    result.push_with_tags(e, ev, &[tags::BREACH, source], extra_tags);
}

/// Push a stealer/infrastructure-CONTEXT entity: tags the provider `source` plus
/// any `extra_tags`, but deliberately NOT `breach`. Device fingerprints (MAC,
/// HWID, hostname, …) are infrastructure/context, not leaked PII.
fn push_context_entity(
    result: &mut ModuleResult,
    mut e: Entity,
    ev: &Evidence,
    source: &str,
    extra_tags: &[&str],
) {
    e.tag(source);
    for t in extra_tags {
        e.tag(*t);
    }
    e.add_evidence(ev.clone());
    result.push(e);
}

/// Maximum-raw-data extractor: turn the long tail of a breach/stealer record
/// into first-class, pivotable entities. Typed where a kind fits (Person,
/// Organisation, Address, MacAddress, DeviceId, platform Usernames), and
/// `Other(field)` for everything else — so EVERY value-bearing field of the raw
/// response becomes a node, not just an evidence attribute. Confidences are
/// modest (secondary, record-derived) so this breadth never outranks the primary
/// identity entities. Pushes at full confidence; the caller demotes non-target
/// rows in its own idiom.
pub fn extract_rich_detail(
    item: &Value,
    scan_id: &str,
    source: &str,
    ev: &Evidence,
    seen: &mut HashSet<String>,
    result: &mut ModuleResult,
) {
    let Some(obj) = item.as_object() else {
        return;
    };

    // ── Names: first + last → a composed Person (the bare `name`/`full_name`
    // path only fires when the value already contains a space). ──
    let first = val_str(item, "first_name").or_else(|| val_str(item, "firstname"));
    let last = val_str(item, "last_name").or_else(|| val_str(item, "lastname"));
    if let (Some(f), Some(l)) = (&first, &last) {
        let full = format!("{} {}", f.trim(), l.trim());
        // A SQL NULL (`\N`) or redaction marker in either name component is
        // absence, not a name — never compose a `"\N \N"` (nor a half-real
        // `"\N Smith"` / `"REDACTED Smith"`) Person from it.
        if full.len() >= 3
            && !is_absent_marker(f)
            && !is_absent_marker(l)
            // Breach dumps store `full_name = "{username} {username}"` when only a
            // handle is known; a doubled/slug username is not a real person.
            && !crate::core::validation::is_username_derived_name(&full)
            && seen.insert(format!("@person:{}", full.to_lowercase()))
        {
            push_breach_entity(
                result,
                Entity::new(EntityKind::Person, &full, confidence::MEDIUM_PLUS, scan_id),
                ev,
                source,
                &[],
            );
        }
    }

    // ── Organisation / employer. ──
    for k in ["company", "employer", "organization", "organisation", "org"] {
        if let Some(o) = val_str(item, k)
            && o.len() >= 2
            && !is_absent_marker(&o)
            && seen.insert(format!("@org:{}", o.to_lowercase()))
        {
            push_breach_entity(
                result,
                Entity::new(EntityKind::Organisation, &o, confidence::MEDIUM, scan_id),
                ev,
                source,
                &[],
            );
        }
    }

    // ── Device fingerprints — strong stealer-log pivots. ──
    for k in ["mac", "mac_address", "bssid"] {
        if let Some(m) = val_str(item, k)
            && m.len() >= 12
            && !is_absent_marker(&m)
            && !is_placeholder_fingerprint(&m)
            // A bare `.to_lowercase()` case-folds but does not reformat
            // separators the way `core::entity::normalise`'s MacAddress arm
            // does, so the SAME address spelled with different punctuation
            // across the `mac`/`mac_address`/`bssid` fields — or across two
            // different records in this shared `seen` set — each earned its
            // own dedup slot despite colliding on the same uid once
            // `Entity::new` constructs them.
            && seen.insert(format!(
                "@mac:{}",
                crate::core::entity::normalise(&EntityKind::MacAddress, &m)
            ))
        {
            push_context_entity(
                result,
                Entity::new(EntityKind::MacAddress, &m, confidence::MEDIUM_PLUS, scan_id),
                ev,
                source,
                &["device"],
            );
        }
    }
    // ── Saved Wi-Fi network names — the geolocation pivot a stealer log buries. ──
    //
    // An SSID is a *locatable* identifier, not just a label: `TargetKind::Ssid` is
    // accepted by [`crate::modules::wigle`], whose `ssid_search` resolves a
    // sufficiently unique name to every GPS point WiGLE has ever observed it at.
    // Untyped, this value reached the catch-all below as an `Other("ssid")` node —
    // a dead end the expansion loop cannot walk, since only a typed kind maps to a
    // `TargetKind`. Typing it opens the edge from "this machine had this network
    // saved" to "here is where that network physically is", which places the
    // machine's owner. It pairs with the `bssid` handled just above: the BSSID
    // geolocates via `mylnikov`, the SSID via `wigle`, and a record carrying both
    // yields two independent fixes on the same access point.
    //
    // Generic/default names (`NETGEAR`, `Free Public WiFi`) are emitted too. They
    // are real recorded data, and `wigle::ssid_search` applies its OWN uniqueness
    // gate before geolocating, so a default name cannot manufacture a false fix —
    // filtering here would discard a true observation to prevent a failure that
    // the consumer already prevents.
    for k in ["ssid", "wifi_ssid", "wifi_name", "network_name"] {
        let Some(s) = val_str(item, k) else { continue };
        if is_absent_marker(&s) {
            continue;
        }
        // Case-SENSITIVE dedup key. IEEE 802.11 SSIDs are case-sensitive, and
        // `core::entity` deliberately excludes `Ssid` from identity folding for
        // exactly that reason; lowercasing here would collapse two genuinely
        // different networks into one node.
        if !seen.insert(format!("@ssid:{s}")) {
            continue;
        }
        // A value longer than the 802.11 limit is not an SSID, so it must not be
        // typed as one — but it is still real recorded data, so it is surfaced as
        // an `Other(k)` node rather than dropped. These keys sit in
        // `RICH_DETAIL_SKIP`, so the catch-all will not surface them for us.
        let entity = if s.len() <= MAX_SSID_OCTETS {
            Entity::new(EntityKind::Ssid, &s, confidence::MEDIUM_PLUS, scan_id)
        } else {
            Entity::new(
                EntityKind::Other(k.to_string()),
                &s,
                confidence::LOW,
                scan_id,
            )
        };
        push_context_entity(result, entity, ev, source, &["wifi-network", "stealer"]);
    }
    for k in [
        "hwid",
        "machine_id",
        "device_id",
        "uuid",
        "guid",
        "computer_name",
        "machine",
        "hostname",
        // Hardware serials / mobile equipment ids — globally-unique device
        // anchors. A shared IMEI/serial across ≥2 accounts is strong single-device
        // co-location proof; typed as DeviceId so AU-106 (shared-device identity)
        // consumes them. (Also in RICH_DETAIL_SKIP so the catch-all does not also
        // mint a duplicate `Other("imei")` from the distinct `@other:` namespace.)
        "imei",
        "serial",
        "serial_number",
        "device_serial",
    ] {
        if let Some(d) = val_str(item, k)
            && d.len() >= 3
            && !is_absent_marker(&d)
            && !is_placeholder_fingerprint(&d)
            && seen.insert(format!("@device:{k}:{}", d.to_lowercase()))
        {
            push_context_entity(
                result,
                Entity::new(EntityKind::DeviceId, &d, confidence::MEDIUM_HIGH, scan_id),
                ev,
                source,
                &["device", "stealer"],
            );
        }
    }

    // ── Extra social handles → platform-prefixed Username pivots. ──
    // The record column and the minted value prefix are the same word, and the
    // list is shared with AU-108 (`core::breach_platforms`) so the rule that
    // counts these platforms can never fall behind the minting again. (github/
    // tiktok/reddit are real handle columns in both providers' records; before
    // they were listed they fell to the catch-all as opaque `Other("github")`
    // junk nodes instead of first-class Username pivots.)
    for &plat in crate::core::breach_platforms::BREACH_SOCIAL_PLATFORMS {
        let k = plat;
        if let Some(h) = val_str(item, k)
            && h.len() >= 2
            && !is_absent_marker(&h)
        {
            let value = format!("{plat}:{h}");
            // The dedup key must match what `Entity::new` will actually
            // construct below: `normalise`'s Username arm case-folds and
            // strips a wrapping quote/whitespace from the value's own edges
            // (it can never see a leading `@` here — the value always starts
            // with the platform name, not `h` — but a TRAILING quote on `h`,
            // a CSV/SQL-dump export artifact, sits at the value's own trailing
            // edge and IS stripped there). A bare `h.to_lowercase()` missed
            // that, letting a dirty and a clean spelling of the same handle
            // each earn their own dedup slot despite colliding on the same
            // uid once constructed.
            if seen.insert(format!(
                "@{plat}:{}",
                crate::core::entity::normalise(&EntityKind::Username, &value)
            )) {
                push_breach_entity(
                    result,
                    Entity::new(
                        EntityKind::Username,
                        value,
                        confidence::MEDIUM_HIGH,
                        scan_id,
                    ),
                    ev,
                    source,
                    &[plat],
                );
            }
        }
    }

    // ── Free-text `bio` mining → alternate contact leads. ──
    // A profile bio routinely carries an alternate email or phone the structured
    // columns miss — a genuine new pivot (unlocks HIBP/emailrep/phone modules).
    // Reuse the canonical scanner-grade extractors so "what an email/phone looks
    // like in free text" has one definition engine-wide. Lower confidence than a
    // structured field (inferred from prose). Shared here so BOTH breach providers
    // gain it on every record routed through the rich pass; OathNet's own breach
    // path mines bio separately, and the shared `seen` set dedups any overlap.
    if let Some(bio) = val_str(item, "bio") {
        for email in crate::util::extract::emails(&bio) {
            // `crate::util::extract::emails` already lower-cases every match
            // it returns, so this canonicalisation is a no-op for THIS call
            // site's own input today. It still matters: this `seen` set is
            // shared with `oathnet_pro::breach`'s own structured-field email
            // dedup (see this function's own doc comment above), which reads
            // a raw JSON field verbatim — a dirty spelling there (a breach-
            // dump escape tail, stray surrounding quotes) must canonicalise
            // the SAME way this site's insert does, or the two fail to dedup
            // against each other despite `Entity::new` collapsing both onto
            // the identical uid. Consistent with both other call sites into
            // this set rather than relying on one leg's extractor happening
            // to pre-clean its own input.
            let canonical = crate::core::entity::normalise(&EntityKind::Email, &email);
            if seen.insert(canonical) {
                push_breach_entity(
                    result,
                    Entity::new(EntityKind::Email, &email, confidence::MEDIUM, scan_id),
                    ev,
                    source,
                    &["bio-mined"],
                );
            }
        }
        for phone in crate::util::extract::phones(&bio) {
            if seen.insert(format!("@bio-phone:{phone}")) {
                push_breach_entity(
                    result,
                    Entity::new(EntityKind::Phone, &phone, confidence::MEDIUM, scan_id),
                    ev,
                    source,
                    &["bio-mined"],
                );
            }
        }
    }

    // ── Physical location: each part as its own geo-hint Address, plus a
    // composed multi-part address (street/city/state/postal/country). ──
    let mut addr_parts: Vec<String> = Vec::new();
    for k in [
        "street",
        "address",
        "address_line",
        "city",
        "state",
        "region",
        "province",
        "zip",
        "zipcode",
        "postal",
        "postal_code",
        "postcode",
    ] {
        if let Some(p) = val_str(item, k)
            && p.len() >= 2
            && !is_absent_marker(&p)
        {
            if seen.insert(format!("@addr-part:{k}:{}", p.to_lowercase())) {
                push_breach_entity(
                    result,
                    Entity::new(EntityKind::Address, &p, confidence::LOW_MEDIUM, scan_id),
                    ev,
                    source,
                    &["geo-hint"],
                );
            }
            addr_parts.push(p);
        }
    }
    if addr_parts.len() >= 2 {
        if let Some(c) = val_str(item, "country")
            && !is_absent_marker(&c)
        {
            addr_parts.push(c);
        }
        let composed = addr_parts.join(", ");
        if seen.insert(format!("@addr:{}", composed.to_lowercase())) {
            // Second gate on the RESOLVED coordinate, not just the input text:
            // `city_coords` is a many-to-one phrase lookup, so a composed
            // address here and an unrelated location string elsewhere in this
            // shared `seen` set can each pass their own text gate above yet
            // still resolve to the identical city centroid (see epieos/
            // oathnet_pro::breach's identical fix for this same root cause).
            if let Some((lat, lon)) = crate::util::city_coords::city_coords(&composed)
                && seen.insert(format!("@coord:{lat:.4},{lon:.4}"))
            {
                let coord_val = format!("{lat:.4},{lon:.4}");
                let mut c = Entity::new(
                    EntityKind::Coordinates,
                    &coord_val,
                    confidence::LOW_MEDIUM,
                    scan_id,
                );
                c.tag("addr-derived");
                c.tag("geoint");
                c.tag(tags::BREACH);
                c.tag(source);
                c.add_evidence(ev.clone());
                result.push(c);
            }
            push_breach_entity(
                result,
                Entity::new(
                    EntityKind::Address,
                    &composed,
                    confidence::MEDIUM_HIGH,
                    scan_id,
                ),
                ev,
                source,
                &["geo-hint", "composed-address"],
            );
        }
    }

    // ── Catch-all: every remaining value-bearing SCALAR field becomes an
    // `Other(field)` node, so no atomic data point in the raw record is left
    // un-surfaced. Nested objects/arrays are NOT turned into entities — a
    // stringified JSON blob (e.g. a `dns` record map) is not a meaningful graph
    // node and only pollutes the entity set; its atomic contents are surfaced by
    // the typed paths above and by the dedicated DNS/RDAP modules. ──
    for (k, v) in obj {
        // O(1) set lookup; the skip list is all-lowercase, so only pay for a
        // lowercased copy when `k` actually contains uppercase ASCII (the common
        // case is already lowercase → no allocation).
        let skip = if k.bytes().any(|b| b.is_ascii_uppercase()) {
            RICH_DETAIL_SKIP_SET.contains(k.to_lowercase().as_str())
        } else {
            RICH_DETAIL_SKIP_SET.contains(k.as_str())
        };
        if skip {
            continue;
        }
        let val = match v {
            Value::Null | Value::Array(_) | Value::Object(_) => continue,
            Value::String(s) => s.clone(),
            Value::Bool(b) => b.to_string(),
            Value::Number(n) => n.to_string(),
        };
        if val.is_empty() || val.len() > 2000 || is_absent_marker(&val) {
            continue;
        }
        if seen.insert(format!("@other:{k}:{}", val.to_lowercase())) {
            push_breach_entity(
                result,
                Entity::new(EntityKind::Other(k.clone()), &val, confidence::LOW, scan_id),
                ev,
                source,
                &["raw-field"],
            );
        }
    }
}

#[cfg(test)]
mod tests {
    include!("breach_rich_tests.rs");
}
