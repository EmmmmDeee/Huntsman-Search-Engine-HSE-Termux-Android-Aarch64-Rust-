//! `hse investigate [TEXT]` — extract OSINT entities mentioned in a free-text
//! investigative prompt.
//!
//! Bridges a natural-language question (the kind of prompt an operator would
//! type to an AI research assistant — "find what's linked to
//! alice@example.com", "who owns example.com and where are they based") to
//! HSE's own deterministic, offline entity extractor
//! (`util::entity_extractor`) — the SAME extractor `hse ingest` runs on
//! document text. No text is ever sent to an external LLM: extraction is pure
//! pattern/classifier matching, so results are exactly reproducible and never
//! fabricated.
//!
//! Mirrors `hse ingest --auto-scan`'s restraint exactly: extraction only
//! prints by default; `--auto-scan` additionally persists the batch as a
//! completed, correlated scan (offline — no module dispatch, no network) via
//! the shared [`crate::app::persist`] use case. Feeding every extracted
//! entity straight into the live scan engine as seeds is deliberately NOT
//! what this does — a natural-language prompt can easily NAME many entities,
//! and auto-launching reconnaissance against every one of them would be both
//! non-deterministic and a footgun (the identical reasoning `cli::ingest`
//! documents for its own `--auto-scan`).

use crate::core::error::{Error, Result};
use crate::util::entity_extractor::{EntityExtractor, ExtractedEntity};
use std::io::Read;

use super::truncate;

/// Evidence-source / scan-label strings are truncated to this many characters
/// so a long prompt doesn't dump a full paragraph into every entity's
/// evidence chain or the printed summary line.
const LABEL_MAX_CHARS: usize = 80;

/// Upper bound on a stdin-supplied investigation prompt. A natural-language
/// prompt is orders of magnitude smaller than this; the cap only trips on
/// clearly-not-a-prompt input (an accidental `hse investigate < huge.log`, or a
/// hostile unbounded pipe). Mirrors the whois client's 64 KiB response-read cap
/// — the same "a source must not be able to stream unbounded bytes into an
/// in-memory buffer" invariant.
const MAX_PROMPT_BYTES: usize = 64 * 1024;

/// Read an investigation prompt from `reader`, bounded to [`MAX_PROMPT_BYTES`].
///
/// The read is capped so an accidental or hostile large stream cannot grow the
/// buffer without limit (OOM). One byte past the cap is read so an over-cap
/// stream is *detected and rejected with a clear error* — pointing the operator
/// at `hse ingest` for documents — rather than being silently truncated to the
/// first 64 KiB, which would quietly analyse only part of the input.
fn read_prompt_bounded<R: Read>(reader: R) -> Result<String> {
    let mut buf = String::new();
    reader
        .take(MAX_PROMPT_BYTES as u64 + 1)
        .read_to_string(&mut buf)?;
    if buf.len() > MAX_PROMPT_BYTES {
        return Err(Error::InvalidTarget(format!(
            "investigate prompt from stdin exceeds {MAX_PROMPT_BYTES} bytes — \
             pass a focused prompt, not a file; pipe documents through \
             `hse ingest` instead"
        )));
    }
    Ok(buf)
}

/// Build the extractor from the caller-supplied `min_confidence` floor and run
/// it over `text`.
///
/// Split out of [`cmd_investigate`] so a unit test can call exactly the code
/// path the CLI dispatch calls — `Command::Investigate`'s parsed
/// `--min-confidence` value flows into `cmd_investigate`'s `min_confidence`
/// parameter unmodified (see `cli::mod::run_command`) and straight into this
/// function — without needing to capture the command's stdout/JSON output.
/// This is the wiring `REQ-CLI-012` exists to keep proven: `hse scan`'s
/// `--min-confidence` regression (a NaN/out-of-range floor silently emptying
/// the result set) is closed once at the shared [`confidence_floor`
/// parser](super::command::confidence_floor), but a *separate* bug — this
/// function ignoring its `min_confidence` argument and using a hardcoded
/// default instead — would not be caught by that parser-level guard alone.
fn extract_entities(text: &str, min_confidence: f64) -> Result<Vec<ExtractedEntity>> {
    let extractor =
        EntityExtractor::new(min_confidence).map_err(|e| Error::Other(e.to_string()))?;
    Ok(extractor.extract_from_text(text))
}

pub(super) async fn cmd_investigate(
    text: Option<String>,
    auto_scan: bool,
    min_confidence: f64,
    json: bool,
) -> Result<()> {
    let text = match text {
        Some(t) => t,
        // No positional TEXT → read from stdin, so a longer prompt (or a script
        // piping one in) doesn't need shell quoting.
        None => read_prompt_bounded(std::io::stdin())?,
    };
    let text = text.trim();
    if text.is_empty() {
        return Err(Error::InvalidTarget(
            "investigate text is empty — pass a prompt, e.g. \
             `hse investigate \"find what's linked to alice@example.com\"`, \
             or pipe one in on stdin"
                .to_string(),
        ));
    }

    let entities = extract_entities(text, min_confidence)?;

    // Best-effort, exactly like `hse ingest --auto-scan`: a persistence hiccup
    // must warn, never fail the command — the extracted entities are still
    // printed below regardless. Never persists an empty batch.
    let scan = if auto_scan && !entities.is_empty() {
        match run_auto_scan(&entities, text).await {
            Ok(summary) => Some(summary),
            Err(e) => {
                tracing::warn!("auto-scan: could not persist extracted entities: {e}");
                None
            }
        }
    } else {
        None
    };

    if json {
        print_json(text, &entities, scan.as_ref());
    } else {
        print_table(text, &entities, scan.as_ref());
    }
    Ok(())
}

/// Result of persisting an `--auto-scan` batch — the summary printed to the
/// operator.
struct AutoScanSummary {
    sid: String,
    entities: usize,
    relations: usize,
    correlations: usize,
    /// `false` when relations/correlations were skipped for size (see
    /// `app::persist::PERSIST_ENRICH_MAX_ENTITIES`) — every entity is still
    /// stored either way; this disambiguates a size-skipped pass from a batch
    /// that genuinely yielded zero relations/correlations.
    enriched: bool,
}

/// Persist the extracted `entities` as a completed, correlated scan — the
/// `--auto-scan` action. Same shape as `cli::ingest::run_auto_scan`, sourced
/// from the prompt text instead of a document, and sharing the identical
/// conversion ([`crate::app::convert`]) and persistence
/// ([`crate::app::persist`]) use cases so the two commands can never drift on
/// how a batch becomes a scan.
async fn run_auto_scan(entities: &[ExtractedEntity], text: &str) -> Result<AutoScanSummary> {
    let label = truncate(text, LABEL_MAX_CHARS);
    // Collision-free per call — same rationale as ingest's identical fix: two
    // `hse investigate --auto-scan` runs within the same second must not
    // collide and overwrite each other's scan row + entities.
    let sid = format!(
        "investigate-{}",
        crate::util::uid::scan_id("investigate", text)
    );
    let evidence_source = format!("investigate:{label}");
    let mut converted: Vec<crate::core::entity::Entity> = entities
        .iter()
        .map(|e| {
            crate::app::convert::extracted_to_hse_entity(
                e,
                &sid,
                &evidence_source,
                "investigate-query",
            )
        })
        .collect();
    // Same admission guard `hse import`/`hse ingest --auto-scan` run before
    // persisting — see ingest's identical call for the full rationale.
    crate::app::import::deduplicate_by_uid(&mut converted);
    let scan_label =
        crate::app::persist::strongest_identity_label(&converted, format!("investigate: {label}"));
    let (relations, correlations, enriched) = crate::app::persist::persist_entities_as_scan(
        &sid,
        scan_label,
        crate::core::scan::TargetKind::FullName,
        &converted,
    )
    .await?;
    Ok(AutoScanSummary {
        sid,
        entities: converted.len(),
        relations,
        correlations,
        enriched,
    })
}

fn print_table(text: &str, entities: &[ExtractedEntity], scan: Option<&AutoScanSummary>) {
    if entities.is_empty() {
        println!(
            "No OSINT entities recognised in that prompt — try lowering \
             --min-confidence or naming something concrete (an email, domain, \
             phone number, username, ...)."
        );
        return;
    }
    println!(
        "Investigate: {:?} — {} entit{} found",
        truncate(text, LABEL_MAX_CHARS),
        entities.len(),
        if entities.len() == 1 { "y" } else { "ies" }
    );
    println!();
    for e in entities {
        println!(
            "  {:<12} {:<40} confidence {:.2}  ({})",
            e.kind.to_str(),
            e.value,
            e.confidence,
            e.source_pattern
        );
    }
    if let Some(s) = scan {
        println!(
            "\nauto-scan: stored scan {} ({} entities, {} relations, {} correlations) — \
             view with `hse list`",
            s.sid, s.entities, s.relations, s.correlations
        );
        if !s.enriched {
            println!(
                "  note: relations/correlations skipped — {} entities exceeds the \
                 {}-entity enrichment cap; every entity is still stored",
                s.entities,
                crate::app::persist::PERSIST_ENRICH_MAX_ENTITIES
            );
        }
    }
}

fn print_json(text: &str, entities: &[ExtractedEntity], scan: Option<&AutoScanSummary>) {
    let entities_json: Vec<_> = entities
        .iter()
        .map(|e| {
            serde_json::json!({
                "kind": e.kind.to_str(),
                "value": e.value,
                "confidence": e.confidence,
                "source_pattern": e.source_pattern,
                "boost_reason": e.boost_reason,
            })
        })
        .collect();
    let mut body = serde_json::json!({
        "query": text,
        "entities": entities_json,
    });
    if let Some(s) = scan {
        body["auto_scan"] = serde_json::json!({
            "scan_id": s.sid,
            "entities": s.entities,
            "relations": s.relations,
            "correlations": s.correlations,
            "enrichment_skipped": !s.enriched,
        });
    }
    println!(
        "{}",
        serde_json::to_string_pretty(&body).unwrap_or_else(|_| "{}".into())
    );
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_text() -> &'static str {
        "Find everything linked to alice@example.com and the domain example.com"
    }

    // `sample_text()` intentionally uses RFC 2606 placeholder values (they
    // are the clearest, most realistic way to demonstrate extraction from
    // natural language). That makes it unusable for tests that assert on
    // what actually gets *persisted* by `run_auto_scan`, since the same
    // admission-guard filter `hse import` and the live-scan engine already
    // apply now runs here too and correctly drops placeholder entities.
    fn live_prompt_text() -> &'static str {
        "Find everything linked to qa-fixture@hse-investigate-unittest.dev and the domain hse-investigate-unittest.dev"
    }

    #[test]
    fn stdin_prompt_read_is_bounded() {
        // Under the cap: returned verbatim (any `Read`, so a byte slice stands
        // in for stdin).
        assert_eq!(
            read_prompt_bounded(&b"find alice@example.com"[..]).unwrap(),
            "find alice@example.com"
        );
        // Exactly at the cap: still accepted in full.
        let exact = vec![b'b'; MAX_PROMPT_BYTES];
        assert_eq!(
            read_prompt_bounded(&exact[..]).unwrap().len(),
            MAX_PROMPT_BYTES
        );
        // One byte over the cap: rejected with a clear error rather than an
        // unbounded read — this is the regression the review flagged.
        let over = vec![b'a'; MAX_PROMPT_BYTES + 1];
        assert!(matches!(
            read_prompt_bounded(&over[..]),
            Err(Error::InvalidTarget(_))
        ));
    }

    #[test]
    fn extracts_email_and_domain_from_a_natural_language_prompt() {
        // The core bridge this command exists for: a free-text investigative
        // question, not a clean single value, still yields the entities it
        // names — the same deterministic extractor `hse ingest` already runs
        // on document text, so no external LLM call and nothing fabricated.
        let extractor = EntityExtractor::new(0.30).expect("valid floor");
        let entities = extractor.extract_from_text(sample_text());
        assert!(
            entities.iter().any(|e| e.value == "alice@example.com"),
            "must extract the email mentioned in the prompt: {entities:?}"
        );
        assert!(
            entities.iter().any(|e| e.value == "example.com"),
            "must extract the domain mentioned in the prompt: {entities:?}"
        );
    }

    #[tokio::test]
    async fn auto_scan_persists_entities_extracted_from_the_prompt() {
        // Under cfg(test) the store is rooted in a temp dir, so this touches
        // no real ~/.huntsman. Uses `live_prompt_text()`, not `sample_text()`:
        // this test asserts on the persisted count, and `sample_text()`'s
        // placeholder entities are now correctly filtered before persist.
        let extractor = EntityExtractor::new(0.30).expect("valid floor");
        let entities = extractor.extract_from_text(live_prompt_text());
        assert!(
            !entities.is_empty(),
            "the sample prompt must extract something"
        );

        let summary = run_auto_scan(&entities, live_prompt_text())
            .await
            .expect("auto-scan should persist the extracted entities");
        assert!(
            summary.sid.starts_with("investigate-"),
            "the scan id must mark it as an investigate-originated scan: {}",
            summary.sid
        );
        assert_eq!(summary.entities, entities.len());
    }

    #[tokio::test]
    async fn auto_scan_ids_are_unique_across_calls_in_the_same_second() {
        // Same collision hazard ingest's auto-scan had (and was fixed for):
        // a fixed-per-second id would let two investigations of the same
        // prompt in the same second overwrite each other's data. Uses
        // `live_prompt_text()` so this exercises the real persistence path
        // rather than the all-filtered/0-entity path.
        let extractor = EntityExtractor::new(0.30).expect("valid floor");
        let entities = extractor.extract_from_text(live_prompt_text());
        let a = run_auto_scan(&entities, live_prompt_text())
            .await
            .expect("first auto-scan persists");
        let b = run_auto_scan(&entities, live_prompt_text())
            .await
            .expect("second auto-scan persists");
        assert_ne!(
            a.sid, b.sid,
            "two investigations must not collide on one scan id (would overwrite data)"
        );
    }

    #[tokio::test]
    async fn auto_scan_drops_placeholder_entities() {
        // `run_auto_scan` claims (in its own doc comment) to share the same
        // admission-guard filtering as `hse import` and the live-scan
        // engine. Prove it: a prompt that only names RFC 2606 placeholder
        // values must extract something (so this isn't vacuous) but persist
        // nothing.
        let extractor = EntityExtractor::new(0.30).expect("valid floor");
        let entities = extractor.extract_from_text(sample_text());
        assert!(
            !entities.is_empty(),
            "the placeholder-only prompt must still extract entities to filter"
        );

        let summary = run_auto_scan(&entities, sample_text())
            .await
            .expect("auto-scan must still succeed on an all-filtered batch");
        assert_eq!(
            summary.entities, 0,
            "placeholder entities (alice@example.com, example.com) must never be persisted as real findings"
        );
    }

    #[test]
    fn entities_extracted_from_a_prompt_carry_investigate_provenance() {
        // Regression guard for the shared app::convert function: an
        // investigate-sourced entity must NOT be mislabelled as
        // document-ingested, and its evidence must name the prompt, not a
        // filename — the two commands share the converter but must never
        // share (or default) provenance.
        let entity = crate::app::convert::extracted_to_hse_entity(
            &ExtractedEntity {
                kind: crate::util::entity_extractor::EntityKind::Email,
                value: "alice@example.com".to_string(),
                confidence: 0.85,
                context: None,
                source_pattern: "email_rfc5322".to_string(),
                boost_reason: None,
            },
            "scan-1",
            "investigate:find what's linked to alice@example.com",
            "investigate-query",
        );
        assert!(entity.tags.contains(&"investigate-query".to_string()));
        assert!(!entity.tags.contains(&"document-ingestion".to_string()));
        assert!(
            entity
                .evidence
                .iter()
                .any(|e| e.source.starts_with("investigate:")),
            "evidence must name the investigate origin, not ingest"
        );
    }

    #[tokio::test]
    async fn empty_prompt_is_rejected() {
        let err = cmd_investigate(Some("   ".to_string()), false, 0.30, false)
            .await
            .expect_err("blank text must be rejected, not silently scan nothing");
        assert!(matches!(err, Error::InvalidTarget(_)));
    }

    #[test]
    fn min_confidence_reaches_the_extractor_filter_unmodified() {
        // REQ-CLI-012 wiring guard. `confidence_floor` (the shared parser
        // `scan`/`ingest`/`investigate` all use) is independently verified —
        // see `cli::command`'s own tests — but that only proves clap rejects
        // a NaN/out-of-range *string*. It says nothing about whether the
        // parsed `f64` that clap hands `Command::Investigate::min_confidence`
        // actually reaches `extract_entities` (and so `EntityExtractor`'s
        // `confidence >= min_confidence` filter) unmodified, as opposed to
        // being silently dropped in favour of a hardcoded default somewhere
        // between the match arm in `cli::mod::run_command` and here. Prove it
        // by calling `extract_entities` — the exact function `cmd_investigate`
        // calls with its `min_confidence` parameter — at two different
        // floors and observing the filtered set actually change.
        //
        // The prompt names two entities that straddle 0.70: a social handle
        // (`patterns::extract_by_patterns` stamps confidence 0.60, "could be
        // mention, not identity") and an email (0.85, RFC 5322).
        let text = "Reach out to qa-fixture@hse-investigate-wiring-test.dev, also known as \
             @wiringtestbot";

        let permissive = extract_entities(text, 0.30).expect("0.30 is a valid floor");
        assert!(
            permissive
                .iter()
                .any(|e| e.value == "qa-fixture@hse-investigate-wiring-test.dev"),
            "the email must survive a floor below its own 0.85 confidence: {permissive:?}"
        );
        assert!(
            permissive.iter().any(|e| e.value == "wiringtestbot"),
            "the social handle must survive a floor below its own 0.60 confidence: {permissive:?}"
        );

        let strict = extract_entities(text, 0.70).expect("0.70 is a valid floor");
        assert!(
            strict
                .iter()
                .any(|e| e.value == "qa-fixture@hse-investigate-wiring-test.dev"),
            "the 0.85-confidence email must still survive a 0.70 floor: {strict:?}"
        );
        assert!(
            !strict.iter().any(|e| e.value == "wiringtestbot"),
            "the 0.60-confidence handle must be filtered by a 0.70 floor — if this \
             fails, --min-confidence is not reaching the extractor: {strict:?}"
        );
    }
}
